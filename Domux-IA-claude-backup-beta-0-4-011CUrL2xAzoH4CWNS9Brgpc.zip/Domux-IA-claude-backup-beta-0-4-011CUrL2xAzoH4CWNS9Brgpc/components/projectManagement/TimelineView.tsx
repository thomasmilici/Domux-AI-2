/**
 * Componente Timeline con vista Gantt per Tier 2+
 * Mostra pianificazione attività e avanzamento progetto
 * Versione 0.5 - Sistema IA-Driven
 */

import React, { useState, useMemo } from 'react';
import { TierGuard } from '../subscription/TierGuard';
import { useTimeline, useGenerationMonitor } from '../../hooks/useProjectSync';
import { updateActivityProgress } from '../../services/projectManagementService';
import type { User } from '../../services/firebase';
import type { Activity, ActivityCategory } from '../../types/projectManagement';

interface TimelineViewProps {
  user: User;
  projectId: string;
}

const TimelineView: React.FC<TimelineViewProps> = ({ user, projectId }) => {
  return (
    <TierGuard user={user} requiredTier="basic" showUpgradeMessage={true}>
      <TimelineContent projectId={projectId} />
    </TierGuard>
  );
};

const TimelineContent: React.FC<{ projectId: string }> = ({ projectId }) => {
  const { timeline, loading, error, overallProgress, getCriticalPathActivities } =
    useTimeline(projectId);
  const { isGenerating, progress: genProgress, currentStep } = useGenerationMonitor(projectId);

  const [selectedCategory, setSelectedCategory] = useState<ActivityCategory | 'all'>('all');
  const [viewMode, setViewMode] = useState<'list' | 'gantt'>('list');

  // Filtra attività per categoria
  const filteredActivities = useMemo(() => {
    if (!timeline) return [];
    if (selectedCategory === 'all') return timeline.activities;
    return timeline.activities.filter(act => act.category === selectedCategory);
  }, [timeline, selectedCategory]);

  // Raggruppa per status
  const activitiesByStatus = useMemo(() => {
    const groups = {
      not_started: [] as Activity[],
      in_progress: [] as Activity[],
      completed: [] as Activity[],
      blocked: [] as Activity[],
    };

    filteredActivities.forEach(act => {
      groups[act.status].push(act);
    });

    return groups;
  }, [filteredActivities]);

  const criticalPath = useMemo(() => getCriticalPathActivities(), [getCriticalPathActivities]);

  if (loading) {
    return (
      <div style={{ padding: '40px', textAlign: 'center' }}>
        <div className="spinner" />
        <p>Caricamento timeline...</p>
      </div>
    );
  }

  if (isGenerating) {
    return (
      <div style={{
        padding: '40px',
        textAlign: 'center',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        borderRadius: '12px',
        color: 'white',
        margin: '20px'
      }}>
        <div style={{ fontSize: '48px', marginBottom: '16px' }}>⚙️</div>
        <h3 style={{ margin: '0 0 16px 0' }}>Generazione Timeline in Corso...</h3>
        <div style={{
          background: 'rgba(255,255,255,0.2)',
          height: '24px',
          borderRadius: '12px',
          overflow: 'hidden',
          marginBottom: '12px'
        }}>
          <div style={{
            background: 'white',
            height: '100%',
            width: `${genProgress}%`,
            transition: 'width 0.3s'
          }} />
        </div>
        <p style={{ margin: 0, fontSize: '14px' }}>
          {currentStep} ({genProgress}%)
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        padding: '20px',
        background: '#ffebee',
        borderRadius: '8px',
        color: '#c62828',
        margin: '20px'
      }}>
        <strong>Errore:</strong> {error}
      </div>
    );
  }

  if (!timeline) {
    return (
      <div style={{
        padding: '40px',
        textAlign: 'center',
        background: '#f5f5f5',
        borderRadius: '12px',
        margin: '20px'
      }}>
        <div style={{ fontSize: '48px', marginBottom: '16px' }}>📋</div>
        <h3>Timeline non ancora generata</h3>
        <p style={{ color: '#666' }}>
          La timeline verrà generata automaticamente al completamento del preventivo.
        </p>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px' }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        borderRadius: '12px',
        padding: '24px',
        color: 'white',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h2 style={{ margin: '0 0 8px 0' }}>📅 Timeline Progetto</h2>
            <p style={{ margin: 0, opacity: 0.9, fontSize: '14px' }}>
              Durata: {timeline.totalDurationWeeks} settimane •
              Attività: {timeline.activities.length} •
              Milestone: {timeline.milestones.length}
            </p>
          </div>
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '12px',
            padding: '16px',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '32px', fontWeight: 'bold' }}>
              {overallProgress.toFixed(0)}%
            </div>
            <div style={{ fontSize: '12px', opacity: 0.9 }}>
              Avanzamento
            </div>
          </div>
        </div>

        {timeline.aiGenerated && (
          <div style={{
            marginTop: '16px',
            padding: '12px',
            background: 'rgba(255,255,255,0.15)',
            borderRadius: '8px',
            fontSize: '13px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            ✨ <span>Generato automaticamente da IA - Modificabile manualmente</span>
          </div>
        )}
      </div>

      {/* Filters */}
      <div style={{
        display: 'flex',
        gap: '12px',
        marginBottom: '24px',
        flexWrap: 'wrap'
      }}>
        <button
          onClick={() => setSelectedCategory('all')}
          style={{
            padding: '8px 16px',
            background: selectedCategory === 'all' ? '#667eea' : '#f5f5f5',
            color: selectedCategory === 'all' ? 'white' : '#333',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: selectedCategory === 'all' ? 'bold' : 'normal'
          }}
        >
          Tutte ({timeline.activities.length})
        </button>

        {Array.from(new Set(timeline.activities.map(a => a.category))).map(cat => {
          const count = timeline.activities.filter(a => a.category === cat).length;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              style={{
                padding: '8px 16px',
                background: selectedCategory === cat ? '#667eea' : '#f5f5f5',
                color: selectedCategory === cat ? 'white' : '#333',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: selectedCategory === cat ? 'bold' : 'normal'
              }}
            >
              {getCategoryLabel(cat)} ({count})
            </button>
          );
        })}
      </div>

      {/* View Mode Toggle */}
      <div style={{ marginBottom: '24px', display: 'flex', gap: '8px' }}>
        <button
          onClick={() => setViewMode('list')}
          style={{
            padding: '8px 16px',
            background: viewMode === 'list' ? '#667eea' : '#f5f5f5',
            color: viewMode === 'list' ? 'white' : '#333',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          📋 Lista
        </button>
        <button
          onClick={() => setViewMode('gantt')}
          style={{
            padding: '8px 16px',
            background: viewMode === 'gantt' ? '#667eea' : '#f5f5f5',
            color: viewMode === 'gantt' ? 'white' : '#333',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          📊 Gantt
        </button>
      </div>

      {/* Critical Path Alert */}
      {criticalPath.length > 0 && (
        <div style={{
          padding: '16px',
          background: '#fff3e0',
          borderLeft: '4px solid #ff9800',
          borderRadius: '4px',
          marginBottom: '24px'
        }}>
          <strong>⚠️ Percorso Critico:</strong> {criticalPath.length} attività critiche
          che determinano la durata del progetto
        </div>
      )}

      {/* Activities View */}
      {viewMode === 'list' ? (
        <ActivityListView
          activities={filteredActivities}
          criticalPath={criticalPath}
          projectId={projectId}
        />
      ) : (
        <GanttChartView
          activities={filteredActivities}
          totalWeeks={timeline.totalDurationWeeks}
          milestones={timeline.milestones}
        />
      )}

      {/* Milestones */}
      {timeline.milestones.length > 0 && (
        <div style={{ marginTop: '32px' }}>
          <h3 style={{ marginBottom: '16px' }}>🎯 Milestone & SAL</h3>
          <div style={{ display: 'grid', gap: '12px' }}>
            {timeline.milestones.map(milestone => (
              <div
                key={milestone.id}
                style={{
                  padding: '16px',
                  background: milestone.completed ? '#e8f5e9' : '#f5f5f5',
                  borderRadius: '8px',
                  borderLeft: `4px solid ${milestone.completed ? '#4caf50' : '#9e9e9e'}`
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <strong>{milestone.name}</strong>
                    {milestone.salNumber && (
                      <span style={{
                        marginLeft: '8px',
                        padding: '4px 8px',
                        background: '#667eea',
                        color: 'white',
                        borderRadius: '4px',
                        fontSize: '12px'
                      }}>
                        SAL {milestone.salNumber}
                      </span>
                    )}
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '14px', color: '#666' }}>
                      Settimana {milestone.week}
                    </div>
                    <div style={{ fontSize: '12px', color: '#999' }}>
                      {formatCurrency(milestone.expectedValue)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Componente Lista Attività
const ActivityListView: React.FC<{
  activities: Activity[];
  criticalPath: Activity[];
  projectId: string;
}> = ({ activities, criticalPath, projectId }) => {
  const [updatingActivity, setUpdatingActivity] = useState<string | null>(null);

  const handleProgressChange = async (activityId: string, newProgress: number) => {
    try {
      setUpdatingActivity(activityId);
      await updateActivityProgress(projectId, activityId, newProgress);
    } catch (error) {
      console.error('Error updating progress:', error);
      alert('Errore aggiornamento avanzamento');
    } finally {
      setUpdatingActivity(null);
    }
  };

  return (
    <div style={{ display: 'grid', gap: '16px' }}>
      {activities.map(activity => {
        const isCritical = criticalPath.some(a => a.id === activity.id);
        const isUpdating = updatingActivity === activity.id;

        return (
          <div
            key={activity.id}
            style={{
              padding: '20px',
              background: 'white',
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              border: isCritical ? '2px solid #ff9800' : '2px solid transparent'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '12px' }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                  <h4 style={{ margin: 0 }}>{activity.name}</h4>
                  {isCritical && (
                    <span style={{
                      padding: '4px 8px',
                      background: '#ff9800',
                      color: 'white',
                      borderRadius: '4px',
                      fontSize: '11px',
                      fontWeight: 'bold'
                    }}>
                      CRITICO
                    </span>
                  )}
                  {activity.aiGenerated && (
                    <span style={{
                      padding: '4px 8px',
                      background: '#667eea',
                      color: 'white',
                      borderRadius: '4px',
                      fontSize: '11px'
                    }}>
                      ✨ AI
                    </span>
                  )}
                </div>
                <div style={{ fontSize: '13px', color: '#666' }}>
                  {getCategoryLabel(activity.category)} • Sett. {activity.startWeek}-{activity.endWeek} ({activity.duration}w)
                </div>
              </div>

              <div style={{
                padding: '8px 12px',
                background: getStatusColor(activity.status),
                color: 'white',
                borderRadius: '6px',
                fontSize: '12px',
                fontWeight: 'bold',
                whiteSpace: 'nowrap'
              }}>
                {getStatusLabel(activity.status)}
              </div>
            </div>

            {/* Progress Bar */}
            <div style={{ marginBottom: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px', fontSize: '13px' }}>
                <span>Avanzamento</span>
                <span style={{ fontWeight: 'bold' }}>{activity.progress}%</span>
              </div>
              <div style={{
                height: '24px',
                background: '#e0e0e0',
                borderRadius: '12px',
                overflow: 'hidden',
                position: 'relative'
              }}>
                <div style={{
                  height: '100%',
                  width: `${activity.progress}%`,
                  background: 'linear-gradient(90deg, #667eea 0%, #764ba2 100%)',
                  transition: 'width 0.3s'
                }} />
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={activity.progress}
                  onChange={(e) => handleProgressChange(activity.id, parseInt(e.target.value))}
                  disabled={isUpdating}
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    opacity: 0,
                    cursor: 'pointer'
                  }}
                />
              </div>
            </div>

            {/* Costs */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '12px',
              fontSize: '13px'
            }}>
              <div>
                <div style={{ color: '#666', marginBottom: '4px' }}>Previsto</div>
                <div style={{ fontWeight: 'bold' }}>{formatCurrency(activity.estimatedCost)}</div>
              </div>
              <div>
                <div style={{ color: '#666', marginBottom: '4px' }}>Effettivo</div>
                <div style={{ fontWeight: 'bold' }}>{formatCurrency(activity.actualCost)}</div>
              </div>
              <div>
                <div style={{ color: '#666', marginBottom: '4px' }}>Varianza</div>
                <div style={{
                  fontWeight: 'bold',
                  color: activity.variance > 0 ? '#f44336' : activity.variance < 0 ? '#4caf50' : '#666'
                }}>
                  {activity.variance > 0 ? '+' : ''}{formatCurrency(activity.variance)}
                </div>
              </div>
            </div>

            {activity.notes && (
              <div style={{
                marginTop: '12px',
                padding: '12px',
                background: '#f5f5f5',
                borderRadius: '6px',
                fontSize: '13px',
                color: '#666'
              }}>
                💬 {activity.notes}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

// Componente Gantt Chart (semplificato)
const GanttChartView: React.FC<{
  activities: Activity[];
  totalWeeks: number;
  milestones: any[];
}> = ({ activities, totalWeeks, milestones }) => {
  const maxWeek = Math.max(totalWeeks, ...activities.map(a => a.endWeek));

  return (
    <div style={{
      background: 'white',
      borderRadius: '12px',
      padding: '20px',
      overflowX: 'auto'
    }}>
      <div style={{ minWidth: '800px' }}>
        {/* Header settimane */}
        <div style={{ display: 'flex', marginBottom: '16px', paddingLeft: '200px' }}>
          {Array.from({ length: maxWeek }, (_, i) => (
            <div
              key={i}
              style={{
                flex: 1,
                textAlign: 'center',
                fontSize: '12px',
                padding: '8px',
                borderLeft: '1px solid #e0e0e0',
                background: '#f5f5f5',
                fontWeight: 'bold'
              }}
            >
              W{i + 1}
            </div>
          ))}
        </div>

        {/* Attività */}
        {activities.map(activity => (
          <div key={activity.id} style={{ display: 'flex', marginBottom: '8px', alignItems: 'center' }}>
            <div style={{
              width: '200px',
              fontSize: '13px',
              paddingRight: '12px',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap'
            }}>
              {activity.name}
            </div>
            <div style={{ flex: 1, position: 'relative', height: '32px' }}>
              <div
                style={{
                  position: 'absolute',
                  left: `${(activity.startWeek / maxWeek) * 100}%`,
                  width: `${(activity.duration / maxWeek) * 100}%`,
                  height: '100%',
                  background: `linear-gradient(90deg, ${getActivityColor(activity.category)} 0%, ${getActivityColor(activity.category)}dd 100%)`,
                  borderRadius: '4px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '11px',
                  color: 'white',
                  fontWeight: 'bold',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.2)'
                }}
              >
                {activity.progress}%
              </div>
            </div>
          </div>
        ))}

        {/* Milestones */}
        {milestones.map(milestone => (
          <div
            key={milestone.id}
            style={{
              position: 'absolute',
              left: `calc(200px + ${(milestone.week / maxWeek) * 100}%)`,
              width: '2px',
              height: '100%',
              background: '#ff9800',
              top: 0
            }}
            title={milestone.name}
          />
        ))}
      </div>
    </div>
  );
};

// Utility functions
function getCategoryLabel(category: ActivityCategory): string {
  const labels: Record<ActivityCategory, string> = {
    demolizioni: '🔨 Demolizioni',
    impianti_idraulici: '🚰 Impianti Idraulici',
    impianti_elettrici: '⚡ Impianti Elettrici',
    murature: '🧱 Murature',
    intonaci: '🎨 Intonaci',
    pavimenti: '⬜ Pavimenti',
    rivestimenti: '🏗️ Rivestimenti',
    serramenti: '🚪 Serramenti',
    finiture: '✨ Finiture',
    imbiancatura: '🖌️ Imbiancatura',
    altro: '📦 Altro',
  };
  return labels[category] || category;
}

function getStatusLabel(status: Activity['status']): string {
  const labels = {
    not_started: 'Non Iniziata',
    in_progress: 'In Corso',
    completed: 'Completata',
    blocked: 'Bloccata',
  };
  return labels[status];
}

function getStatusColor(status: Activity['status']): string {
  const colors = {
    not_started: '#9e9e9e',
    in_progress: '#2196f3',
    completed: '#4caf50',
    blocked: '#f44336',
  };
  return colors[status];
}

function getActivityColor(category: ActivityCategory): string {
  const colors: Record<ActivityCategory, string> = {
    demolizioni: '#f44336',
    impianti_idraulici: '#2196f3',
    impianti_elettrici: '#ff9800',
    murature: '#795548',
    intonaci: '#9c27b0',
    pavimenti: '#607d8b',
    rivestimenti: '#00bcd4',
    serramenti: '#3f51b5',
    finiture: '#4caf50',
    imbiancatura: '#ffeb3b',
    altro: '#9e9e9e',
  };
  return colors[category] || '#9e9e9e';
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export default TimelineView;
