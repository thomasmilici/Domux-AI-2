/**
 * Componente per gestione spese progetto (Tier 2+)
 * Tracciamento spese con collegamento ad attività timeline
 * Versione 0.5 - Sistema IA-Driven
 */

import React, { useState } from 'react';
import { TierGuard } from '../subscription/TierGuard';
import { useExpenses, useTimeline } from '../../hooks/useProjectSync';
import { addExpense } from '../../services/projectManagementService';
import type { User } from '../../services/firebase';
import type { Expense, ExpenseCategory } from '../../types/projectManagement';

interface ExpensesViewProps {
  user: User;
  projectId: string;
}

const ExpensesView: React.FC<ExpensesViewProps> = ({ user, projectId }) => {
  return (
    <TierGuard user={user} requiredTier="basic" showUpgradeMessage={true}>
      <ExpensesContent projectId={projectId} />
    </TierGuard>
  );
};

const ExpensesContent: React.FC<{ projectId: string }> = ({ projectId }) => {
  const { expenses, loading, totalExpenses, totalPaid, totalUnpaid, byCategory } =
    useExpenses(projectId);
  const { timeline } = useTimeline(projectId);

  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState<Partial<Expense>>({
    description: '',
    category: 'materiali',
    amount: 0,
    paid: false,
  });
  const [saving, setSaving] = useState(false);

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.description || !formData.amount || formData.amount <= 0) {
      alert('Compila tutti i campi obbligatori');
      return;
    }

    try {
      setSaving(true);
      await addExpense(projectId, {
        description: formData.description,
        category: formData.category as ExpenseCategory,
        amount: formData.amount,
        linkedActivityId: formData.linkedActivityId,
        paid: formData.paid || false,
        date: new Date() as any,
        notes: formData.notes,
      });

      // Reset form
      setFormData({
        description: '',
        category: 'materiali',
        amount: 0,
        paid: false,
      });
      setShowAddForm(false);
    } catch (error) {
      console.error('Error adding expense:', error);
      alert('Errore durante l\'aggiunta della spesa');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: '40px', textAlign: 'center' }}>
        <div className="spinner" />
        <p>Caricamento spese...</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px' }}>
      {/* Header con riepilogo */}
      <div style={{
        background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
        borderRadius: '12px',
        padding: '24px',
        color: 'white',
        marginBottom: '24px'
      }}>
        <h2 style={{ margin: '0 0 16px 0' }}>💰 Gestione Spese</h2>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
          gap: '16px'
        }}>
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '8px',
            padding: '16px'
          }}>
            <div style={{ fontSize: '12px', opacity: 0.9, marginBottom: '4px' }}>
              Totale Spese
            </div>
            <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
              {formatCurrency(totalExpenses)}
            </div>
          </div>

          <div style={{
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '8px',
            padding: '16px'
          }}>
            <div style={{ fontSize: '12px', opacity: 0.9, marginBottom: '4px' }}>
              Pagate
            </div>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#4caf50' }}>
              {formatCurrency(totalPaid)}
            </div>
          </div>

          <div style={{
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '8px',
            padding: '16px'
          }}>
            <div style={{ fontSize: '12px', opacity: 0.9, marginBottom: '4px' }}>
              Da Pagare
            </div>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ff9800' }}>
              {formatCurrency(totalUnpaid)}
            </div>
          </div>
        </div>
      </div>

      {/* Breakdown per categoria */}
      <div style={{
        background: 'white',
        borderRadius: '12px',
        padding: '20px',
        marginBottom: '24px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <h3 style={{ marginTop: 0 }}>📊 Spese per Categoria</h3>
        <div style={{ display: 'grid', gap: '12px' }}>
          {Object.entries(byCategory).map(([category, amount]) => {
            const percentage = totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0;
            return (
              <div key={category}>
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  marginBottom: '4px',
                  fontSize: '14px'
                }}>
                  <span>{getCategoryLabel(category as ExpenseCategory)}</span>
                  <span style={{ fontWeight: 'bold' }}>
                    {formatCurrency(amount)} ({percentage.toFixed(1)}%)
                  </span>
                </div>
                <div style={{
                  height: '8px',
                  background: '#e0e0e0',
                  borderRadius: '4px',
                  overflow: 'hidden'
                }}>
                  <div style={{
                    height: '100%',
                    width: `${percentage}%`,
                    background: getCategoryColor(category as ExpenseCategory),
                    transition: 'width 0.3s'
                  }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Pulsante aggiungi */}
      <div style={{ marginBottom: '24px' }}>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          style={{
            padding: '12px 24px',
            background: '#667eea',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            fontSize: '16px',
            fontWeight: 'bold',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
        >
          <span style={{ fontSize: '20px' }}>+</span>
          Aggiungi Spesa
        </button>
      </div>

      {/* Form aggiungi spesa */}
      {showAddForm && (
        <div style={{
          background: 'white',
          borderRadius: '12px',
          padding: '24px',
          marginBottom: '24px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ marginTop: 0 }}>➕ Nuova Spesa</h3>
          <form onSubmit={handleAddExpense}>
            <div style={{ display: 'grid', gap: '16px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                  Descrizione *
                </label>
                <input
                  type="text"
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Es: Acquisto cemento per fondazioni"
                  required
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '1px solid #ddd',
                    borderRadius: '8px',
                    fontSize: '14px'
                  }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    Categoria *
                  </label>
                  <select
                    value={formData.category || 'materiali'}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as ExpenseCategory })}
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '1px solid #ddd',
                      borderRadius: '8px',
                      fontSize: '14px'
                    }}
                  >
                    <option value="personale">Personale</option>
                    <option value="materiali">Materiali</option>
                    <option value="noleggi">Noleggi</option>
                    <option value="subappalti">Subappalti</option>
                    <option value="spese_generali">Spese Generali</option>
                    <option value="altro">Altro</option>
                  </select>
                </div>

                <div>
                  <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                    Importo (€) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.amount || 0}
                    onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) })}
                    required
                    style={{
                      width: '100%',
                      padding: '12px',
                      border: '1px solid #ddd',
                      borderRadius: '8px',
                      fontSize: '14px'
                    }}
                  />
                </div>
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                  Collega ad Attività (opzionale)
                </label>
                <select
                  value={formData.linkedActivityId || ''}
                  onChange={(e) => setFormData({ ...formData, linkedActivityId: e.target.value || undefined })}
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '1px solid #ddd',
                    borderRadius: '8px',
                    fontSize: '14px'
                  }}
                >
                  <option value="">Nessuna attività</option>
                  {timeline?.activities.map(act => (
                    <option key={act.id} value={act.id}>
                      {act.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <input
                    type="checkbox"
                    checked={formData.paid || false}
                    onChange={(e) => setFormData({ ...formData, paid: e.target.checked })}
                  />
                  <span>Spesa già pagata</span>
                </label>
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                  Note (opzionale)
                </label>
                <textarea
                  value={formData.notes || ''}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '1px solid #ddd',
                    borderRadius: '8px',
                    fontSize: '14px',
                    resize: 'vertical'
                  }}
                />
              </div>

              <div style={{ display: 'flex', gap: '12px' }}>
                <button
                  type="submit"
                  disabled={saving}
                  style={{
                    padding: '12px 24px',
                    background: '#4caf50',
                    color: 'white',
                    border: 'none',
                    borderRadius: '8px',
                    fontSize: '16px',
                    fontWeight: 'bold',
                    cursor: saving ? 'not-allowed' : 'pointer',
                    opacity: saving ? 0.6 : 1
                  }}
                >
                  {saving ? 'Salvataggio...' : '💾 Salva'}
                </button>

                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  style={{
                    padding: '12px 24px',
                    background: '#9e9e9e',
                    color: 'white',
                    border: 'none',
                    borderRadius: '8px',
                    fontSize: '16px',
                    cursor: 'pointer'
                  }}
                >
                  Annulla
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Lista spese */}
      <div style={{
        background: 'white',
        borderRadius: '12px',
        padding: '20px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <h3 style={{ marginTop: 0 }}>📝 Elenco Spese ({expenses.length})</h3>

        {expenses.length === 0 ? (
          <div style={{
            padding: '40px',
            textAlign: 'center',
            color: '#999'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>📭</div>
            <p>Nessuna spesa registrata</p>
            <p style={{ fontSize: '14px' }}>
              Le spese previste dall'IA appariranno qui automaticamente
            </p>
          </div>
        ) : (
          <div style={{ display: 'grid', gap: '12px' }}>
            {expenses
              .sort((a, b) => b.date.seconds - a.date.seconds)
              .map(expense => (
                <div
                  key={expense.id}
                  style={{
                    padding: '16px',
                    background: '#f9f9f9',
                    borderRadius: '8px',
                    borderLeft: `4px solid ${getCategoryColor(expense.category)}`
                  }}
                >
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'start',
                    marginBottom: '8px'
                  }}>
                    <div style={{ flex: 1 }}>
                      <div style={{
                        fontWeight: 'bold',
                        marginBottom: '4px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                      }}>
                        {expense.description}
                        {expense.aiSuggested && (
                          <span style={{
                            padding: '2px 6px',
                            background: '#667eea',
                            color: 'white',
                            borderRadius: '4px',
                            fontSize: '10px'
                          }}>
                            ✨ AI
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: '13px', color: '#666' }}>
                        {getCategoryLabel(expense.category)} •{' '}
                        {formatDate(expense.date)}
                        {expense.linkedActivityId && timeline && (
                          <> • 🔗 {timeline.activities.find(a => a.id === expense.linkedActivityId)?.name}</>
                        )}
                      </div>
                    </div>

                    <div style={{ textAlign: 'right' }}>
                      <div style={{
                        fontSize: '20px',
                        fontWeight: 'bold',
                        marginBottom: '4px'
                      }}>
                        {formatCurrency(expense.amount)}
                      </div>
                      <div style={{
                        padding: '4px 8px',
                        background: expense.paid ? '#4caf50' : '#ff9800',
                        color: 'white',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: 'bold'
                      }}>
                        {expense.paid ? '✓ Pagata' : '⏳ Da Pagare'}
                      </div>
                    </div>
                  </div>

                  {expense.notes && (
                    <div style={{
                      marginTop: '8px',
                      padding: '8px',
                      background: '#fff',
                      borderRadius: '4px',
                      fontSize: '13px',
                      color: '#666'
                    }}>
                      💬 {expense.notes}
                    </div>
                  )}
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Utility functions
function getCategoryLabel(category: ExpenseCategory): string {
  const labels: Record<ExpenseCategory, string> = {
    personale: '👷 Personale',
    materiali: '🧱 Materiali',
    noleggi: '🚜 Noleggi',
    subappalti: '🤝 Subappalti',
    spese_generali: '📋 Spese Generali',
    altro: '📦 Altro',
  };
  return labels[category] || category;
}

function getCategoryColor(category: ExpenseCategory): string {
  const colors: Record<ExpenseCategory, string> = {
    personale: '#2196f3',
    materiali: '#795548',
    noleggi: '#ff9800',
    subappalti: '#9c27b0',
    spese_generali: '#607d8b',
    altro: '#9e9e9e',
  };
  return colors[category] || '#9e9e9e';
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function formatDate(timestamp: any): string {
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return new Intl.DateTimeFormat('it-IT', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date);
}

export default ExpensesView;
