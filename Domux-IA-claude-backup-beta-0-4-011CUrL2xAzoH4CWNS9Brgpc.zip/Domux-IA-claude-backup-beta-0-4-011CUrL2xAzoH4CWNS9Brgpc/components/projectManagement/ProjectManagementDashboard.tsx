/**
 * Dashboard completa Project Management (Tier 2+)
 * Hub centrale per Timeline, Spese, SAL
 * Versione 0.5 - Sistema IA-Driven
 */

import React, { useState } from 'react';
import { TierGuard, useTierAccess } from '../subscription/TierGuard';
import TimelineView from './TimelineView';
import ExpensesView from './ExpensesView';
import type { User } from '../../services/firebase';

interface ProjectManagementDashboardProps {
  user: User;
  projectId: string;
  onClose?: () => void;
}

type TabView = 'overview' | 'timeline' | 'expenses' | 'sal';

const ProjectManagementDashboard: React.FC<ProjectManagementDashboardProps> = ({
  user,
  projectId,
  onClose,
}) => {
  return (
    <TierGuard user={user} requiredTier="basic" showUpgradeMessage={true}>
      <DashboardContent user={user} projectId={projectId} onClose={onClose} />
    </TierGuard>
  );
};

const DashboardContent: React.FC<{
  user: User;
  projectId: string;
  onClose?: () => void;
}> = ({ user, projectId, onClose }) => {
  const [activeTab, setActiveTab] = useState<TabView>('overview');
  const { features } = useTierAccess(user);

  return (
    <div style={{
      minHeight: '100vh',
      background: '#f5f5f5'
    }}>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        color: 'white',
        padding: '24px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
      }}>
        <div style={{
          maxWidth: '1400px',
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <h1 style={{ margin: '0 0 8px 0', fontSize: '28px' }}>
              🏗️ Project Management
            </h1>
            <p style={{ margin: 0, opacity: 0.9, fontSize: '14px' }}>
              Gestione completa timeline, spese e avanzamento lavori
            </p>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              style={{
                padding: '10px 20px',
                background: 'rgba(255,255,255,0.2)',
                border: '1px solid rgba(255,255,255,0.3)',
                borderRadius: '8px',
                color: 'white',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: 'bold'
              }}
            >
              ← Torna al Progetto
            </button>
          )}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div style={{
        background: 'white',
        borderBottom: '2px solid #e0e0e0',
        position: 'sticky',
        top: 0,
        zIndex: 10
      }}>
        <div style={{
          maxWidth: '1400px',
          margin: '0 auto',
          display: 'flex',
          gap: '8px',
          padding: '0 24px'
        }}>
          <TabButton
            active={activeTab === 'overview'}
            onClick={() => setActiveTab('overview')}
            icon="📊"
            label="Panoramica"
          />
          <TabButton
            active={activeTab === 'timeline'}
            onClick={() => setActiveTab('timeline')}
            icon="📅"
            label="Timeline"
            tier={2}
          />
          <TabButton
            active={activeTab === 'expenses'}
            onClick={() => setActiveTab('expenses')}
            icon="💰"
            label="Spese"
            tier={2}
          />
          <TabButton
            active={activeTab === 'sal'}
            onClick={() => setActiveTab('sal')}
            icon="📝"
            label="Brogliaccio SAL"
            tier={2}
            disabled
          />
        </div>
      </div>

      {/* Content */}
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto'
      }}>
        {activeTab === 'overview' && <OverviewTab projectId={projectId} />}
        {activeTab === 'timeline' && <TimelineView user={user} projectId={projectId} />}
        {activeTab === 'expenses' && <ExpensesView user={user} projectId={projectId} />}
        {activeTab === 'sal' && (
          <div style={{ padding: '40px', textAlign: 'center' }}>
            <div style={{ fontSize: '64px', marginBottom: '16px' }}>🚧</div>
            <h2>In Fase di Sviluppo</h2>
            <p style={{ color: '#666' }}>
              Il componente Brogliaccio SAL sarà disponibile nella prossima release
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

// Tab Button Component
const TabButton: React.FC<{
  active: boolean;
  onClick: () => void;
  icon: string;
  label: string;
  tier?: number;
  disabled?: boolean;
}> = ({ active, onClick, icon, label, tier, disabled }) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        padding: '16px 24px',
        background: active ? '#667eea' : 'transparent',
        color: active ? 'white' : disabled ? '#ccc' : '#333',
        border: 'none',
        borderBottom: active ? '3px solid #667eea' : '3px solid transparent',
        cursor: disabled ? 'not-allowed' : 'pointer',
        fontSize: '16px',
        fontWeight: active ? 'bold' : 'normal',
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        transition: 'all 0.2s'
      }}
    >
      <span style={{ fontSize: '20px' }}>{icon}</span>
      <span>{label}</span>
      {tier && tier > 1 && (
        <span style={{
          padding: '2px 6px',
          background: active ? 'rgba(255,255,255,0.2)' : '#667eea',
          color: 'white',
          borderRadius: '4px',
          fontSize: '10px',
          fontWeight: 'bold'
        }}>
          Tier {tier}
        </span>
      )}
    </button>
  );
};

// Overview Tab
const OverviewTab: React.FC<{ projectId: string }> = ({ projectId }) => {
  return (
    <div style={{ padding: '24px' }}>
      <div style={{
        background: 'white',
        borderRadius: '12px',
        padding: '32px',
        textAlign: 'center',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <div style={{ fontSize: '64px', marginBottom: '24px' }}>✨</div>
        <h2 style={{ margin: '0 0 16px 0' }}>
          Sistema di Project Management IA-Driven
        </h2>
        <p style={{ color: '#666', maxWidth: '600px', margin: '0 auto 32px', lineHeight: '1.6' }}>
          Tutti i dati del tuo progetto vengono generati automaticamente dall'intelligenza artificiale
          per offrirti una pianificazione completa e professionale fin dal primo momento.
        </p>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '24px',
          marginTop: '32px'
        }}>
          <FeatureCard
            icon="📅"
            title="Timeline Automatica"
            description="Sequenziamento attività con durate realistiche e dipendenze"
          />
          <FeatureCard
            icon="💰"
            title="Previsione Spese"
            description="Distribuzione temporale costi e cash flow previsto"
          />
          <FeatureCard
            icon="📝"
            title="SAL Previsti"
            description="Stati Avanzamento Lavori calcolati automaticamente"
          />
          <FeatureCard
            icon="📊"
            title="Analisi Rischi"
            description="Identificazione criticità e suggerimenti mitigazione"
          />
        </div>

        <div style={{
          marginTop: '48px',
          padding: '24px',
          background: '#f5f5f5',
          borderRadius: '12px'
        }}>
          <h3 style={{ margin: '0 0 12px 0' }}>🚀 Come Funziona</h3>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '16px',
            marginTop: '24px',
            textAlign: 'left'
          }}>
            <div>
              <div style={{
                width: '40px',
                height: '40px',
                background: '#667eea',
                color: 'white',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                marginBottom: '12px'
              }}>
                1
              </div>
              <strong>Crei il Preventivo</strong>
              <p style={{ fontSize: '14px', color: '#666', margin: '4px 0 0 0' }}>
                Inserisci le voci di lavorazione come sempre
              </p>
            </div>

            <div>
              <div style={{
                width: '40px',
                height: '40px',
                background: '#667eea',
                color: 'white',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                marginBottom: '12px'
              }}>
                2
              </div>
              <strong>IA Analizza</strong>
              <p style={{ fontSize: '14px', color: '#666', margin: '4px 0 0 0' }}>
                L'intelligenza artificiale studia il progetto
              </p>
            </div>

            <div>
              <div style={{
                width: '40px',
                height: '40px',
                background: '#667eea',
                color: 'white',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                marginBottom: '12px'
              }}>
                3
              </div>
              <strong>Dati Generati</strong>
              <p style={{ fontSize: '14px', color: '#666', margin: '4px 0 0 0' }}>
                Timeline, spese e SAL pronti all'uso
              </p>
            </div>

            <div>
              <div style={{
                width: '40px',
                height: '40px',
                background: '#667eea',
                color: 'white',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                marginBottom: '12px'
              }}>
                4
              </div>
              <strong>Traccia Realtà</strong>
              <p style={{ fontSize: '14px', color: '#666', margin: '4px 0 0 0' }}>
                Confronta avanzamento reale vs previsto
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Feature Card
const FeatureCard: React.FC<{
  icon: string;
  title: string;
  description: string;
}> = ({ icon, title, description }) => {
  return (
    <div style={{
      padding: '24px',
      background: '#f9f9f9',
      borderRadius: '12px',
      textAlign: 'center'
    }}>
      <div style={{ fontSize: '48px', marginBottom: '12px' }}>{icon}</div>
      <h4 style={{ margin: '0 0 8px 0' }}>{title}</h4>
      <p style={{ fontSize: '14px', color: '#666', margin: 0, lineHeight: '1.5' }}>
        {description}
      </p>
    </div>
  );
};

export default ProjectManagementDashboard;
