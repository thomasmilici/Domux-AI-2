/**
 * Componente per visualizzare i piani di pricing
 * Versione 0.5
 */

import React from 'react';
import type { User } from '../../services/firebase';
import type { SubscriptionTier } from '../../types/subscription';
import { TIER_CONFIG } from '../../types/subscription';
import { getEffectiveTier } from '../../services/subscriptionService';

interface PricingPlansProps {
  user?: User;
  onSelectPlan?: (tier: SubscriptionTier) => void;
}

const PricingPlans: React.FC<PricingPlansProps> = ({ user, onSelectPlan }) => {
  const currentTier = user ? getEffectiveTier(user) : null;

  // Escludi free_trial dai piani visibili
  const plans: SubscriptionTier[] = ['basic', 'professional', 'enterprise'];

  const handleSelectPlan = (tier: SubscriptionTier) => {
    if (onSelectPlan) {
      onSelectPlan(tier);
    } else {
      // TODO: Integrazione PayPal
      alert(`Hai selezionato il piano ${TIER_CONFIG[tier].displayName}. L'integrazione PayPal sarà disponibile a breve.`);
    }
  };

  return (
    <div style={{ padding: '40px 20px' }}>
      <h2 style={{ textAlign: 'center', fontSize: '32px', fontWeight: 'bold', marginBottom: '12px' }}>
        Scegli il Piano Perfetto per Te
      </h2>
      <p style={{ textAlign: 'center', color: '#666', marginBottom: '40px', fontSize: '16px' }}>
        Tutti i piani includono 7 giorni di prova gratuita
      </p>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '24px',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        {plans.map(tier => {
          const config = TIER_CONFIG[tier];
          const isCurrentPlan = currentTier === tier;
          const isProfessional = tier === 'professional';

          return (
            <div
              key={tier}
              style={{
                background: isProfessional
                  ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  : 'white',
                color: isProfessional ? 'white' : '#333',
                borderRadius: '16px',
                padding: '32px',
                boxShadow: isProfessional
                  ? '0 20px 40px rgba(102, 126, 234, 0.4)'
                  : '0 4px 12px rgba(0,0,0,0.1)',
                border: isProfessional ? 'none' : '2px solid #e0e0e0',
                position: 'relative',
                transform: isProfessional ? 'scale(1.05)' : 'scale(1)',
                transition: 'transform 0.2s'
              }}
            >
              {isProfessional && (
                <div style={{
                  position: 'absolute',
                  top: '-12px',
                  right: '20px',
                  background: '#f5576c',
                  color: 'white',
                  padding: '6px 16px',
                  borderRadius: '20px',
                  fontSize: '12px',
                  fontWeight: 'bold'
                }}>
                  PIÙ POPOLARE
                </div>
              )}

              {isCurrentPlan && (
                <div style={{
                  position: 'absolute',
                  top: '-12px',
                  left: '20px',
                  background: '#4caf50',
                  color: 'white',
                  padding: '6px 16px',
                  borderRadius: '20px',
                  fontSize: '12px',
                  fontWeight: 'bold'
                }}>
                  PIANO ATTUALE
                </div>
              )}

              <div style={{ textAlign: 'center', marginBottom: '24px' }}>
                <h3 style={{
                  fontSize: '28px',
                  fontWeight: 'bold',
                  margin: '0 0 8px 0',
                  color: isProfessional ? 'white' : '#333'
                }}>
                  {config.displayName}
                </h3>
                <div style={{ fontSize: '48px', fontWeight: 'bold', margin: '16px 0 8px 0' }}>
                  €{config.monthlyPrice}
                </div>
                <div style={{
                  fontSize: '14px',
                  opacity: 0.8,
                  color: isProfessional ? 'white' : '#666'
                }}>
                  al mese
                </div>
                {config.yearlyPrice && (
                  <div style={{
                    fontSize: '12px',
                    marginTop: '8px',
                    opacity: 0.7,
                    color: isProfessional ? 'white' : '#666'
                  }}>
                    o €{config.yearlyPrice}/anno (risparmi 2 mesi)
                  </div>
                )}
              </div>

              <ul style={{
                listStyle: 'none',
                padding: 0,
                margin: '0 0 24px 0',
                fontSize: '14px'
              }}>
                <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                  <span style={{ marginRight: '8px' }}>✅</span>
                  <span>
                    {config.maxProjectsPerMonth === -1 ? 'Progetti illimitati' : `${config.maxProjectsPerMonth} progetti/mese`}
                  </span>
                </li>
                <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                  <span style={{ marginRight: '8px' }}>✅</span>
                  <span>
                    {config.maxSessionsActive === -1 ? 'Sessioni illimitate' : `${config.maxSessionsActive} sessioni attive`}
                  </span>
                </li>
                <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                  <span style={{ marginRight: '8px' }}>✅</span>
                  <span>
                    {config.maxImageUploadsPerProject === -1 ? 'Immagini illimitate' : `${config.maxImageUploadsPerProject} immagini/progetto`}
                  </span>
                </li>
                <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                  <span style={{ marginRight: '8px' }}>✅</span>
                  <span>Export PDF professionale</span>
                </li>
                <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                  <span style={{ marginRight: '8px' }}>✅</span>
                  <span>Assistente AI</span>
                </li>
                {config.canAccessAdvancedServices && (
                  <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                    <span style={{ marginRight: '8px' }}>✅</span>
                    <span>Servizi avanzati</span>
                  </li>
                )}
                {config.canAccessPremiumServices && (
                  <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                    <span style={{ marginRight: '8px' }}>✅</span>
                    <span>Servizi premium esclusivi</span>
                  </li>
                )}
                {config.prioritySupport && (
                  <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                    <span style={{ marginRight: '8px' }}>✅</span>
                    <span>Supporto prioritario</span>
                  </li>
                )}
                {config.customBranding && (
                  <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                    <span style={{ marginRight: '8px' }}>✅</span>
                    <span>Logo personalizzato</span>
                  </li>
                )}
                {config.apiAccess && (
                  <li style={{ padding: '8px 0', display: 'flex', alignItems: 'center' }}>
                    <span style={{ marginRight: '8px' }}>✅</span>
                    <span>Accesso API</span>
                  </li>
                )}
              </ul>

              <button
                onClick={() => handleSelectPlan(tier)}
                disabled={isCurrentPlan}
                style={{
                  width: '100%',
                  padding: '14px',
                  backgroundColor: isCurrentPlan
                    ? '#ccc'
                    : isProfessional
                      ? 'white'
                      : '#667eea',
                  color: isCurrentPlan
                    ? '#666'
                    : isProfessional
                      ? '#667eea'
                      : 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '16px',
                  fontWeight: 'bold',
                  cursor: isCurrentPlan ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => {
                  if (!isCurrentPlan) {
                    e.currentTarget.style.transform = 'scale(1.02)';
                  }
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'scale(1)';
                }}
              >
                {isCurrentPlan ? 'Piano Attuale' : 'Seleziona Piano'}
              </button>
            </div>
          );
        })}
      </div>

      <div style={{
        textAlign: 'center',
        marginTop: '40px',
        padding: '24px',
        backgroundColor: '#f5f5f5',
        borderRadius: '12px',
        maxWidth: '800px',
        margin: '40px auto 0'
      }}>
        <h3 style={{ fontSize: '20px', marginBottom: '12px' }}>🎁 Prova Gratuita di 7 Giorni</h3>
        <p style={{ color: '#666', margin: 0 }}>
          Tutti i nuovi utenti ricevono automaticamente 7 giorni di prova gratuita per esplorare tutte le funzionalità.
          Nessuna carta di credito richiesta per iniziare!
        </p>
      </div>
    </div>
  );
};

export default PricingPlans;
