/**
 * Componente per visualizzare lo stato della subscription
 * Versione 0.5
 */

import React from 'react';
import type { User } from '../../services/firebase';
import {
  getEffectiveTier,
  getUserTierFeatures,
  getSubscriptionStatusMessage,
  getTrialDaysRemaining,
  isSubscriptionActive
} from '../../services/subscriptionService';
import { TIER_CONFIG } from '../../types/subscription';

interface SubscriptionStatusProps {
  user: User;
  showDetails?: boolean;
}

const SubscriptionStatus: React.FC<SubscriptionStatusProps> = ({ user, showDetails = false }) => {
  const tier = getEffectiveTier(user);
  const features = getUserTierFeatures(user);
  const statusMessage = getSubscriptionStatusMessage(user);
  const isActive = isSubscriptionActive(user.subscription);
  const tierConfig = TIER_CONFIG[tier];

  // Colori per ogni tier
  const tierColors = {
    free_trial: { bg: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', icon: '🎁' },
    basic: { bg: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', icon: '⭐' },
    professional: { bg: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', icon: '💎' },
    enterprise: { bg: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', icon: '👑' }
  };

  const colors = tierColors[tier];
  const daysRemaining = tier === 'free_trial' ? getTrialDaysRemaining(user.subscription) : null;

  return (
    <div
      style={{
        background: colors.bg,
        borderRadius: '12px',
        padding: '20px',
        color: 'white',
        marginBottom: '20px'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ fontSize: '32px' }}>{colors.icon}</span>
            <div>
              <h3 style={{ margin: 0, fontSize: '24px', fontWeight: 'bold' }}>
                {features.displayName}
              </h3>
              <p style={{ margin: '4px 0 0 0', fontSize: '14px', opacity: 0.9 }}>
                {statusMessage}
              </p>
            </div>
          </div>

          {tier === 'free_trial' && daysRemaining !== null && (
            <div style={{ marginTop: '12px', fontSize: '14px', opacity: 0.95 }}>
              {daysRemaining > 0 ? (
                <>
                  ⏱️ <strong>{daysRemaining}</strong> {daysRemaining === 1 ? 'giorno rimanente' : 'giorni rimanenti'}
                </>
              ) : (
                <>⚠️ Prova gratuita scaduta</>
              )}
            </div>
          )}
        </div>

        {tier === 'free_trial' && (
          <button
            style={{
              padding: '10px 20px',
              backgroundColor: 'white',
              color: '#667eea',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              boxShadow: '0 4px 12px rgba(0,0,0,0.2)'
            }}
            onClick={() => {
              // TODO: Navigare alla pagina di upgrade
              alert('La pagina di upgrade sarà disponibile a breve con l\'integrazione PayPal');
            }}
          >
            Effettua l'Upgrade
          </button>
        )}
      </div>

      {showDetails && (
        <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid rgba(255,255,255,0.2)' }}>
          <h4 style={{ margin: '0 0 12px 0', fontSize: '16px' }}>Piano Attuale:</h4>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px', fontSize: '13px' }}>
            <div>
              📁 Progetti/mese: <strong>{features.maxProjectsPerMonth === -1 ? 'Illimitati' : features.maxProjectsPerMonth}</strong>
            </div>
            <div>
              🔄 Sessioni attive: <strong>{features.maxSessionsActive === -1 ? 'Illimitate' : features.maxSessionsActive}</strong>
            </div>
            <div>
              🖼️ Immagini/progetto: <strong>{features.maxImageUploadsPerProject === -1 ? 'Illimitate' : features.maxImageUploadsPerProject}</strong>
            </div>
            <div>
              {features.prioritySupport ? '✅' : '❌'} Supporto prioritario
            </div>
            <div>
              {features.customBranding ? '✅' : '❌'} Logo personalizzato
            </div>
            <div>
              {features.apiAccess ? '✅' : '❌'} Accesso API
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionStatus;
