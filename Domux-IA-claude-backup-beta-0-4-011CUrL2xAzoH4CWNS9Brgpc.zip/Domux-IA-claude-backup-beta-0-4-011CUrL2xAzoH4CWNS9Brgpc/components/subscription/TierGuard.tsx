/**
 * Componente per proteggere l'accesso a feature in base al tier
 * Versione 0.5
 */

import React from 'react';
import type { User } from '../../services/firebase';
import type { SubscriptionTier, TierFeatures } from '../../types/subscription';
import {
  getUserTierFeatures,
  hasRequiredTier,
  getSubscriptionStatusMessage,
  getEffectiveTier
} from '../../services/subscriptionService';
import { TIER_CONFIG } from '../../types/subscription';

interface TierGuardProps {
  user: User;
  requiredTier?: SubscriptionTier;
  requiredFeature?: keyof TierFeatures;
  children: React.ReactNode;
  fallback?: React.ReactNode;
  showUpgradeMessage?: boolean;
}

/**
 * Componente che mostra i contenuti solo se l'utente ha il tier richiesto
 */
export const TierGuard: React.FC<TierGuardProps> = ({
  user,
  requiredTier,
  requiredFeature,
  children,
  fallback,
  showUpgradeMessage = true
}) => {
  const userTier = getEffectiveTier(user);
  const features = getUserTierFeatures(user);

  // Verifica tier se specificato
  if (requiredTier && !hasRequiredTier(user, requiredTier)) {
    if (fallback) {
      return <>{fallback}</>;
    }

    if (showUpgradeMessage) {
      return (
        <UpgradeMessage
          userTier={userTier}
          requiredTier={requiredTier}
          user={user}
        />
      );
    }

    return null;
  }

  // Verifica feature se specificata
  if (requiredFeature) {
    const featureValue = features[requiredFeature];
    const hasAccess = typeof featureValue === 'boolean'
      ? featureValue
      : typeof featureValue === 'number' && featureValue !== 0;

    if (!hasAccess) {
      if (fallback) {
        return <>{fallback}</>;
      }

      if (showUpgradeMessage) {
        return (
          <FeatureUpgradeMessage
            feature={requiredFeature}
            userTier={userTier}
            user={user}
          />
        );
      }

      return null;
    }
  }

  return <>{children}</>;
};

/**
 * Messaggio di upgrade per tier insufficiente
 */
const UpgradeMessage: React.FC<{
  userTier: SubscriptionTier;
  requiredTier: SubscriptionTier;
  user: User;
}> = ({ userTier, requiredTier, user }) => {
  const userTierConfig = TIER_CONFIG[userTier];
  const requiredTierConfig = TIER_CONFIG[requiredTier];
  const statusMessage = getSubscriptionStatusMessage(user);

  return (
    <div style={{
      padding: '24px',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      borderRadius: '12px',
      color: 'white',
      textAlign: 'center',
      margin: '20px 0'
    }}>
      <div style={{ fontSize: '48px', marginBottom: '16px' }}>🔒</div>
      <h3 style={{ margin: '0 0 12px 0', fontSize: '24px' }}>
        Feature Riservata
      </h3>
      <p style={{ margin: '0 0 8px 0', opacity: 0.9 }}>
        Questa funzionalità è disponibile a partire dal piano <strong>{requiredTierConfig.displayName}</strong>
      </p>
      <p style={{ margin: '0 0 20px 0', fontSize: '14px', opacity: 0.8 }}>
        Piano attuale: {userTierConfig.displayName} - {statusMessage}
      </p>
      <button
        style={{
          padding: '12px 32px',
          backgroundColor: 'white',
          color: '#667eea',
          border: 'none',
          borderRadius: '8px',
          fontSize: '16px',
          fontWeight: 'bold',
          cursor: 'pointer',
          boxShadow: '0 4px 12px rgba(0,0,0,0.2)'
        }}
        onClick={() => {
          // TODO: Navigare alla pagina di upgrade
          alert('La pagina di upgrade sarà disponibile a breve con l\'integrazione PayPal');
        }}
      >
        Effettua l'Upgrade
      </button>
    </div>
  );
};

/**
 * Messaggio di upgrade per feature specifica
 */
const FeatureUpgradeMessage: React.FC<{
  feature: keyof TierFeatures;
  userTier: SubscriptionTier;
  user: User;
}> = ({ feature, userTier, user }) => {
  const userTierConfig = TIER_CONFIG[userTier];
  const statusMessage = getSubscriptionStatusMessage(user);

  // Trova il tier minimo che ha questa feature
  const requiredTier = Object.entries(TIER_CONFIG).find(([_, config]) => {
    const value = config[feature];
    return typeof value === 'boolean' ? value : typeof value === 'number' && value !== 0;
  })?.[0] as SubscriptionTier;

  const requiredTierConfig = requiredTier ? TIER_CONFIG[requiredTier] : null;

  return (
    <div style={{
      padding: '20px',
      background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      borderRadius: '12px',
      color: 'white',
      textAlign: 'center',
      margin: '16px 0'
    }}>
      <div style={{ fontSize: '36px', marginBottom: '12px' }}>⭐</div>
      <h4 style={{ margin: '0 0 8px 0', fontSize: '18px' }}>
        Feature Premium
      </h4>
      <p style={{ margin: '0 0 16px 0', fontSize: '14px', opacity: 0.9 }}>
        {requiredTierConfig
          ? `Disponibile dal piano ${requiredTierConfig.displayName}`
          : 'Disponibile solo per piani superiori'
        }
      </p>
      <p style={{ margin: '0 0 16px 0', fontSize: '12px', opacity: 0.8 }}>
        Piano attuale: {userTierConfig.displayName} - {statusMessage}
      </p>
      <button
        style={{
          padding: '10px 24px',
          backgroundColor: 'white',
          color: '#f5576c',
          border: 'none',
          borderRadius: '6px',
          fontSize: '14px',
          fontWeight: 'bold',
          cursor: 'pointer'
        }}
        onClick={() => {
          // TODO: Navigare alla pagina di upgrade
          alert('La pagina di upgrade sarà disponibile a breve con l\'integrazione PayPal');
        }}
      >
        Scopri i Piani
      </button>
    </div>
  );
};

/**
 * Hook per verificare se l'utente può accedere a una feature
 */
export function useTierAccess(user: User, requiredTier?: SubscriptionTier, requiredFeature?: keyof TierFeatures) {
  const userTier = getEffectiveTier(user);
  const features = getUserTierFeatures(user);

  let hasAccess = true;

  if (requiredTier) {
    hasAccess = hasRequiredTier(user, requiredTier);
  }

  if (requiredFeature && hasAccess) {
    const featureValue = features[requiredFeature];
    hasAccess = typeof featureValue === 'boolean'
      ? featureValue
      : typeof featureValue === 'number' && featureValue !== 0;
  }

  return {
    hasAccess,
    userTier,
    features,
    statusMessage: getSubscriptionStatusMessage(user)
  };
}

export default TierGuard;
