import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob, Type, FunctionDeclaration } from '@google/genai';
import { db, doc, updateDoc, serverTimestamp, arrayUnion, getDoc } from '../services/firebase';

declare global {
  interface Window {
    webkitAudioContext: typeof AudioContext;
  }
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const updateSessionFunctionDeclaration: FunctionDeclaration = {
  name: 'updateProjectContext',
  description: "Aggiorna il contesto del progetto con le informazioni raccolte dall'utente. Da chiamare ogni volta che si ottiene un'informazione specifica.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      luogoLavori: {
        type: Type.STRING,
        description: 'La regione o il comune in cui si svolgeranno i lavori.',
      },
      descrizioneLavori: {
        type: Type.STRING,
        description: 'Una singola lavorazione o dettaglio tecnico descritto dall\'utente (es. "demolizione del muro", "posa di parquet").',
      },
      tipoProgetto: {
        type: Type.STRING,
        description: 'Il tipo di progetto: "public_works" per Opere Pubbliche con prezzari regionali ufficiali, oppure "private_estimate" per Preventivi Privati con prezzi da store edilizia.',
      },
      regionePreferita: {
        type: Type.STRING,
        description: 'La regione italiana per cui cercare i prezzari ufficiali (solo per opere pubbliche). Valori possibili: Abruzzo, Basilicata, Calabria, Campania, Emilia-Romagna, Friuli-Venezia Giulia, Lazio, Liguria, Lombardia, Marche, Molise, Piemonte, Puglia, Sardegna, Sicilia, Toscana, Trentino-Alto Adige, Umbria, Valle d\'Aosta, Veneto.',
      },
      storePreferiti: {
        type: Type.ARRAY,
        description: 'Array di nomi di store edilizia dove cercare i prezzi (solo per preventivi privati). Valori possibili: "Leroy Merlin", "Bricoman", "OBI", "Bricofer", "Brico IO", "Castorama".',
        items: {
          type: Type.STRING,
        },
      },
      nomeCommittente: {
        type: Type.STRING,
        description: 'Nome del committente del progetto.',
      },
      cognomeCommittente: {
        type: Type.STRING,
        description: 'Cognome del committente del progetto.',
      },
      codiceFiscaleCommittente: {
        type: Type.STRING,
        description: 'Codice Fiscale o Partita IVA del committente.',
      },
      indirizzoCommittente: {
        type: Type.STRING,
        description: 'Indirizzo completo del committente.',
      },
    },
  },
};

type Status = 'IDLE' | 'CONNECTING' | 'LISTENING' | 'SPEAKING' | 'ERROR';

interface VoiceAssistantProps {
  onClose: () => void;
  sessionId: string;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ onClose, sessionId }) => {
  const [status, setStatus] = useState<Status>('CONNECTING');
  const [showContinuePrompt, setShowContinuePrompt] = useState(false);
  const listeningTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const hasExistingDataRef = useRef(false);

  const ai = useRef<GoogleGenAI | null>(null);
  const sessionPromise = useRef<Promise<any> | null>(null);
  const inputAudioContext = useRef<AudioContext | null>(null);
  const outputAudioContext = useRef<AudioContext | null>(null);
  const scriptProcessor = useRef<ScriptProcessorNode | null>(null);
  const mediaStream = useRef<MediaStream | null>(null);
  const nextStartTime = useRef(0);
  const isClosing = useRef(false);
  const sources = useRef(new Set<AudioBufferSourceNode>());

  const startMicrophoneStream = () => {
    if (scriptProcessor.current || !inputAudioContext.current || !mediaStream.current) return;
    
    const source = inputAudioContext.current.createMediaStreamSource(mediaStream.current);
    const processor = inputAudioContext.current.createScriptProcessor(4096, 1, 1);
    
    processor.onaudioprocess = (audioProcessingEvent) => {
        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
        const pcmBlob: Blob = {
            data: encode(new Uint8Array(new Int16Array(inputData.map(f => f * 32768)).buffer)),
            mimeType: 'audio/pcm;rate=16000',
        };
        sessionPromise.current?.then((session) => {
            session.sendRealtimeInput({ media: pcmBlob });
        });
    };
    
    source.connect(processor);
    processor.connect(inputAudioContext.current.destination);
    scriptProcessor.current = processor;
  };

  useEffect(() => {
    const startSession = async () => {
        setStatus('CONNECTING');
        if (!process.env.API_KEY) {
          setStatus('ERROR');
          return;
        }
        ai.current = new GoogleGenAI({ apiKey: process.env.API_KEY });

        try {
          mediaStream.current = await navigator.mediaDevices.getUserMedia({ audio: true });
        } catch (err) {
          setStatus('ERROR');
          return;
        }

        // Check if there's existing data in the session BEFORE connecting
        try {
          const sessionDocRef = doc(db, 'projectSessions', sessionId);
          const sessionDoc = await getDoc(sessionDocRef);

          if (sessionDoc.exists()) {
            const sessionData = sessionDoc.data();
            const hasLocation = sessionData?.context?.location;
            const hasDescriptions = sessionData?.context?.descriptionItems && sessionData.context.descriptionItems.length > 0;
            const hasProjectType = sessionData?.projectType;

            // If the user has already provided some data, this is a returning session
            if (hasLocation || hasDescriptions || hasProjectType) {
              hasExistingDataRef.current = true;
            }
          }
        } catch (error) {
          console.error('Error checking existing session data:', error);
        }

        inputAudioContext.current = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
        outputAudioContext.current = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });

        sessionPromise.current = ai.current.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-09-2025',
          callbacks: {
            onopen: () => {
              setStatus('LISTENING'); // Update status when connection is established
              sessionPromise.current?.then((session) => {
                if (hasExistingDataRef.current) {
                  // Returning user - welcome them back
                  session.sendRealtimeInput({ text: "Bentornato! Vedo che abbiamo già iniziato a raccogliere informazioni per il tuo progetto. Vuoi continuare da dove avevamo lasciato o preferisci rivedere qualche informazione?" });
                } else {
                  // New session - standard greeting
                  session.sendRealtimeInput({ text: "Saluta brevemente l'utente, presentati come Domux AI e chiedi subito: vuoi generare un preventivo per un appalto pubblico o per un committente privato?" });
                }
              });
            },
            onmessage: async (message: LiveServerMessage) => handleServerMessage(message),
            onerror: () => setStatus('ERROR'),
            onclose: () => {},
          },
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
            tools: [{ functionDeclarations: [updateSessionFunctionDeclaration] }],
            systemInstruction: `Sei Domux AI, un assistente vocale intelligente per progetti edilizi. Il tuo compito è raccogliere informazioni in modo naturale e conversazionale.

PRINCIPI FONDAMENTALI:
1. RISPETTA LE PAUSE: Non interrompere MAI l'utente. Se sta riflettendo o elencando più cose, aspetta che finisca completamente prima di rispondere.
2. SII FLESSIBILE: Non seguire uno script rigido. Adatta le tue domande al contesto e alle informazioni che ricevi.
3. SII NATURALE: Parla come un assistente umano professionale. Accogli le informazioni anche se non richieste esplicitamente.
4. USA LA FUNZIONE IMMEDIATAMENTE: Per ogni informazione che ricevi, chiama la funzione 'updateProjectContext' SUBITO, poi passa alla domanda successiva senza interruzioni.
5. MANTIENI IL FLUSSO: Dopo aver salvato un dato, NON dire mai "ho ricevuto tutto" o "abbiamo finito" a meno che non hai DAVVERO raccolto tutte le informazioni necessarie.

FLUSSO CONVERSAZIONALE (ma sii flessibile):
1. Inizia chiedendo il tipo di progetto: "Vuoi generare un preventivo per un appalto pubblico o per un committente privato?"
   - Se pubblico (public_works): chiedi la regione e salva con tipoProgetto="public_works"
   - Se privato (private_estimate): chiedi su quali negozi cercare i prezzi e salva con tipoProgetto="private_estimate"

2. Per preventivi PRIVATI, chiedi: "Su quali negozi vuoi che cerchi i prezzi?"
   Presenta le opzioni: "Ho disponibili Leroy Merlin, Bricoman, OBI, Bricofer, Brico IO e Castorama. Puoi scegliere uno o più negozi."
   Salva come array in storePreferiti.

3. Chiedi la località dei lavori (città o comune).
   CRUCIALE: Quando ricevi la località:
   a) Chiama subito updateProjectContext(luogoLavori="...") per salvarla
   b) Attendi la risposta della funzione (ti dirà "Salvato: località: ...")
   c) Passa IMMEDIATAMENTE alla domanda sulle lavorazioni
   d) NON dire frasi come "ho ricevuto tutto" o "perfetto, abbiamo finito"
   e) Esempio di risposta corretta dopo aver salvato Milano: "Perfetto, Milano salvata. Ora dimmi, che tipo di lavori devi fare?"

4. Chiedi i dettagli delle lavorazioni da eseguire.
   IMPORTANTE: Questa è una delle domande PIÙ IMPORTANTI - non saltarla!
   L'utente potrebbe elencare più cose insieme - aspetta che finisca e poi salva ogni lavorazione separatamente chiamando updateProjectContext(descrizioneLavori="...") per ciascuna.

5. Se necessario, chiedi i dati del committente (nome, cognome, codice fiscale/P.IVA, indirizzo).
   IMPORTANTE: Il cognome del committente è OBBLIGATORIO per generare il preventivo.

GESTIONE PAUSE E ASCOLTO:
- Se l'utente dice parole come "aspetta", "un attimo", "fammi pensare": non fare nulla, aspetta in silenzio.
- Se l'utente sta elencando cose con virgole o "e" o "poi": aspetta che finisca l'elenco completo.
- Se una frase sembra incompleta (termina con "per...", "con...", ecc.): aspetta ancora.
- Rispondi solo quando sei sicuro che l'utente abbia finito di parlare.

CONTROLLO QUALITÀ DELLA RACCOLTA DATI:
- Hai raccolto il tipo di progetto?
- Hai raccolto la località?
- Hai raccolto ALMENO UNA lavorazione? (ESSENZIALE!)
- Se opere pubbliche: hai raccolto la regione?
- Se preventivo privato: hai raccolto gli store?
- Se richiesto: hai raccolto i dati del committente (specialmente il cognome)?

Solo quando hai raccolto TUTTE queste informazioni puoi dire "Ho tutte le informazioni necessarie".

TONO:
- Conciso e professionale
- Conferma brevemente cosa hai capito
- Non ripetere informazioni già acquisite
- Non generare mai il computo metrico (non è il tuo compito)

Ricorda: ogni volta che l'utente fornisce un'informazione, salvala immediatamente con la funzione 'updateProjectContext', attendi la conferma "Salvato: ...", e poi passa alla domanda successiva.`,
          },
        });
    };

    startSession();

    return () => {
      closeSessionResources();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleServerMessage = async (message: LiveServerMessage) => {
    if (message.toolCall) {
      for (const fc of message.toolCall.functionCalls) {
        if (fc.name === 'updateProjectContext') {
          const {
            descrizioneLavori,
            luogoLavori,
            tipoProgetto,
            regionePreferita,
            storePreferiti,
            nomeCommittente,
            cognomeCommittente,
            codiceFiscaleCommittente,
            indirizzoCommittente
          } = fc.args;

          const sessionDocRef = doc(db, 'projectSessions', sessionId);
          let updates: any = { updatedAt: serverTimestamp() };

          // Track what was saved for a contextual response
          let savedItems: string[] = [];

          if (luogoLavori) {
            updates['context.location'] = luogoLavori;
            savedItems.push(`località: ${luogoLavori}`);
          }
          if (descrizioneLavori) {
            updates['context.descriptionItems'] = arrayUnion(descrizioneLavori);
            savedItems.push(`lavorazione: ${descrizioneLavori}`);
          }
          if (tipoProgetto) {
            updates['projectType'] = tipoProgetto;
            savedItems.push(`tipo progetto: ${tipoProgetto === 'public_works' ? 'opere pubbliche' : 'preventivo privato'}`);
          }
          if (regionePreferita) {
            updates['region'] = regionePreferita;
            savedItems.push(`regione: ${regionePreferita}`);
          }
          if (storePreferiti && Array.isArray(storePreferiti)) {
            updates['preferredStores'] = storePreferiti;
            savedItems.push(`store: ${storePreferiti.join(', ')}`);
          }
          if (nomeCommittente) {
            updates['context.committente.nome'] = nomeCommittente;
            savedItems.push(`nome committente: ${nomeCommittente}`);
          }
          if (cognomeCommittente) {
            updates['context.committente.cognome'] = cognomeCommittente;
            savedItems.push(`cognome committente: ${cognomeCommittente}`);
          }
          if (codiceFiscaleCommittente) {
            updates['context.committente.codiceFiscale'] = codiceFiscaleCommittente;
            savedItems.push('codice fiscale committente');
          }
          if (indirizzoCommittente) {
            updates['context.committente.indirizzo'] = indirizzoCommittente;
            savedItems.push('indirizzo committente');
          }

          await updateDoc(sessionDocRef, updates);

          // Create a contextual response based on what was saved
          const contextualResponse = savedItems.length > 0
            ? `Salvato: ${savedItems.join(', ')}. Prosegui con la prossima domanda.`
            : "Dato salvato correttamente.";

          sessionPromise.current?.then((session) => {
            session.sendToolResponse({
              functionResponses: { id: fc.id, name: fc.name, response: { result: contextualResponse } }
            });
          });
        }
      }
    }

    const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
    if (base64Audio && outputAudioContext.current?.state === 'running') {
        setStatus('SPEAKING');
        setShowContinuePrompt(false);
        if (listeningTimeoutRef.current) {
          clearTimeout(listeningTimeoutRef.current);
          listeningTimeoutRef.current = null;
        }
        try {
            const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext.current, 24000, 1);
            nextStartTime.current = Math.max(nextStartTime.current, outputAudioContext.current.currentTime);
            const source = outputAudioContext.current.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(outputAudioContext.current.destination);

            sources.current.add(source);
            source.onended = () => {
                sources.current.delete(source);
                if (!isClosing.current && sources.current.size === 0) {
                    if (!scriptProcessor.current) startMicrophoneStream();
                    setStatus('LISTENING');
                    // Start timeout for "continue" prompt after 12 seconds of listening
                    listeningTimeoutRef.current = setTimeout(() => {
                      setShowContinuePrompt(true);
                    }, 12000);
                }
            };
            source.start(nextStartTime.current);
            nextStartTime.current += audioBuffer.duration;
        } catch (error) {
            if (!isClosing.current) {
              setStatus('LISTENING');
              // Start timeout for "continue" prompt
              listeningTimeoutRef.current = setTimeout(() => {
                setShowContinuePrompt(true);
              }, 12000);
            }
        }
    }
  };

  const closeSessionResources = () => {
    if (isClosing.current) return;
    isClosing.current = true;
    setStatus('IDLE');
    setShowContinuePrompt(false);
    if (listeningTimeoutRef.current) {
      clearTimeout(listeningTimeoutRef.current);
      listeningTimeoutRef.current = null;
    }
    sessionPromise.current?.then(session => session.close()).catch(console.error);
    if(scriptProcessor.current) scriptProcessor.current.disconnect();
    scriptProcessor.current = null;
    mediaStream.current?.getTracks().forEach(track => track.stop());
    inputAudioContext.current?.close().catch(console.error);
    outputAudioContext.current?.close().catch(console.error);
  };
  
  const handleManualClose = () => {
    closeSessionResources();
    onClose();
  };

  const getStatusIndicator = () => {
    switch(status) {
        case 'CONNECTING': return <><div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div><span>Connessione...</span></>;
        case 'LISTENING': return <><div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div><span>In ascolto...</span></>;
        case 'SPEAKING': return <><div className="w-3 h-3 bg-teal-500 rounded-full animate-pulse"></div><span>Sto parlando...</span></>;
        case 'ERROR': return <><div className="w-3 h-3 bg-red-500 rounded-full"></div><span>Errore</span></>;
        default: return null;
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-2 sm:p-4" aria-modal="true" role="dialog">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[95vh] sm:max-h-[90vh]">
        <header className="p-3 sm:p-4 border-b flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <h2 className="text-base sm:text-lg font-bold text-zinc-800">Assistente Vocale Domux AI</h2>
          <div className="flex items-center gap-2 text-xs sm:text-sm text-zinc-600 font-medium">{getStatusIndicator()}</div>
        </header>

        <main className="p-4 sm:p-6 flex-grow flex flex-col items-center justify-center bg-zinc-50 text-center overflow-y-auto">
            <div className={`relative w-32 h-32 sm:w-48 sm:h-48 rounded-full flex items-center justify-center transition-colors duration-300 ${status === 'LISTENING' && 'bg-green-100'} ${status === 'SPEAKING' && 'bg-teal-100'} ${status === 'CONNECTING' && 'bg-yellow-100'} ${status === 'ERROR' && 'bg-red-100'}`}>
                <div className={`absolute inset-0 rounded-full ${status === 'LISTENING' && showContinuePrompt ? 'animate-ping bg-green-300' : 'animate-pulse'} ${status === 'LISTENING' && 'bg-green-200'} ${status === 'SPEAKING' && 'bg-teal-200'} ${status === 'CONNECTING' && 'bg-yellow-200'}`} style={{ animationDuration: showContinuePrompt ? '2s' : '1.5s' }}></div>
                <div className={`relative w-24 h-24 sm:w-32 sm:h-32 rounded-full flex items-center justify-center transition-colors duration-300 ${status === 'LISTENING' && 'bg-green-200'} ${status === 'SPEAKING' && 'bg-teal-200'} ${status === 'CONNECTING' && 'bg-yellow-200'} ${status === 'ERROR' && 'bg-red-200'}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className={`h-12 w-12 sm:h-16 sm:w-16 transition-colors duration-300 ${status === 'LISTENING' && 'text-green-600'} ${status === 'SPEAKING' && 'text-teal-600'} ${status === 'CONNECTING' && 'text-yellow-600'} ${status === 'ERROR' && 'text-red-600'}`} viewBox="0 0 20 20" fill="currentColor"><path d="M7 4a3 3 0 016 0v6a3 3 0 11-6 0V4z" /><path fillRule="evenodd" d="M5.5 10.5a.5.5 0 01.5-.5h8a.5.5 0 010 1H6a.5.5 0 01-.5-.5z" clipRule="evenodd" /><path d="M2 10a.5.5 0 00-1 0v1a8 8 0 007.5 7.94V20a.5.5 0 001 0v-1.06A8 8 0 0019 11v-1a.5.5 0 00-1 0v1a7 7 0 01-14 0v-1z" /></svg>
                </div>
            </div>
            <p className="mt-4 sm:mt-8 text-lg sm:text-xl font-semibold text-zinc-700 h-7">
              {status === 'LISTENING' && !showContinuePrompt && 'In ascolto...'}
              {status === 'LISTENING' && showContinuePrompt && 'Continua pure, ti ascolto'}
              {status === 'SPEAKING' && 'Sto parlando...'}
              {status === 'CONNECTING' && 'Connessione...'}
              {status === 'ERROR' && 'Errore di connessione'}
            </p>
            {status === 'ERROR' && <div className="text-center text-red-600 bg-red-100 p-3 rounded-lg mt-4 max-w-sm text-sm sm:text-base"><p className="font-semibold">Impossibile avviare l'assistente.</p><p className="text-sm">Assicurati di aver concesso i permessi per il microfono.</p></div>}
            {status === 'LISTENING' && showContinuePrompt && (
              <p className="mt-2 text-sm text-zinc-500 italic">Ti sto ascoltando con attenzione...</p>
            )}
        </main>

        <footer className="p-3 sm:p-4 border-t bg-white">
           <button onClick={handleManualClose} className="w-full bg-red-600 text-white font-bold py-2 sm:py-3 px-4 rounded-lg hover:bg-red-700 transition-colors duration-300 text-sm sm:text-base">
            Termina Dialogo
          </button>
        </footer>
      </div>
    </div>
  );
};

export default VoiceAssistant;