
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full text-center p-4">
      <p className="text-xs text-zinc-500">
        Realizzato da Thomas Milici e Domenico Gimondo. Tutti i diritti riservati.
      </p>
    </footer>
  );
};

export default Footer;