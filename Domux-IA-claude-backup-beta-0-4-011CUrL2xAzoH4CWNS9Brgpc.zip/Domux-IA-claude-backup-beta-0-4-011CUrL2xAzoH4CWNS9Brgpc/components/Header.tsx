import React from 'react';
import { User, signOut, auth } from '../services/firebase';
import Logo from './Logo';

interface HeaderProps {
  user: User;
  onToggleDashboard: () => void;
  isDashboardOpen: boolean;
}

const Header: React.FC<HeaderProps> = ({ user, onToggleDashboard, isDashboardOpen }) => {
  const handleLogout = () => {
    signOut(auth).catch((error) => console.error("Error signing out: ", error));
  };

  const isAdminOrCollaborator = user.role === 'superadmin' || user.role === 'admin' || user.role === 'collaborator';

  return (
    <header className="w-full bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-40">
      <div className="flex items-center gap-3">
        <Logo className="h-10 w-auto" />
        <span className="text-2xl font-bold text-brand-dark tracking-tight">Domux AI</span>
      </div>
      <div className="flex items-center gap-4">
        {isAdminOrCollaborator && (
            <button
                onClick={onToggleDashboard}
                className="text-sm font-medium text-zinc-600 hover:text-brand-cyan transition-colors"
                title={isDashboardOpen ? "Vai alla Dashboard Utente" : "Vai alla Dashboard Admin"}
            >
                {isDashboardOpen ? 'Dashboard Utente' : 'Dashboard Admin'}
            </button>
        )}
        <span className="text-sm text-zinc-600 hidden sm:block">
          Ciao, {user.displayName || user.email}
        </span>
        <button
          onClick={handleLogout}
          className="bg-brand-dark text-white font-bold py-2 px-4 rounded-lg hover:opacity-90 transition-colors duration-300 text-sm"
        >
          Logout
        </button>
      </div>
    </header>
  );
};

export default Header;