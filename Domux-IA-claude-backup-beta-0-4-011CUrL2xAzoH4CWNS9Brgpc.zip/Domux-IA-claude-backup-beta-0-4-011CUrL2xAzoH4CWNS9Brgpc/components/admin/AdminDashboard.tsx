import React, { useState, useEffect } from 'react';
import { db, User, onSnapshot, collection, doc, updateDoc, deleteDoc, serverTimestamp } from '../../services/firebase';

interface AppUser {
  uid: string;
  email: string;
  role: 'user' | 'collaborator' | 'admin' | 'superadmin';
  disabled?: boolean;
};

interface Project {
  createdAt: {
    seconds: number;
    nanoseconds: number;
  };
}

interface Stats {
  daily: number;
  monthly: number;
  semiAnnually: number;
  annually: number;
}

interface AdminDashboardProps {
  currentUser: User;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ currentUser }) => {
  const [users, setUsers] = useState<AppUser[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Fetch Users
    const usersUnsubscribe = onSnapshot(collection(db, 'users'), 
      (snapshot) => {
        const usersData = snapshot.docs.map((doc) => ({ ...doc.data(), uid: doc.id } as AppUser));
        setUsers(usersData);
      },
      (err) => {
        console.error(err);
        setError('Impossibile caricare gli utenti.');
      }
    );

    // Fetch Projects for Stats
    const projectsUnsubscribe = onSnapshot(collection(db, 'projects'),
      (snapshot) => {
        const projectsData = snapshot.docs.map(doc => doc.data() as Project);
        calculateStats(projectsData);
        setLoading(false);
      },
      (err) => {
        console.error(err);
        setError('Impossibile caricare le statistiche.');
        setLoading(false);
      }
    );
    
    return () => {
      usersUnsubscribe();
      projectsUnsubscribe();
    };
  }, []);

  const calculateStats = (projects: Project[]) => {
    const now = new Date();
    const oneDay = 24 * 60 * 60 * 1000;
    const thirtyDays = 30 * oneDay;
    const sixMonths = 182 * oneDay;
    const oneYear = 365 * oneDay;

    const daily = projects.filter(p => now.getTime() - new Date(p.createdAt.seconds * 1000).getTime() <= oneDay).length;
    const monthly = projects.filter(p => now.getTime() - new Date(p.createdAt.seconds * 1000).getTime() <= thirtyDays).length;
    const semiAnnually = projects.filter(p => now.getTime() - new Date(p.createdAt.seconds * 1000).getTime() <= sixMonths).length;
    const annually = projects.filter(p => now.getTime() - new Date(p.createdAt.seconds * 1000).getTime() <= oneYear).length;

    setStats({ daily, monthly, semiAnnually, annually });
  }
  
  const handleRoleChange = async (targetUser: AppUser, newRole: 'user' | 'collaborator' | 'admin') => {
    // Superadmin can't be modified by anyone
    if (targetUser.role === 'superadmin') {
        alert("Non hai i permessi per modificare questo utente.");
        return;
    }

    // Only superadmin can promote to admin
    if (newRole === 'admin' && currentUser.role !== 'superadmin') {
        alert("Solo il superadmin può promuovere utenti ad admin.");
        return;
    }

    // Admin can't modify other admins or superadmins
    if (currentUser.role === 'admin' && (targetUser.role === 'admin' || targetUser.role === 'superadmin')) {
        alert("Non hai i permessi per modificare questo utente.");
        return;
    }

    // Only superadmin and admin can change roles
    if (currentUser.role !== 'superadmin' && currentUser.role !== 'admin') {
        alert("Non hai i permessi per modificare questo utente.");
        return;
    }
    
    try {
        const userDocRef = doc(db, 'users', targetUser.uid);
        await updateDoc(userDocRef, { role: newRole });
    } catch (err) {
        console.error("Errore nell'aggiornamento del ruolo:", err);
        alert("Impossibile aggiornare il ruolo dell'utente.");
    }
  };

  const handleToggleDisabled = async (targetUser: AppUser) => {
    // Superadmin can't be blocked
    if (targetUser.role === 'superadmin') {
        alert("Non puoi bloccare un superadmin.");
        return;
    }

    // Admin can't block other admins
    if (currentUser.role === 'admin' && targetUser.role === 'admin') {
        alert("Non puoi bloccare un altro admin.");
        return;
    }

    // Only admin, collaborator, and superadmin can block/unblock
    if (currentUser.role !== 'superadmin' && currentUser.role !== 'admin' && currentUser.role !== 'collaborator') {
        alert("Non hai i permessi per bloccare/sbloccare utenti.");
        return;
    }

    const newDisabledStatus = !targetUser.disabled;
    const action = newDisabledStatus ? 'bloccare' : 'sbloccare';

    if (!window.confirm(`Vuoi ${action} l'utente ${targetUser.email}?`)) {
        return;
    }

    try {
        const userDocRef = doc(db, 'users', targetUser.uid);
        await updateDoc(userDocRef, { disabled: newDisabledStatus });
    } catch (err) {
        console.error("Errore nel blocco/sblocco utente:", err);
        alert("Impossibile modificare lo stato dell'utente.");
    }
  };

  const handleDeleteUser = async (targetUser: AppUser) => {
    // Only admin and superadmin can delete users
    if (currentUser.role !== 'superadmin' && currentUser.role !== 'admin') {
        alert("Non hai i permessi per eliminare utenti.");
        return;
    }

    // Can't delete superadmin
    if (targetUser.role === 'superadmin') {
        alert("Non puoi eliminare un superadmin.");
        return;
    }

    // Admin can't delete other admins
    if (currentUser.role === 'admin' && targetUser.role === 'admin') {
        alert("Non puoi eliminare un altro admin.");
        return;
    }

    // Can't delete yourself
    if (targetUser.uid === currentUser.uid) {
        alert("Non puoi eliminare il tuo account.");
        return;
    }

    if (!window.confirm(`Sei sicuro di voler ELIMINARE l'utente ${targetUser.email}? Questa azione è irreversibile!`)) {
        return;
    }

    try {
        const userDocRef = doc(db, 'users', targetUser.uid);
        await deleteDoc(userDocRef);
        alert("Utente eliminato con successo.");
    } catch (err) {
        console.error("Errore nell'eliminazione dell'utente:", err);
        alert("Impossibile eliminare l'utente.");
    }
  };

  if (loading) {
    return <div className="p-8 text-center w-full">Caricamento dashboard...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500 w-full">{error}</div>;
  }

  return (
    <div className="p-4 sm:p-8 w-full max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-zinc-800">Dashboard Amministrazione</h1>
      
      {/* --- Stats Section --- */}
      <div className="mb-10">
        <h2 className="text-2xl font-semibold mb-4 text-zinc-700">Statistiche di Utilizzo</h2>
        {stats ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-6 rounded-lg shadow-md text-white">
                <h3 className="uppercase text-sm opacity-90">👥 Utenti Registrati</h3>
                <p className="text-4xl font-bold">{users.length}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-zinc-500 uppercase text-sm">Progetti (24h)</h3>
                <p className="text-4xl font-bold text-brand-dark">{stats.daily}</p>
            </div>
             <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-zinc-500 uppercase text-sm">Progetti (30gg)</h3>
                <p className="text-4xl font-bold text-brand-dark">{stats.monthly}</p>
            </div>
             <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-zinc-500 uppercase text-sm">Progetti (6 mesi)</h3>
                <p className="text-4xl font-bold text-brand-dark">{stats.semiAnnually}</p>
            </div>
             <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-zinc-500 uppercase text-sm">Progetti (1 anno)</h3>
                <p className="text-4xl font-bold text-brand-dark">{stats.annually}</p>
            </div>
          </div>
        ) : <p>Caricamento statistiche...</p>}
      </div>

      {/* --- User Management Section (Collaborators can view, Superadmin can edit) --- */}
      <div>
        <h2 className="text-2xl font-semibold mb-4 text-zinc-700">Gestione Utenti</h2>
        {currentUser.role === 'collaborator' && (
          <p className="text-sm text-zinc-600 mb-4 bg-blue-50 p-3 rounded-lg">
            ℹ️ <strong>Modalità visualizzazione:</strong> Come collaboratore, puoi visualizzare gli utenti ma non modificarne i ruoli.
          </p>
        )}
        <div className="bg-white shadow-lg rounded-lg overflow-x-auto">
          <table className="min-w-full leading-normal">
            <thead>
              <tr>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Email Utente
                </th>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Ruolo Attuale
                </th>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Stato
                </th>
                {(currentUser.role === 'superadmin' || currentUser.role === 'admin' || currentUser.role === 'collaborator') && (
                  <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Azioni
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.uid}>
                  <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <p className="text-gray-900 whitespace-nowrap">{user.email}</p>
                  </td>
                  <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <span className={`relative inline-block px-3 py-1 font-semibold leading-tight rounded-full ${
                      user.role === 'superadmin' ? 'bg-red-200 text-red-900' :
                      user.role === 'admin' ? 'bg-purple-200 text-purple-900' :
                      user.role === 'collaborator' ? 'bg-blue-200 text-blue-900' :
                      'bg-green-200 text-green-900'
                    }`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <span className={`relative inline-block px-3 py-1 font-semibold leading-tight rounded-full ${
                      user.disabled ? 'bg-red-200 text-red-900' : 'bg-green-200 text-green-900'
                    }`}>
                      {user.disabled ? '🚫 Bloccato' : '✅ Attivo'}
                    </span>
                  </td>
                  {(currentUser.role === 'superadmin' || currentUser.role === 'admin' || currentUser.role === 'collaborator') && (
                    <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                      <div className="flex flex-wrap gap-2">
                        {/* Superadmin can promote to any role except superadmin */}
                        {currentUser.role === 'superadmin' && user.role !== 'superadmin' && (
                          <>
                            {user.role === 'user' && (
                              <>
                                <button
                                  onClick={() => handleRoleChange(user, 'collaborator')}
                                  className="bg-blue-500 hover:bg-blue-700 text-white text-xs font-bold py-1 px-2 rounded"
                                >
                                  → Collaboratore
                                </button>
                                <button
                                  onClick={() => handleRoleChange(user, 'admin')}
                                  className="bg-purple-500 hover:bg-purple-700 text-white text-xs font-bold py-1 px-2 rounded"
                                >
                                  → Admin
                                </button>
                              </>
                            )}
                            {user.role === 'collaborator' && (
                              <>
                                <button
                                  onClick={() => handleRoleChange(user, 'admin')}
                                  className="bg-purple-500 hover:bg-purple-700 text-white text-xs font-bold py-1 px-2 rounded"
                                >
                                  → Admin
                                </button>
                                <button
                                  onClick={() => handleRoleChange(user, 'user')}
                                  className="bg-yellow-500 hover:bg-yellow-700 text-white text-xs font-bold py-1 px-2 rounded"
                                >
                                  → User
                                </button>
                              </>
                            )}
                            {user.role === 'admin' && (
                              <>
                                <button
                                  onClick={() => handleRoleChange(user, 'collaborator')}
                                  className="bg-blue-500 hover:bg-blue-700 text-white text-xs font-bold py-1 px-2 rounded"
                                >
                                  → Collaboratore
                                </button>
                                <button
                                  onClick={() => handleRoleChange(user, 'user')}
                                  className="bg-yellow-500 hover:bg-yellow-700 text-white text-xs font-bold py-1 px-2 rounded"
                                >
                                  → User
                                </button>
                              </>
                            )}
                          </>
                        )}
                        {/* Admin can only modify user and collaborator roles */}
                        {currentUser.role === 'admin' && user.role !== 'superadmin' && user.role !== 'admin' && (
                          <>
                            {user.role === 'user' && (
                              <button
                                onClick={() => handleRoleChange(user, 'collaborator')}
                                className="bg-blue-500 hover:bg-blue-700 text-white text-xs font-bold py-1 px-2 rounded"
                              >
                                → Collaboratore
                              </button>
                            )}
                            {user.role === 'collaborator' && (
                              <button
                                onClick={() => handleRoleChange(user, 'user')}
                                className="bg-yellow-500 hover:bg-yellow-700 text-white text-xs font-bold py-1 px-2 rounded"
                              >
                                → User
                              </button>
                            )}
                          </>
                        )}

                        {/* Separator for block/unblock and delete buttons */}
                        {((currentUser.role === 'superadmin' || currentUser.role === 'admin') && user.role !== 'superadmin') && <div className="w-full border-t border-gray-300 my-2"></div>}

                        {/* Block/Unblock button - available for superadmin, admin, and collaborator */}
                        {user.role !== 'superadmin' && !(currentUser.role === 'admin' && user.role === 'admin') && (
                          <button
                            onClick={() => handleToggleDisabled(user)}
                            className={`${user.disabled ? 'bg-green-600 hover:bg-green-800' : 'bg-orange-500 hover:bg-orange-700'} text-white text-xs font-bold py-1 px-2 rounded w-full`}
                          >
                            {user.disabled ? '✅ Sblocca' : '🚫 Blocca'}
                          </button>
                        )}

                        {/* Delete button - only for admin and superadmin */}
                        {(currentUser.role === 'superadmin' || currentUser.role === 'admin') &&
                         user.role !== 'superadmin' &&
                         !(currentUser.role === 'admin' && user.role === 'admin') &&
                         user.uid !== currentUser.uid && (
                          <button
                            onClick={() => handleDeleteUser(user)}
                            className="bg-red-600 hover:bg-red-800 text-white text-xs font-bold py-1 px-2 rounded w-full mt-2"
                          >
                            🗑️ Elimina
                          </button>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;