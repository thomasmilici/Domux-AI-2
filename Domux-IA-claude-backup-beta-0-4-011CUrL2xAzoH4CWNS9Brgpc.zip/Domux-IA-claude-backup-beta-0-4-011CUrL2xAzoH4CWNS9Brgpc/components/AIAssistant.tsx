import React, { useState, useRef, useEffect } from 'react';
import { User, db, collection, addDoc, serverTimestamp, storage, ref, uploadBytes, getDownloadURL } from '../services/firebase';
import { generateRenovationPlan, generateComputoMetric, sendChatMessage, analyzeDocument, generateComputoFromDocument, analyzeMultipleDocumentsAndGuide, generateProjectTitle } from '../services/geminiService';
import { ComputoItem } from '../types';
import Loader from './Loader';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { generateProfessionalPDF } from '../utils/pdfGeneration';

interface Message {
    id: string;
    role: 'user' | 'assistant';
    content: string;
    timestamp: Date;
    fileAttachment?: {
        name: string;
        type: string;
        preview?: string;
    };
}

interface AIAssistantProps {
    user: User;
    onGoBack: () => void;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ user, onGoBack }) => {
    const [messages, setMessages] = useState<Message[]>([
        {
            id: '1',
            role: 'assistant',
            content: 'Ciao! Sono il tuo assistente AI specializzato in edilizia. Posso aiutarti a:\n\n📝 Generare preventivi dai tuoi appunti (anche foto di note scritte a mano)\n📄 Analizzare documenti PDF\n📷 Scattare foto di cantieri e creare computi\n💬 Rispondere a domande su edilizia e ristrutturazioni\n\nUsa i pulsanti qui sotto o scrivimi direttamente! Come posso aiutarti oggi?',
            timestamp: new Date(),
        }
    ]);
    const [inputText, setInputText] = useState('');
    const [loading, setLoading] = useState(false);
    const [uploadingFile, setUploadingFile] = useState(false);
    const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
    const [showFilesPreview, setShowFilesPreview] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const multiFileInputRef = useRef<HTMLInputElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    // Helper function to save computo to Firestore
    const saveComputoToArchive = async (computoItems: ComputoItem[], reportText: string, fileName: string) => {
        try {
            // Generate readable ID
            const now = new Date();
            const datePart = now.toISOString().split('T')[0];
            const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
            const readableId = `CM-${datePart}-${randomPart}`;

            // Generate intelligent project title based on computo items
            let projectTitle: string;
            try {
                projectTitle = await generateProjectTitle(computoItems, fileName);
                // Format: "[Descrizione] - [Data]" (no surname available in AI Assistant context)
                const formattedDate = now.toLocaleDateString('it-IT');
                projectTitle = `${projectTitle} - ${formattedDate}`;
            } catch (error) {
                console.error('Error generating project title:', error);
                projectTitle = `Analisi ${fileName} - ${now.toLocaleDateString('it-IT')}`;
            }

            // Create metadata for PDF generation
            const metadata = {
                uuid: crypto.randomUUID(),
                readableId,
                hash: '', // Will be calculated after PDF generation
                timestamp: now.toISOString(),
                generatorVersion: "Domux AI v1.5 - AI Assistant",
            };

            // Create minimal session object for PDF generation (AI Assistant doesn't have full session data)
            const sessionData = {
                id: 'ai-assistant',
                projectName: projectTitle,
                context: {
                    location: `Analisi documento: ${fileName}`,
                    committente: {
                        nome: '',
                        cognome: '',
                        codiceFiscale: '',
                        indirizzo: ''
                    },
                    descriptionItems: []
                }
            };

            // Use professional PDF generation function (no images for AI Assistant)
            const doc = generateProfessionalPDF(
                computoItems,
                reportText,
                user,
                sessionData as any,
                metadata,
                undefined,
                undefined
            );

            // Generate PDF blob
            const pdfBlob = doc.output('blob');
            const pdfArrayBuffer = await pdfBlob.arrayBuffer();
            const pdfUint8Array = new Uint8Array(pdfArrayBuffer);

            // Calculate hash
            const hashBuffer = await crypto.subtle.digest('SHA-256', pdfUint8Array);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            metadata.hash = hash;

            // Upload PDF to Storage
            const pdfStorageRef = ref(storage, `pdfs/${user.uid}/${readableId}.pdf`);
            await uploadBytes(pdfStorageRef, pdfBlob);
            const pdfDownloadUrl = await getDownloadURL(pdfStorageRef);

            // Save to Firestore
            const projectData = {
                userId: user.uid,
                userInput: `Analisi ${fileName}`,
                location: 'Italia',
                createdAt: serverTimestamp(),
                pdfDownloadUrl,
                metadata,
                result: {
                    computoItems,
                    reportText
                }
            };

            await addDoc(collection(db, 'projects'), projectData);

            return readableId;
        } catch (error) {
            console.error('Errore durante il salvataggio del computo:', error);
            throw error;
        }
    };

    const handleSendMessage = async () => {
        if (!inputText.trim() || loading) return;

        const userMessage: Message = {
            id: Date.now().toString(),
            role: 'user',
            content: inputText,
            timestamp: new Date(),
        };

        setMessages(prev => [...prev, userMessage]);
        const messageText = inputText;
        setInputText('');
        setLoading(true);

        try {
            // Convert messages to Gemini API format (excluding the welcome message and user's current message)
            const conversationHistory = messages
                .slice(1) // Skip the welcome message
                .map(msg => ({
                    role: msg.role === 'user' ? 'user' as const : 'model' as const,
                    parts: [{ text: msg.content }]
                }));

            // Call real Gemini API
            const aiResponse = await sendChatMessage(messageText, conversationHistory);

            const aiMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: aiResponse,
                timestamp: new Date(),
            };
            setMessages(prev => [...prev, aiMessage]);
        } catch (error: any) {
            const errorMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: `Mi dispiace, si è verificato un errore: ${error.message}`,
                timestamp: new Date(),
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setLoading(false);
        }
    };

    const compressImage = async (file: File): Promise<{ base64: string, mimeType: string, preview: string }> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    const MAX_WIDTH = 1920;
                    const MAX_HEIGHT = 1920;

                    let width = img.width;
                    let height = img.height;

                    if (width > height) {
                        if (width > MAX_WIDTH) {
                            height = Math.round((height * MAX_WIDTH) / width);
                            width = MAX_WIDTH;
                        }
                    } else {
                        if (height > MAX_HEIGHT) {
                            width = Math.round((width * MAX_HEIGHT) / height);
                            height = MAX_HEIGHT;
                        }
                    }

                    const canvas = document.createElement('canvas');
                    canvas.width = width;
                    canvas.height = height;

                    const ctx = canvas.getContext('2d');
                    if (!ctx) {
                        reject(new Error('Impossibile creare il contesto canvas'));
                        return;
                    }

                    ctx.drawImage(img, 0, 0, width, height);

                    canvas.toBlob(
                        (blob) => {
                            if (!blob) {
                                reject(new Error('Impossibile comprimere l\'immagine'));
                                return;
                            }

                            const compressedReader = new FileReader();
                            compressedReader.onloadend = () => {
                                const dataUrl = compressedReader.result as string;
                                const base64String = dataUrl.split(',')[1];

                                console.log(`Image compressed: ${file.size} bytes -> ${blob.size} bytes (${Math.round((blob.size / file.size) * 100)}%)`);

                                resolve({
                                    base64: base64String,
                                    mimeType: 'image/jpeg',
                                    preview: dataUrl
                                });
                            };
                            compressedReader.onerror = () => reject(new Error('Errore nella lettura dell\'immagine compressa'));
                            compressedReader.readAsDataURL(blob);
                        },
                        'image/jpeg',
                        0.85
                    );
                };
                img.onerror = () => reject(new Error('Errore nel caricamento dell\'immagine'));
                img.src = e.target?.result as string;
            };
            reader.onerror = () => reject(new Error('Errore nella lettura del file'));
            reader.readAsDataURL(file);
        });
    };

    const handleFileUpload = async (file: File, toolPrompt: string) => {
        setUploadingFile(true);

        try {
            let base64: string;
            let mimeType: string;
            let preview: string | undefined;

            // Compress images before uploading
            if (file.type.startsWith('image/')) {
                const compressed = await compressImage(file);
                base64 = compressed.base64;
                mimeType = compressed.mimeType;
                preview = compressed.preview;
            } else {
                // For PDFs and other files, read normally
                const reader = new FileReader();
                const result = await new Promise<string>((resolve, reject) => {
                    reader.onload = (e) => resolve(e.target?.result as string);
                    reader.onerror = () => reject(new Error('Errore nella lettura del file'));
                    reader.readAsDataURL(file);
                });
                base64 = result.split(',')[1];
                mimeType = file.type;
                preview = undefined;
            }

            const userMessage: Message = {
                id: Date.now().toString(),
                role: 'user',
                content: toolPrompt,
                timestamp: new Date(),
                fileAttachment: {
                    name: file.name,
                    type: file.type,
                    preview: preview,
                }
            };

            setMessages(prev => [...prev, userMessage]);
            setUploadingFile(false);
            setLoading(true);

            try {
                // For both images and PDFs, generate complete computo
                if (file.type.startsWith('image/') || file.type === 'application/pdf') {

                    // Generate structured computo from document/image
                    const computoResult = await generateComputoFromDocument(
                        base64,
                        mimeType,
                        toolPrompt,
                        'Italia'
                    );

                    // Save to archive
                    const projectId = await saveComputoToArchive(
                        computoResult.computoItems,
                        computoResult.reportText,
                        file.name
                    );

                    const total = computoResult.computoItems.reduce((sum, item) => sum + item.importo, 0);

                    const aiMessage: Message = {
                        id: (Date.now() + 1).toString(),
                        role: 'assistant',
                        content: `✅ Ho analizzato "${file.name}" e generato un computo metrico completo!\n\n📊 **Riepilogo:**\n- Voci di computo: ${computoResult.computoItems.length}\n- Importo totale: €${total.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n- Codice progetto: ${projectId}\n\n💾 **Il progetto è stato salvato automaticamente nella sezione Archivio** e puoi scaricarlo in formato PDF o Excel quando vuoi.\n\nTorna alla dashboard per visualizzarlo! 🎉`,
                        timestamp: new Date(),
                    };
                    setMessages(prev => [...prev, aiMessage]);
                } else {
                    // For other document types
                    const aiMessage: Message = {
                        id: (Date.now() + 1).toString(),
                        role: 'assistant',
                        content: `Ho ricevuto il file "${file.name}" di tipo ${file.type}. Al momento supporto principalmente PDF e immagini. Se è un documento di testo, prova a convertirlo in PDF.`,
                        timestamp: new Date(),
                    };
                    setMessages(prev => [...prev, aiMessage]);
                }
            } catch (error: any) {
                const errorMessage: Message = {
                    id: (Date.now() + 1).toString(),
                    role: 'assistant',
                    content: `Mi dispiace, si è verificato un errore durante l'analisi: ${error.message}`,
                    timestamp: new Date(),
                };
                setMessages(prev => [...prev, errorMessage]);
            } finally {
                setLoading(false);
            }
        } catch (error: any) {
            const errorMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: `Mi dispiace, si è verificato un errore: ${error.message}`,
                timestamp: new Date(),
            };
            setMessages(prev => [...prev, errorMessage]);
            setUploadingFile(false);
            setLoading(false);
        }
    };

    const handleMultipleFilesUpload = async (files: File[]) => {
        if (files.length === 0) return;

        setUploadingFile(true);
        setShowFilesPreview(false);

        // Create user message showing what files were uploaded
        const fileList = files.map(f => `📎 ${f.name}`).join('\n');
        const userMessage: Message = {
            id: Date.now().toString(),
            role: 'user',
            content: `Ho caricato i miei appunti per generare un preventivo:\n\n${fileList}`,
            timestamp: new Date(),
        };

        setMessages(prev => [...prev, userMessage]);
        setUploadingFile(false);
        setLoading(true);

        try {
            // Convert all files to base64 (with image compression)
            const filesData: { base64: string; mimeType: string; name: string }[] = [];

            for (const file of files) {
                let base64: string;
                let mimeType: string;

                // Compress images before uploading
                if (file.type.startsWith('image/')) {
                    const compressed = await compressImage(file);
                    base64 = compressed.base64;
                    mimeType = compressed.mimeType;
                } else {
                    // For PDFs and other files, read normally
                    base64 = await new Promise<string>((resolve) => {
                        const reader = new FileReader();
                        reader.onload = (e) => {
                            const result = e.target?.result as string;
                            resolve(result.split(',')[1]);
                        };
                        reader.readAsDataURL(file);
                    });
                    mimeType = file.type;
                }

                filesData.push({
                    base64,
                    mimeType: mimeType,
                    name: file.name,
                });
            }

            // Call AI with intelligent analysis - first analyze, then ask for missing info
            const conversationHistory = messages
                .slice(1)
                .map(msg => ({
                    role: msg.role === 'user' ? 'user' as const : 'model' as const,
                    parts: [{ text: msg.content }]
                }));

            const analysisResult = await analyzeMultipleDocumentsAndGuide(
                filesData,
                conversationHistory
            );

            // Show AI's message to user
            const aiMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: analysisResult.message,
                timestamp: new Date(),
            };
            setMessages(prev => [...prev, aiMessage]);

            // If AI determined it can generate the computo, do it automatically
            if (analysisResult.shouldGenerateComputo && analysisResult.extractedInfo) {
                const { description, location, projectType, region } = analysisResult.extractedInfo;

                if (description && location) {
                    // Show loading message
                    const generatingMessage: Message = {
                        id: (Date.now() + 2).toString(),
                        role: 'assistant',
                        content: '⏳ Sto generando il computo metrico completo...',
                        timestamp: new Date(),
                    };
                    setMessages(prev => [...prev, generatingMessage]);

                    try {
                        // Generate the full computo
                        const computoResult = await generateComputoMetric(
                            description,
                            location,
                            projectType as 'public_works' | 'private_estimate' | undefined,
                            region
                        );

                        // Save to archive
                        const projectId = await saveComputoToArchive(
                            computoResult.computoItems,
                            computoResult.reportText,
                            'Preventivo da appunti'
                        );

                        const total = computoResult.computoItems.reduce((sum, item) => sum + item.importo, 0);

                        const successMessage: Message = {
                            id: (Date.now() + 3).toString(),
                            role: 'assistant',
                            content: `✅ Computo metrico generato con successo!\n\n📊 **Riepilogo:**\n- Voci di computo: ${computoResult.computoItems.length}\n- Importo totale: €${total.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n- Codice progetto: ${projectId}\n\n💾 **Il progetto è stato salvato automaticamente nella sezione Archivio**. Torna alla dashboard per visualizzarlo e scaricarlo! 🎉`,
                            timestamp: new Date(),
                        };
                        setMessages(prev => [...prev.slice(0, -1), successMessage]); // Replace loading message
                    } catch (error: any) {
                        const errorMsg: Message = {
                            id: (Date.now() + 3).toString(),
                            role: 'assistant',
                            content: `❌ Si è verificato un errore durante la generazione del computo: ${error.message}`,
                            timestamp: new Date(),
                        };
                        setMessages(prev => [...prev.slice(0, -1), errorMsg]); // Replace loading message
                    }
                }
            }

            setSelectedFiles([]);
        } catch (error: any) {
            const errorMessage: Message = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: `Mi dispiace, si è verificato un errore durante l'analisi: ${error.message}`,
                timestamp: new Date(),
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setLoading(false);
        }
    };

    const handleMultiFileSelect = () => {
        if (multiFileInputRef.current) {
            multiFileInputRef.current.accept = 'image/*,application/pdf';
            multiFileInputRef.current.multiple = true;
            multiFileInputRef.current.onchange = (e) => {
                const files = Array.from((e.target as HTMLInputElement).files || []);
                if (files.length > 0) {
                    setSelectedFiles(files);
                    setShowFilesPreview(true);
                }
            };
            multiFileInputRef.current.click();
        }
    };

    const handleToolClick = (toolName: string, prompt: string, acceptFiles: string, useCamera: boolean = false) => {
        if (fileInputRef.current) {
            fileInputRef.current.accept = acceptFiles;
            // Enable camera capture on mobile devices
            if (useCamera) {
                fileInputRef.current.setAttribute('capture', 'environment'); // Use back camera
            } else {
                fileInputRef.current.removeAttribute('capture');
            }
            fileInputRef.current.onchange = (e) => {
                const file = (e.target as HTMLInputElement).files?.[0];
                if (file) {
                    handleFileUpload(file, prompt);
                }
            };
            fileInputRef.current.click();
        }
    };

    return (
        <div className="w-full max-w-6xl mx-auto h-screen flex flex-col bg-zinc-100 p-2 sm:p-4">
            {/* Header */}
            <div className="bg-white rounded-t-xl shadow-lg p-2 sm:p-4 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                    <div className="text-2xl sm:text-4xl">🤖</div>
                    <div className="min-w-0">
                        <h1 className="text-lg sm:text-2xl font-bold text-brand-dark truncate">Assistente AI</h1>
                        <p className="text-xs sm:text-sm text-zinc-600 hidden sm:block">Analizza documenti, foto e genera computi</p>
                    </div>
                </div>
                <button
                    onClick={onGoBack}
                    className="bg-zinc-200 text-zinc-800 font-bold py-1.5 px-3 sm:py-2 sm:px-4 rounded-lg hover:bg-zinc-300 transition-colors text-sm sm:text-base whitespace-nowrap"
                >
                    ← Indietro
                </button>
            </div>

            {/* Chat Messages Area */}
            <div className="flex-1 bg-white shadow-lg overflow-y-auto p-3 sm:p-6 space-y-3 sm:space-y-4">
                {messages.map((message) => (
                    <div
                        key={message.id}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                        <div
                            className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-3 sm:p-4 ${
                                message.role === 'user'
                                    ? 'bg-gradient-to-r from-brand-dark to-brand-cyan text-white'
                                    : 'bg-zinc-100 text-zinc-800 border border-zinc-200'
                            }`}
                        >
                            {message.fileAttachment && (
                                <div className="mb-2 sm:mb-3 p-2 sm:p-3 bg-white/10 rounded-lg">
                                    <p className="text-xs opacity-75 mb-1">📎 Allegato:</p>
                                    <p className="font-semibold text-xs sm:text-sm break-all">{message.fileAttachment.name}</p>
                                    {message.fileAttachment.preview && (
                                        <img
                                            src={message.fileAttachment.preview}
                                            alt="Preview"
                                            className="mt-2 rounded-lg max-h-32 sm:max-h-40 object-cover w-full"
                                        />
                                    )}
                                </div>
                            )}
                            <p className="whitespace-pre-wrap text-sm sm:text-base leading-relaxed">{message.content}</p>
                            <p className={`text-xs mt-2 ${message.role === 'user' ? 'text-white/70' : 'text-zinc-500'}`}>
                                {message.timestamp.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}
                            </p>
                        </div>
                    </div>
                ))}
                {loading && (
                    <div className="flex justify-start">
                        <div className="bg-zinc-100 rounded-2xl p-4 border border-zinc-200">
                            <div className="flex items-center gap-2">
                                <div className="animate-bounce">●</div>
                                <div className="animate-bounce delay-100">●</div>
                                <div className="animate-bounce delay-200">●</div>
                                <span className="ml-2 text-zinc-600">L'AI sta pensando...</span>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Tools Panel */}
            <div className="bg-white shadow-lg p-2 sm:p-4 border-t border-zinc-200">
                <p className="text-xs text-zinc-500 mb-2 sm:mb-3 text-center hidden sm:block">🛠️ Strumenti Rapidi</p>
                <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-2 sm:mb-4">
                    <button
                        onClick={() => handleToolClick('PDF', 'Analizza questo documento PDF e genera un computo metrico basato sul contenuto. Estrai tutte le voci di costo, quantità e descrizioni.', 'application/pdf')}
                        disabled={loading || uploadingFile}
                        className="bg-gradient-to-br from-red-500 to-red-600 text-white p-2 sm:p-4 rounded-lg sm:rounded-xl hover:shadow-lg transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <div className="text-2xl sm:text-3xl mb-1 sm:mb-2">📄</div>
                        <div className="font-bold text-xs sm:text-sm">Analizza PDF</div>
                        <div className="text-xs opacity-90 hidden sm:block">Carica documento</div>
                    </button>

                    <button
                        onClick={() => handleToolClick('Photo', 'Analizza questa foto del cantiere/stanza e genera un computo estimativo completo dei lavori necessari. Crea anche una visualizzazione 3D del risultato finale.', 'image/*', true)}
                        disabled={loading || uploadingFile}
                        className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-2 sm:p-4 rounded-lg sm:rounded-xl hover:shadow-lg transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <div className="text-2xl sm:text-3xl mb-1 sm:mb-2">📷</div>
                        <div className="font-bold text-xs sm:text-sm">Scatta Foto</div>
                        <div className="text-xs opacity-90 hidden sm:block">Usa fotocamera</div>
                    </button>

                    <button
                        onClick={handleMultiFileSelect}
                        disabled={loading || uploadingFile}
                        className="bg-gradient-to-br from-green-500 to-green-600 text-white p-2 sm:p-4 rounded-lg sm:rounded-xl hover:shadow-lg transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <div className="text-2xl sm:text-3xl mb-1 sm:mb-2">📝</div>
                        <div className="font-bold text-xs sm:text-sm">Usa Appunti</div>
                        <div className="text-xs opacity-90 hidden sm:block">Foto o documenti</div>
                    </button>
                </div>
            </div>

            {/* Files Preview Panel */}
            {showFilesPreview && selectedFiles.length > 0 && (
                <div className="bg-white shadow-lg p-3 sm:p-4 border-t border-zinc-200">
                    <div className="flex items-center justify-between mb-3">
                        <h3 className="text-sm sm:text-base font-bold text-zinc-800">
                            📎 File selezionati ({selectedFiles.length})
                        </h3>
                        <button
                            onClick={() => {
                                setSelectedFiles([]);
                                setShowFilesPreview(false);
                            }}
                            className="text-zinc-500 hover:text-zinc-700 text-sm"
                        >
                            ✕ Annulla
                        </button>
                    </div>
                    <div className="space-y-2 mb-3 max-h-32 overflow-y-auto">
                        {selectedFiles.map((file, index) => (
                            <div key={index} className="flex items-center gap-2 p-2 bg-zinc-50 rounded-lg">
                                <span className="text-lg">
                                    {file.type.startsWith('image/') ? '🖼️' : '📄'}
                                </span>
                                <span className="text-xs sm:text-sm text-zinc-700 flex-1 truncate">
                                    {file.name}
                                </span>
                                <span className="text-xs text-zinc-500">
                                    {(file.size / 1024).toFixed(0)} KB
                                </span>
                            </div>
                        ))}
                    </div>
                    <button
                        onClick={() => handleMultipleFilesUpload(selectedFiles)}
                        disabled={loading || uploadingFile}
                        className="w-full bg-gradient-to-r from-brand-dark to-brand-cyan text-white font-bold py-2 sm:py-3 rounded-lg hover:opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-sm sm:text-base"
                    >
                        ✓ Invia e Analizza
                    </button>
                </div>
            )}

            {/* Input Area */}
            <div className="bg-white rounded-b-xl shadow-lg p-2 sm:p-4">
                <div className="flex gap-2 sm:gap-3">
                    <input
                        type="text"
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        placeholder="Scrivi un messaggio..."
                        disabled={loading}
                        className="flex-1 p-2 sm:p-3 text-sm sm:text-base border-2 border-zinc-300 rounded-lg focus:border-brand-cyan focus:outline-none disabled:bg-zinc-100 disabled:cursor-not-allowed"
                    />
                    <button
                        onClick={handleSendMessage}
                        disabled={!inputText.trim() || loading}
                        className="bg-gradient-to-r from-brand-dark to-brand-cyan text-white font-bold px-4 sm:px-6 py-2 sm:py-3 rounded-lg hover:opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-sm sm:text-base whitespace-nowrap"
                    >
                        ➤ <span className="hidden sm:inline">Invia</span>
                    </button>
                </div>
            </div>

            {/* Hidden file inputs */}
            <input
                ref={fileInputRef}
                type="file"
                className="hidden"
            />
            <input
                ref={multiFileInputRef}
                type="file"
                multiple
                className="hidden"
            />

            {uploadingFile && <Loader message="Caricamento file in corso..." />}
        </div>
    );
};

export default AIAssistant;
