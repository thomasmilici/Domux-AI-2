import React, { useState, useEffect } from 'react';
import { db, User, collection, query, where, onSnapshot, addDoc, serverTimestamp, doc, getDoc, deleteDoc, updateDoc } from '../../services/firebase';
import { ProjectSession } from '../../types';
import MainApp from '../../MainApp';
import AIAssistant from '../AIAssistant';
import Logger from '../../services/logger';

interface ProjectSummary {
    id: string;
    userInput: string;
    readableId: string;
    createdAt: Date;
    pdfDownloadUrl: string;
}

interface UserDashboardProps {
  user: User;
  onViewProject?: (projectId: string) => void;
}

const UserDashboard: React.FC<UserDashboardProps> = ({ user, onViewProject }) => {
    const [activeSessions, setActiveSessions] = useState<ProjectSession[]>([]);
    const [completedProjects, setCompletedProjects] = useState<ProjectSummary[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
    const [showImportDialog, setShowImportDialog] = useState(false);
    const [showAIAssistant, setShowAIAssistant] = useState(false);
    const [viewMode, setViewMode] = useState<'main' | 'sessions' | 'archive'>('main');

    // State for editing professional profile
    const [isEditingProfile, setIsEditingProfile] = useState(false);
    const [profileData, setProfileData] = useState({
        ragioneSociale: user.ragioneSociale || '',
        partitaIva: user.partitaIva || '',
        indirizzo: user.indirizzo || '',
        emailContatto: user.emailContatto || '',
        telefono: user.telefono || '',
    });

    useEffect(() => {
        setLoading(true);
        setError(null);
        
        // Listener for all project sessions to filter client-side
        const sessionsQuery = query(
            collection(db, 'projectSessions'),
            where('userId', '==', user.uid)
        );
        const unsubscribeSessions = onSnapshot(sessionsQuery, (snapshot) => {
            const allSessions = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as ProjectSession));
            
            const active = allSessions
                .filter(session => session.status === 'open' || session.status === 'paused')
                .sort((a, b) => {
                    const timeA = a.updatedAt?.seconds ? a.updatedAt.seconds * 1000 : 0;
                    const timeB = b.updatedAt?.seconds ? b.updatedAt.seconds * 1000 : 0;
                    return timeB - timeA;
                });

            setActiveSessions(active);
        }, (err) => {
            Logger.error("Error fetching active sessions:", err);
            setError("Impossibile caricare le sessioni attive.");
        });

        // Listener for completed projects.
        const projectsQuery = query(
            collection(db, 'projects'),
            where('userId', '==', user.uid)
        );
        const unsubscribeProjects = onSnapshot(projectsQuery, (snapshot) => {
            const projectsData: ProjectSummary[] = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    userInput: data.userInput || 'Progetto senza descrizione',
                    readableId: data.metadata?.readableId || `PROJ-${doc.id.substring(0, 8)}`,
                    createdAt: data.createdAt?.toDate() || new Date(),
                    pdfDownloadUrl: data.pdfDownloadUrl || '',
                };
            });
            
            projectsData.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

            setCompletedProjects(projectsData);
            setLoading(false);
        }, (err) => {
            Logger.error("Error fetching completed projects:", err);
            setError("Impossibile caricare i progetti completati.");
            setLoading(false);
        });

        return () => {
            unsubscribeSessions();
            unsubscribeProjects();
        };
    }, [user.uid]);

    const handleCreateNewProject = async () => {
        try {
            const newSession: Omit<ProjectSession, 'id'> = {
                userId: user.uid,
                projectName: `Progetto del ${new Date().toLocaleDateString('it-IT')}`,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
                status: 'open',
                context: {
                    descriptionItems: [],
                    location: '',
                    committente: {
                        nome: '',
                        cognome: '',
                        codiceFiscale: '',
                        indirizzo: '',
                    },
                },
            };
            const docRef = await addDoc(collection(db, 'projectSessions'), newSession);
            setCurrentSessionId(docRef.id);
        } catch (err) {
            Logger.error("Error creating new project session:", err);
            setError("Impossibile creare un nuovo progetto.");
            alert("Errore: Impossibile creare un nuovo progetto. Controlla le autorizzazioni e riprova.");
        }
    };
    
    const handleResumeSession = (sessionId: string) => {
        setCurrentSessionId(sessionId);
    };

    const handleDuplicateProject = async (project: ProjectSummary) => {
        const newName = window.prompt(`Inserisci il nome per il progetto duplicato:`, `Copia di ${project.readableId}`);
        if (!newName || newName.trim() === '') {
            return; // Utente ha annullato o non ha inserito un nome
        }

        try {
            const projectDocRef = doc(db, 'projects', project.id);
            const projectDoc = await getDoc(projectDocRef);

            if (!projectDoc.exists()) {
                setError("Impossibile trovare il progetto originale da duplicare.");
                alert("Errore: il progetto originale non è stato trovato.");
                return;
            }

            const originalProjectData = projectDoc.data();
            const newSession: Omit<ProjectSession, 'id'> = {
                userId: user.uid,
                projectName: newName.trim(),
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
                status: 'open',
                context: {
                    descriptionItems: [originalProjectData.userInput],
                    location: originalProjectData.location,
                    committente: { nome: '', cognome: '', codiceFiscale: '', indirizzo: '' },
                },
                parentId: project.id,
            };

            const docRef = await addDoc(collection(db, 'projectSessions'), newSession);
            // Apri automaticamente il progetto duplicato
            setCurrentSessionId(docRef.id);

        } catch (err) {
            Logger.error("Error duplicating project:", err);
            setError("Impossibile duplicare il progetto. Riprova più tardi.");
            alert(`Errore durante la duplicazione: ${err.message}`);
        }
    };

    const handleDeleteProject = async (projectId: string) => {
        if (window.confirm("Sei sicuro di voler eliminare questo progetto? L'azione è irreversibile.")) {
            try {
                await deleteDoc(doc(db, 'projects', projectId));
                alert("Progetto eliminato con successo.");
            } catch (err) {
                Logger.error("Error deleting project:", err);
                setError("Impossibile eliminare il progetto.");
                alert(`Errore durante l'eliminazione: ${err.message}`);
            }
        }
    };

    const handleRenameProject = async (projectId: string, currentName: string) => {
        const newName = prompt("Inserisci il nuovo nome del progetto:", currentName);
        if (!newName || newName.trim() === '' || newName === currentName) {
            return; // User cancelled or didn't change the name
        }

        try {
            const projectDocRef = doc(db, 'projects', projectId);
            await updateDoc(projectDocRef, {
                userInput: newName.trim()
            });
            alert("Progetto rinominato con successo!");
        } catch (err) {
            Logger.error("Error renaming project:", err);
            setError("Impossibile rinominare il progetto.");
            alert(`Errore durante la ridenominazione: ${err.message}`);
        }
    };

    const handleDeleteSession = async (sessionId: string) => {
        if (window.confirm("Sei sicuro di voler eliminare questa sessione? Tutti i dati non salvati andranno persi.")) {
            try {
                await deleteDoc(doc(db, 'projectSessions', sessionId));
                alert("Sessione eliminata con successo.");
            } catch (err) {
                Logger.error("Error deleting session:", err);
                setError("Impossibile eliminare la sessione.");
                alert(`Errore durante l'eliminazione: ${err.message}`);
            }
        }
    };

    const handleDuplicateSession = async (session: ProjectSession) => {
        const newName = window.prompt(`Inserisci il nome per la sessione duplicata:`, `Copia di ${session.projectName}`);
        if (!newName || newName.trim() === '') {
            return; // Utente ha annullato o non ha inserito un nome
        }

        try {
            const newSession: Omit<ProjectSession, 'id'> = {
                userId: user.uid,
                projectName: newName.trim(),
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
                status: 'open',
                context: {
                    ...session.context
                },
                parentId: session.id,
            };

            const docRef = await addDoc(collection(db, 'projectSessions'), newSession);
            // Apri automaticamente la sessione duplicata
            setCurrentSessionId(docRef.id);

        } catch (err) {
            Logger.error("Error duplicating session:", err);
            setError("Impossibile duplicare la sessione.");
            alert(`Errore durante la duplicazione: ${err.message}`);
        }
    };
    
    const handleProfileDataChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setProfileData(prev => ({ ...prev, [name]: value }));
    };

    const handleProfileSave = async () => {
        try {
            const userDocRef = doc(db, 'users', user.uid);
            await updateDoc(userDocRef, profileData);

            // Update local user object
            Object.assign(user, profileData);

            setIsEditingProfile(false);
            alert("Dati professionali aggiornati con successo.");
        } catch(err) {
            Logger.error("Error updating profile:", err);
            setError("Impossibile salvare le modifiche al profilo.");
            alert(`Errore durante il salvataggio del profilo: ${err.message}`);
        }
    };

    const handleImportProject = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        try {
            const text = await file.text();
            const data = JSON.parse(text);

            // Validate imported data
            if (!data.descriptionItems || !data.location) {
                alert("File non valido: mancano campi obbligatori (descriptionItems, location)");
                return;
            }

            const newSession: Omit<ProjectSession, 'id'> = {
                userId: user.uid,
                projectName: data.projectName || `Progetto Importato ${new Date().toLocaleDateString('it-IT')}`,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
                status: 'open',
                context: {
                    descriptionItems: Array.isArray(data.descriptionItems) ? data.descriptionItems : [data.descriptionItems],
                    location: data.location || '',
                    committente: data.committente || {
                        nome: '',
                        cognome: '',
                        codiceFiscale: '',
                        indirizzo: '',
                    },
                },
            };

            const docRef = await addDoc(collection(db, 'projectSessions'), newSession);
            alert("Progetto importato con successo!");
            setShowImportDialog(false);
            setCurrentSessionId(docRef.id);

        } catch (err) {
            Logger.error("Error importing project:", err);
            alert(`Errore durante l'importazione: ${err.message}`);
        }
    };


    // Render functions for different views
    const renderMainView = () => (
        <>
            {/* Pulsanti Azioni Principali - 5 Grandi Card */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                {/* Pulsante Nuovo Progetto */}
                <button
                    onClick={handleCreateNewProject}
                    className="bg-gradient-to-r from-brand-dark to-brand-cyan text-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] group"
                >
                    <div className="flex items-start gap-4">
                        <div className="text-5xl group-hover:scale-110 transition-transform">📄</div>
                        <div className="text-left flex-grow">
                            <h3 className="text-xl font-bold mb-2">Nuovo Progetto</h3>
                            <p className="text-white/90 text-sm">
                                Inizia una nuova sessione per generare un computo metrico dettagliato
                            </p>
                        </div>
                    </div>
                </button>

                {/* Pulsante Assistente AI */}
                <button
                    onClick={() => setShowAIAssistant(true)}
                    className="bg-gradient-to-r from-purple-600 to-pink-500 text-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] group"
                >
                    <div className="flex items-start gap-4">
                        <div className="text-5xl group-hover:scale-110 transition-transform">🤖</div>
                        <div className="text-left flex-grow">
                            <h3 className="text-xl font-bold mb-2">Assistente AI</h3>
                            <p className="text-white/90 text-sm">
                                Chatta con l'AI, analizza documenti e foto, genera computi e render 3D
                            </p>
                        </div>
                    </div>
                </button>

                {/* Pulsante Importa Progetto */}
                <button
                    onClick={() => setShowImportDialog(true)}
                    className="bg-gradient-to-r from-zinc-700 to-zinc-500 text-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] group"
                >
                    <div className="flex items-start gap-4">
                        <div className="text-5xl group-hover:scale-110 transition-transform">📥</div>
                        <div className="text-left flex-grow">
                            <h3 className="text-xl font-bold mb-2">Importa Progetto Esterno</h3>
                            <p className="text-white/90 text-sm">
                                Carica un progetto esistente o dati esterni
                            </p>
                        </div>
                    </div>
                </button>
            </div>

            {/* Navigazione a Sezioni con Badge */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                {/* Pulsante Sessioni in Corso */}
                <button
                    onClick={() => setViewMode('sessions')}
                    className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] group relative"
                >
                    <div className="flex items-center justify-between">
                        <div className="flex items-start gap-4">
                            <div className="text-5xl group-hover:scale-110 transition-transform">🔄</div>
                            <div className="text-left">
                                <h3 className="text-2xl font-bold mb-2">Sessioni in Corso</h3>
                                <p className="text-white/90 text-sm">
                                    Riprendi le tue sessioni di lavoro attive
                                </p>
                            </div>
                        </div>
                        {activeSessions.length > 0 && (
                            <div className="absolute top-4 right-4 bg-white text-blue-600 font-bold text-lg px-4 py-2 rounded-full shadow-lg">
                                {activeSessions.length}
                            </div>
                        )}
                    </div>
                </button>

                {/* Pulsante Archivio Progetti */}
                <button
                    onClick={() => setViewMode('archive')}
                    className="bg-gradient-to-r from-green-500 to-green-600 text-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] group relative"
                >
                    <div className="flex items-center justify-between">
                        <div className="flex items-start gap-4">
                            <div className="text-5xl group-hover:scale-110 transition-transform">📦</div>
                            <div className="text-left">
                                <h3 className="text-2xl font-bold mb-2">Progetti Archiviati</h3>
                                <p className="text-white/90 text-sm">
                                    Visualizza e gestisci i progetti completati
                                </p>
                            </div>
                        </div>
                        {completedProjects.length > 0 && (
                            <div className="absolute top-4 right-4 bg-white text-green-600 font-bold text-lg px-4 py-2 rounded-full shadow-lg">
                                {completedProjects.length}
                            </div>
                        )}
                    </div>
                </button>
            </div>
        </>
    );

    const renderSessionsView = () => (
        <>
            {/* Header con Back Button */}
            <div className="flex items-center gap-4 mb-6">
                <button
                    onClick={() => setViewMode('main')}
                    className="bg-zinc-200 text-zinc-800 font-bold py-2 px-4 rounded-lg hover:bg-zinc-300 transition-colors"
                >
                    ← Torna alla Dashboard
                </button>
                <h2 className="text-2xl font-bold text-zinc-800">🔄 Sessioni in Corso</h2>
            </div>

            {/* Lista Sessioni */}
            {activeSessions.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {activeSessions.map(session => (
                        <div key={session.id} className="p-4 border border-zinc-200 rounded-lg flex flex-col gap-3 bg-white hover:shadow-lg transition-shadow">
                            <div className="flex-grow min-w-0">
                                <p className="font-semibold text-zinc-900 truncate text-lg">{session.projectName}</p>
                                <p className="text-sm text-zinc-500 break-words mt-2">
                                    Ultima modifica: {session.updatedAt?.toDate().toLocaleString('it-IT')}
                                </p>
                            </div>
                            <div className="flex flex-col gap-2">
                                <button
                                    onClick={() => handleResumeSession(session.id)}
                                    className="w-full bg-zinc-700 text-white font-bold py-3 px-4 rounded-lg hover:bg-zinc-800 transition-colors"
                                >
                                    ▶️ Riprendi Sessione
                                </button>
                                <button
                                    onClick={() => handleDeleteSession(session.id)}
                                    className="w-full bg-red-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-red-700 transition-colors"
                                >
                                    🗑️ Elimina Sessione
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="bg-white p-12 rounded-lg shadow-lg text-center">
                    <div className="text-6xl mb-4">📋</div>
                    <p className="text-zinc-500 text-lg">Nessuna sessione attiva.</p>
                    <p className="text-zinc-400 mt-2">Crea un nuovo progetto per iniziare!</p>
                    <button
                        onClick={() => setViewMode('main')}
                        className="mt-6 bg-brand-dark text-white font-bold py-3 px-6 rounded-lg hover:opacity-90 transition-opacity"
                    >
                        Torna alla Dashboard
                    </button>
                </div>
            )}
        </>
    );

    const renderArchiveView = () => (
        <>
            {/* Header con Back Button */}
            <div className="flex items-center gap-4 mb-6">
                <button
                    onClick={() => setViewMode('main')}
                    className="bg-zinc-200 text-zinc-800 font-bold py-2 px-4 rounded-lg hover:bg-zinc-300 transition-colors"
                >
                    ← Torna alla Dashboard
                </button>
                <h2 className="text-2xl font-bold text-zinc-800">📦 Archivio Progetti Certificati</h2>
            </div>

            {/* Lista Progetti Archiviati */}
            {completedProjects.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {completedProjects.map(project => (
                        <div key={project.id} className="p-4 border border-zinc-200 rounded-lg flex flex-col gap-3 bg-white hover:shadow-lg transition-shadow">
                            <div className="flex-grow min-w-0">
                                <p className="font-semibold text-zinc-900 break-words">{project.readableId}</p>
                                <p className="text-sm text-zinc-600 break-words line-clamp-2 mt-1" title={project.userInput}>
                                    {project.userInput}
                                </p>
                                <p className="text-xs text-zinc-500 mt-2">
                                    📅 {project.createdAt.toLocaleDateString('it-IT')}
                                </p>
                            </div>
                            <div className="flex flex-col gap-2 mt-auto">
                                {onViewProject && (
                                    <button
                                        onClick={() => onViewProject(project.id)}
                                        className="w-full text-center bg-brand-cyan text-white font-bold py-2 px-3 rounded-lg hover:opacity-90 transition-colors"
                                    >
                                        👁️ Visualizza Progetto
                                    </button>
                                )}
                                <a
                                    href={project.pdfDownloadUrl}
                                    download={`${project.userInput.replace(/[^a-zA-Z0-9\s\-_]/g, '')}.pdf`}
                                    className="w-full text-center bg-brand-dark text-white font-bold py-2 px-3 rounded-lg hover:opacity-90 transition-colors inline-block"
                                >
                                    📄 Scarica PDF
                                </a>
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => handleRenameProject(project.id, project.userInput)}
                                        className="flex-1 text-center bg-blue-600 text-white font-bold py-2 px-3 rounded-lg hover:bg-blue-700 transition-colors"
                                        title="Rinomina Progetto"
                                    >
                                        ✏️
                                    </button>
                                    <button
                                        onClick={() => handleDuplicateProject(project)}
                                        className="flex-1 text-center bg-zinc-600 text-white font-bold py-2 px-3 rounded-lg hover:bg-zinc-700 transition-colors"
                                        title="Duplica Progetto"
                                    >
                                        📋
                                    </button>
                                    <button
                                        onClick={() => handleDeleteProject(project.id)}
                                        className="bg-red-600 text-white font-bold py-2 px-3 rounded-lg hover:bg-red-700 transition-colors"
                                        title="Elimina Progetto"
                                    >
                                        🗑️
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="bg-white p-12 rounded-lg shadow-lg text-center">
                    <div className="text-6xl mb-4">📦</div>
                    <p className="text-zinc-500 text-lg">Nessun progetto archiviato.</p>
                    <p className="text-zinc-400 mt-2">I progetti completati appariranno qui.</p>
                    <button
                        onClick={() => setViewMode('main')}
                        className="mt-6 bg-brand-dark text-white font-bold py-3 px-6 rounded-lg hover:opacity-90 transition-opacity"
                    >
                        Torna alla Dashboard
                    </button>
                </div>
            )}
        </>
    );

    if (currentSessionId) {
        return <MainApp user={user} onGoBack={() => setCurrentSessionId(null)} initialSessionId={currentSessionId} />;
    }

    if (showAIAssistant) {
        return <AIAssistant user={user} onGoBack={() => setShowAIAssistant(false)} />;
    }

    return (
        <div className="w-full max-w-7xl mx-auto animate-fade-in px-4 sm:px-6 lg:px-8">
            <header className="mb-6">
                <h1 className="text-2xl sm:text-3xl font-bold text-zinc-800">Dashboard Progetti</h1>
                <p className="text-zinc-600 mt-1 text-sm sm:text-base">
                    {viewMode === 'main' && 'Gestisci le tue sessioni di lavoro e visualizza i progetti completati.'}
                    {viewMode === 'sessions' && 'Le tue sessioni di lavoro attive'}
                    {viewMode === 'archive' && 'I tuoi progetti completati e certificati'}
                </p>
            </header>

            {loading && <p className="text-zinc-600">Caricamento dati...</p>}
            {error && <p className="text-red-500 bg-red-100 p-3 rounded-md mb-4">{error}</p>}

            {/* Dati Professionista - Spostati in alto */}
            <div className="bg-gradient-to-r from-brand-dark to-brand-cyan p-4 sm:p-6 rounded-lg shadow-lg mb-6 text-white">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
                    <h2 className="text-xl sm:text-2xl font-bold">👤 Dati Professionista</h2>
                    {!isEditingProfile && (
                        <button
                            onClick={() => setIsEditingProfile(true)}
                            className="bg-white text-brand-dark px-4 py-2 rounded-lg hover:bg-zinc-100 transition-colors font-semibold text-sm"
                        >
                            ✏️ Modifica Dati
                        </button>
                    )}
                </div>

                {isEditingProfile ? (
                    <div className="space-y-3 bg-white p-4 rounded-lg">
                        <input
                            type="text"
                            name="ragioneSociale"
                            placeholder="Ragione Sociale"
                            value={profileData.ragioneSociale}
                            onChange={handleProfileDataChange}
                            className="w-full p-3 border border-zinc-300 rounded-lg text-zinc-800 focus:ring-2 focus:ring-brand-cyan focus:border-transparent"
                        />
                        <input
                            type="text"
                            name="partitaIva"
                            placeholder="Partita IVA"
                            value={profileData.partitaIva}
                            onChange={handleProfileDataChange}
                            className="w-full p-3 border border-zinc-300 rounded-lg text-zinc-800 focus:ring-2 focus:ring-brand-cyan focus:border-transparent"
                        />
                        <input
                            type="text"
                            name="indirizzo"
                            placeholder="Indirizzo Sede Legale"
                            value={profileData.indirizzo}
                            onChange={handleProfileDataChange}
                            className="w-full p-3 border border-zinc-300 rounded-lg text-zinc-800 focus:ring-2 focus:ring-brand-cyan focus:border-transparent"
                        />
                        <input
                            type="email"
                            name="emailContatto"
                            placeholder="Email di Contatto"
                            value={profileData.emailContatto}
                            onChange={handleProfileDataChange}
                            className="w-full p-3 border border-zinc-300 rounded-lg text-zinc-800 focus:ring-2 focus:ring-brand-cyan focus:border-transparent"
                        />
                        <input
                            type="tel"
                            name="telefono"
                            placeholder="Telefono"
                            value={profileData.telefono}
                            onChange={handleProfileDataChange}
                            className="w-full p-3 border border-zinc-300 rounded-lg text-zinc-800 focus:ring-2 focus:ring-brand-cyan focus:border-transparent"
                        />
                        <div className="flex gap-2 pt-2">
                            <button
                                onClick={handleProfileSave}
                                className="flex-1 bg-brand-dark text-white font-semibold py-3 px-4 rounded-lg hover:opacity-90 transition-colors"
                            >
                                💾 Salva
                            </button>
                            <button
                                onClick={() => setIsEditingProfile(false)}
                                className="flex-1 bg-zinc-300 text-zinc-800 font-semibold py-3 px-4 rounded-lg hover:bg-zinc-400 transition-colors"
                            >
                                ❌ Annulla
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                        {Object.values(profileData).some(val => val) ? (
                            <>
                                {profileData.ragioneSociale && (
                                    <div className="bg-white/10 backdrop-blur-sm p-3 rounded-lg">
                                        <p className="text-white/70 text-xs mb-1">Ragione Sociale</p>
                                        <p className="font-semibold">{profileData.ragioneSociale}</p>
                                    </div>
                                )}
                                {profileData.partitaIva && (
                                    <div className="bg-white/10 backdrop-blur-sm p-3 rounded-lg">
                                        <p className="text-white/70 text-xs mb-1">P.IVA</p>
                                        <p className="font-semibold">{profileData.partitaIva}</p>
                                    </div>
                                )}
                                {profileData.indirizzo && (
                                    <div className="bg-white/10 backdrop-blur-sm p-3 rounded-lg">
                                        <p className="text-white/70 text-xs mb-1">Indirizzo</p>
                                        <p className="font-semibold">{profileData.indirizzo}</p>
                                    </div>
                                )}
                                {profileData.emailContatto && (
                                    <div className="bg-white/10 backdrop-blur-sm p-3 rounded-lg">
                                        <p className="text-white/70 text-xs mb-1">Email</p>
                                        <p className="font-semibold break-all">{profileData.emailContatto}</p>
                                    </div>
                                )}
                                {profileData.telefono && (
                                    <div className="bg-white/10 backdrop-blur-sm p-3 rounded-lg">
                                        <p className="text-white/70 text-xs mb-1">Telefono</p>
                                        <p className="font-semibold">{profileData.telefono}</p>
                                    </div>
                                )}
                            </>
                        ) : (
                            <p className="text-white/80 italic col-span-full text-center py-4">
                                Nessun dato professionale impostato. Clicca su 'Modifica Dati' per aggiungerli.
                            </p>
                        )}
                    </div>
                )}
            </div>


            {/* Render della vista corrente */}
            {viewMode === 'main' && renderMainView()}
            {viewMode === 'sessions' && renderSessionsView()}
            {viewMode === 'archive' && renderArchiveView()}

            {/* Import Project Dialog */}
            {showImportDialog && (
                <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg p-4 sm:p-6 max-h-[90vh] overflow-y-auto">
                        <h3 className="text-lg sm:text-xl font-bold text-zinc-800 mb-4">📥 Importa Progetto Esterno</h3>
                        <p className="text-zinc-600 mb-4 text-xs sm:text-sm">
                            Carica un file JSON contenente i dati del progetto. Il file deve includere almeno:
                        </p>
                        <pre className="bg-zinc-100 p-3 rounded text-xs mb-4 overflow-x-auto">
{`{
  "projectName": "Nome progetto",
  "location": "Località lavori",
  "descriptionItems": ["Descrizione 1", "..."],
  "committente": {
    "nome": "Nome",
    "cognome": "Cognome",
    "codiceFiscale": "CF",
    "indirizzo": "Indirizzo"
  }
}`}
                        </pre>
                        <input
                            type="file"
                            accept=".json"
                            onChange={handleImportProject}
                            className="w-full p-2 sm:p-3 border border-zinc-300 rounded-lg mb-4 text-sm"
                        />
                        <div className="flex gap-3">
                            <button
                                onClick={() => setShowImportDialog(false)}
                                className="flex-1 bg-zinc-300 text-zinc-800 font-bold py-2 sm:py-3 px-4 rounded-lg hover:bg-zinc-400 transition-colors text-sm sm:text-base"
                            >
                                ❌ Annulla
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default UserDashboard;