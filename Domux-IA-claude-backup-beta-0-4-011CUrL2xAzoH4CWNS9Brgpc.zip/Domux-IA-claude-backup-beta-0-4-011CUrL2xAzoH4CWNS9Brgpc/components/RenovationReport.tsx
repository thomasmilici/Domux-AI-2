import React, { useState } from 'react';
import { GenerationResult, ProjectSession, GroundingChunk, ComputoItem } from '../types';
import { User } from '../services/firebase';
import ResultsTable from './ResultsTable';
import ComputoEditor from './ComputoEditor';

interface RenovationReportProps {
  user: User;
  result: GenerationResult;
  userInput: string;
  projectName?: string; // Project title for download filename
  location: string;
  committente?: ProjectSession['context']['committente'];
  onEdit?: (editedItems: ComputoItem[], editedReport: string) => void;
  showBackButton?: boolean;
  onGoBack?: () => void;
}

// Helper function to trigger file download for blobs (PDF/CSV)
const triggerDownload = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};


const RenovationReport: React.FC<RenovationReportProps> = ({
  user,
  result,
  userInput,
  projectName,
  location,
  committente,
  onEdit,
  showBackButton = false,
  onGoBack,
}) => {
  const { computoItems, generatedImageUrl, reportText, metadata, pdfDownloadUrl, pdfBlob, sources } = result;
  const [isEditing, setIsEditing] = useState(false);

  const handleEditSave = (editedItems: ComputoItem[], editedReport: string) => {
    setIsEditing(false);
    if (onEdit) {
      onEdit(editedItems, editedReport);
    }
  };

  const sanitizeForFilename = (input: string): string => {
    const sanitized = input.replace(/[/\\?%*:|"<>]/g, '').replace(/\s+/g, '_');
    return sanitized.length > 100 ? sanitized.substring(0, 100) : sanitized;
  };
  // Use projectName (title) if available, otherwise fallback to userInput (description)
  const baseFilename = sanitizeForFilename(projectName || userInput || 'progetto');
  
  const handleDownloadPdf = async () => {
    try {
      let blob: Blob;

      if (pdfBlob) {
        // Use the local blob if available
        blob = pdfBlob;
      } else if (pdfDownloadUrl) {
        // Fetch from Firebase Storage
        const response = await fetch(pdfDownloadUrl);
        if (!response.ok) throw new Error('PDF non disponibile o eliminato');
        blob = await response.blob();
      } else {
        alert('PDF non disponibile per questo progetto.');
        return;
      }

      triggerDownload(blob, `${baseFilename}.pdf`);
    } catch (error) {
      console.error('Errore durante il download del PDF:', error);
      alert('PDF non disponibile o eliminato dal server. Puoi duplicare il progetto per rigenerarlo.');
    }
  };

  const handleDownloadCsv = () => {
    const headers = ["N.","Codice Art.","Descrizione Lavori","U.M.","Quantità","Prezzo Unit.","Importo"];
    const csvRows = [headers.join(';')];

    for (const item of computoItems) {
      const values = [
        item.id,
        item.codice_articolo,
        `"${item.descrizione.replace(/"/g, '""')}"`,
        item.um,
        (item.quantita || 0).toLocaleString('it-IT', { useGrouping: false }),
        (item.prezzo_unitario || 0).toLocaleString('it-IT', { useGrouping: false }),
        (item.importo || 0).toLocaleString('it-IT', { useGrouping: false })
      ];
      csvRows.push(values.join(';'));
    }

    const total = computoItems.reduce((sum, item) => sum + (item.importo || 0), 0);
    csvRows.push('');
    csvRows.push(['', '', '', '', '', 'TOTALE (IVA esclusa)', total.toLocaleString('it-IT', { minimumFractionDigits: 2, useGrouping: false })].join(';'));

    const csvContent = csvRows.join('\n');
    const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' });
    triggerDownload(blob, `${baseFilename}.csv`);
  };

  const handleDownloadXlsx = () => {
    const headers = ["N.","Codice Art.","Descrizione Lavori","U.M.","Quantità","Prezzo Unit. (€)","Importo (€)"];
    let htmlTable = '<table border="1"><thead><tr>' + headers.map(h => `<th>${h}</th>`).join('') + '</tr></thead><tbody>';

    // Excel row numbers start from 2 (row 1 is header)
    let rowNum = 2;
    for (const item of computoItems) {
      htmlTable += `<tr>
        <td style="text-align:center">${item.id}</td>
        <td style="white-space:pre-wrap;max-width:150px">${item.codice_articolo}</td>
        <td style="white-space:pre-wrap;max-width:300px">${item.descrizione}</td>
        <td style="text-align:center;white-space:pre-wrap">${item.um}</td>
        <td style="text-align:right">${item.quantita}</td>
        <td style="text-align:right">${item.prezzo_unitario}</td>
        <td style="text-align:right" x:num x:fmla="=E${rowNum}*F${rowNum}">${item.importo.toFixed(2)}</td>
      </tr>`;
      rowNum++;
    }

    // Total row with SUM formula
    const lastRow = rowNum - 1;
    htmlTable += `<tr style="font-weight:bold;background-color:#f4f4f5">
      <td colspan="6" style="text-align:right">TOTALE (IVA esclusa)</td>
      <td style="text-align:right" x:num x:fmla="=SUM(G2:G${lastRow})">${computoItems.reduce((sum, item) => sum + (item.importo || 0), 0).toFixed(2)}</td>
    </tr></tbody></table>`;

    const excelHtml = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
      <head>
        <meta charset="UTF-8">
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>Computo Metrico</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <style>
          table{border-collapse:collapse;width:100%}
          th,td{padding:8px;border:1px solid #ddd;white-space:normal;word-wrap:break-word}
          th{background-color:#0D2C54;color:white;font-weight:bold}
          td{vertical-align:top}
        </style>
      </head>
      <body>${htmlTable}</body></html>`;

    const blob = new Blob([excelHtml], { type: 'application/vnd.ms-excel' });
    triggerDownload(blob, `${baseFilename}.xls`);
  };

  // Show editor if editing
  if (isEditing) {
    return (
      <ComputoEditor
        computoItems={computoItems}
        reportText={reportText}
        onSave={handleEditSave}
        onCancel={() => setIsEditing(false)}
      />
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto bg-white p-8 rounded-xl shadow-lg animate-fade-in print:shadow-none print:p-0">
      <header className="mb-8 print:hidden">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-3xl font-bold text-brand-dark">
            Risultato del Progetto
          </h1>
          {showBackButton && onGoBack && (
            <button
              onClick={onGoBack}
              className="bg-zinc-200 text-zinc-800 font-bold py-2 px-4 rounded-lg hover:bg-zinc-300 transition-colors flex items-center gap-2"
            >
              ← Torna Indietro
            </button>
          )}
        </div>
        <p className="text-zinc-600">
          Ecco l'analisi dettagliata, il computo metrico e la visualizzazione
          del tuo progetto certificato.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <button
            onClick={() => setIsEditing(true)}
            className="bg-orange-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-orange-700 transition-colors"
          >
            ✎ Modifica Computo
          </button>

          <button
            onClick={handleDownloadPdf}
            disabled={!pdfBlob && !pdfDownloadUrl}
            className="bg-brand-dark text-white font-bold py-2 px-4 rounded-lg hover:opacity-90 transition-colors disabled:bg-zinc-400 disabled:cursor-not-allowed"
          >
            📄 Scarica PDF Certificato
          </button>

          <button
            onClick={handleDownloadXlsx}
            className="bg-green-700 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-800 transition-colors"
          >
            📊 Esporta Excel (XLS)
          </button>

          <button
            onClick={handleDownloadCsv}
            className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
          >
            📑 Esporta CSV
          </button>
        </div>
      </header>

      <div className="space-y-12">
        <section>
          <h2 className="text-2xl font-bold text-brand-dark mb-4 border-b pb-2">
            Riepilogo e Visualizzazione
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-lg text-zinc-800 mb-2">
                Dati del Progetto
              </h3>
              <p>
                <strong className="font-medium text-zinc-600">
                  Descrizione:
                </strong>{' '}
                {userInput}
              </p>
              <p>
                <strong className="font-medium text-zinc-600">Località:</strong>{' '}
                {location}
              </p>

              {committente && <div className="mt-4">
                 <h3 className="font-semibold text-lg text-zinc-800 mb-2">
                    Dati Committente
                 </h3>
                 <p><strong className="font-medium text-zinc-600">Nominativo:</strong> {committente.nome} {committente.cognome}</p>
                 <p><strong className="font-medium text-zinc-600">C.F./P.IVA:</strong> {committente.codiceFiscale}</p>
                 <p><strong className="font-medium text-zinc-600">Indirizzo:</strong> {committente.indirizzo}</p>
              </div>}

              <h3 className="font-semibold text-lg text-zinc-800 mt-6 mb-2">
                Relazione Tecnica
              </h3>
              <div className="text-zinc-700 whitespace-pre-wrap prose prose-sm max-w-none">
                {reportText}
              </div>
            </div>

            <div className="space-y-6">
              {result.originalImageUrl && (
                <div>
                  <h3 className="font-semibold text-lg text-zinc-800 mb-2">
                    Prima dei Lavori
                  </h3>
                  <img
                    src={result.originalImageUrl}
                    alt="Stato attuale"
                    className="w-full rounded-lg shadow-md"
                  />
                </div>
              )}
              {generatedImageUrl && (
                <div>
                  <h3 className="font-semibold text-lg text-zinc-800 mb-2">
                    Risultato Proposto
                  </h3>
                  <img
                    src={generatedImageUrl}
                    alt="Risultato generato"
                    className="w-full rounded-lg shadow-md"
                  />
                </div>
              )}
            </div>
          </div>
        </section>

        <section>
          <ResultsTable items={computoItems} />
        </section>

        {sources && sources.length > 0 && (
          <section className="bg-blue-50 p-6 rounded-lg">
            <h2 className="text-2xl font-bold text-brand-dark mb-4 border-b pb-2">
              Fonti e Riferimenti Web
            </h2>
            <p className="text-sm text-zinc-700 mb-4">
              L'AI ha consultato le seguenti fonti per generare questo computo. Si consiglia di verificarle per un'analisi approfondita.
            </p>
            <ul className="space-y-2">
              {sources.map((source, index) => source.web && (
                <li key={index} className="text-sm">
                  <a 
                    href={source.web.uri} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 hover:underline break-words"
                  >
                    {source.web.title || source.web.uri}
                  </a>
                </li>
              ))}
            </ul>
          </section>
        )}
        
        <section className="bg-zinc-50 p-6 rounded-lg">
          <h2 className="text-2xl font-bold text-brand-dark mb-4 border-b pb-2">
            Informazioni di Certificazione
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 text-sm text-zinc-700">
            <p><strong>Codice Computo:</strong> {metadata.readableId}</p>
            <p><strong>UUID:</strong> {metadata.uuid}</p>
            <p><strong>Data Generazione (UTC):</strong> {new Date(metadata.timestamp).toLocaleString('it-IT', { timeZone: 'UTC' })}</p>
            <p><strong>Versione Generatore:</strong> {metadata.generatorVersion}</p>
            {metadata.parentId && <p><strong>Progetto Padre (UUID):</strong> {metadata.parentId}</p>}
          </div>
          <div className="mt-4">
            <p><strong>Hash SHA-256 del contenuto:</strong></p>
            <p className="font-mono text-xs break-all bg-zinc-200 p-2 rounded mt-1">{metadata.hash}</p>
          </div>
        </section>

      </div>
    </div>
  );
};

export default RenovationReport;