import React, { useState, useEffect } from 'react';
import { db, getDocs, collection, query, orderBy, limit, where } from '../services/firebase';

interface LogEntry {
  id: string;
  level: 'log' | 'warn' | 'error';
  message: string;
  timestamp?: any;
  timestampISO?: string;
  userId?: string;
  sessionId?: string;
  userAgent?: string;
  context?: any;
}

const LogViewer: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'error' | 'warn' | 'log'>('all');

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const logsQuery = query(
        collection(db, 'logs'),
        orderBy('timestamp', 'desc'),
        limit(100)
      );

      const snapshot = await getDocs(logsQuery);
      const logsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as LogEntry[];

      setLogs(logsData);
    } catch (error) {
      console.error('Error loading logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredLogs = filter === 'all'
    ? logs
    : logs.filter(log => log.level === filter);

  const errorCount = logs.filter(l => l.level === 'error').length;
  const warnCount = logs.filter(l => l.level === 'warn').length;

  if (loading) {
    return <div className="p-4">Caricamento log...</div>;
  }

  return (
    <div className="p-4 bg-gray-900 text-gray-100 h-screen overflow-auto font-mono text-sm">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">📋 Log Viewer</h1>
        <button
          onClick={loadLogs}
          className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded"
        >
          🔄 Ricarica
        </button>
      </div>

      {/* Stats */}
      <div className="mb-4 grid grid-cols-4 gap-4">
        <div className="bg-gray-800 p-3 rounded">
          <div className="text-gray-400 text-xs">Totale</div>
          <div className="text-2xl font-bold">{logs.length}</div>
        </div>
        <div className="bg-red-900 p-3 rounded">
          <div className="text-red-300 text-xs">Errori</div>
          <div className="text-2xl font-bold">{errorCount}</div>
        </div>
        <div className="bg-yellow-900 p-3 rounded">
          <div className="text-yellow-300 text-xs">Warning</div>
          <div className="text-2xl font-bold">{warnCount}</div>
        </div>
        <div className="bg-blue-900 p-3 rounded">
          <div className="text-blue-300 text-xs">Info</div>
          <div className="text-2xl font-bold">{logs.length - errorCount - warnCount}</div>
        </div>
      </div>

      {/* Filters */}
      <div className="mb-4 flex gap-2">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded ${filter === 'all' ? 'bg-blue-600' : 'bg-gray-700'}`}
        >
          Tutti ({logs.length})
        </button>
        <button
          onClick={() => setFilter('error')}
          className={`px-4 py-2 rounded ${filter === 'error' ? 'bg-red-600' : 'bg-gray-700'}`}
        >
          Errori ({errorCount})
        </button>
        <button
          onClick={() => setFilter('warn')}
          className={`px-4 py-2 rounded ${filter === 'warn' ? 'bg-yellow-600' : 'bg-gray-700'}`}
        >
          Warning ({warnCount})
        </button>
        <button
          onClick={() => setFilter('log')}
          className={`px-4 py-2 rounded ${filter === 'log' ? 'bg-blue-600' : 'bg-gray-700'}`}
        >
          Info ({logs.length - errorCount - warnCount})
        </button>
      </div>

      {/* Logs */}
      <div className="space-y-2">
        {filteredLogs.length === 0 ? (
          <div className="text-gray-400 p-4 text-center">
            Nessun log trovato
          </div>
        ) : (
          filteredLogs.map((log, index) => {
            const levelColors = {
              error: 'bg-red-900 border-red-700 text-red-100',
              warn: 'bg-yellow-900 border-yellow-700 text-yellow-100',
              log: 'bg-gray-800 border-gray-700 text-gray-100'
            };

            const levelIcons = {
              error: '🔴',
              warn: '⚠️',
              log: 'ℹ️'
            };

            return (
              <div
                key={log.id}
                className={`border-l-4 p-3 rounded ${levelColors[log.level]}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span>{levelIcons[log.level]}</span>
                    <span className="font-bold uppercase">{log.level}</span>
                    <span className="text-xs opacity-60">
                      {log.timestampISO || 'N/A'}
                    </span>
                  </div>
                  <div className="text-xs opacity-60">
                    #{index + 1}
                  </div>
                </div>

                <div className="mb-2 font-semibold">
                  {log.message}
                </div>

                {log.userId && (
                  <div className="text-xs opacity-75">
                    👤 User: {log.userId}
                  </div>
                )}

                {log.sessionId && (
                  <div className="text-xs opacity-75">
                    📝 Session: {log.sessionId}
                  </div>
                )}

                {log.context && (
                  <details className="mt-2">
                    <summary className="cursor-pointer text-xs opacity-75 hover:opacity-100">
                      📄 Context / Stack Trace
                    </summary>
                    <pre className="mt-2 p-2 bg-black rounded text-xs overflow-auto max-h-64">
                      {JSON.stringify(log.context, null, 2)}
                    </pre>
                  </details>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default LogViewer;
