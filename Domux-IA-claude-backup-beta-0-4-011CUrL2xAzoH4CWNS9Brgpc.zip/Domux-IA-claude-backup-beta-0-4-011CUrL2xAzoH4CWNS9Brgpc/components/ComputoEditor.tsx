import React, { useState } from 'react';
import { ComputoItem } from '../types';

interface ComputoEditorProps {
    computoItems: ComputoItem[];
    reportText: string;
    onSave: (items: ComputoItem[], report: string) => void;
    onCancel: () => void;
}

const ComputoEditor: React.FC<ComputoEditorProps> = ({ computoItems, reportText, onSave, onCancel }) => {
    const [items, setItems] = useState<ComputoItem[]>(computoItems);
    const [report, setReport] = useState(reportText);
    const [editingId, setEditingId] = useState<number | null>(null);

    const handleItemChange = (id: number, field: keyof ComputoItem, value: string | number) => {
        setItems(items.map(item => {
            if (item.id === id) {
                const updated = { ...item, [field]: value };
                // Ricalcola importo se cambiano quantità o prezzo
                if (field === 'quantita' || field === 'prezzo_unitario') {
                    updated.importo = updated.quantita * updated.prezzo_unitario;
                }
                return updated;
            }
            return item;
        }));
    };

    const handleDeleteItem = (id: number) => {
        if (window.confirm('Sei sicuro di voler eliminare questa voce?')) {
            setItems(items.filter(item => item.id !== id));
        }
    };

    const handleAddItem = () => {
        const newId = Math.max(...items.map(i => i.id), 0) + 1;
        const newItem: ComputoItem = {
            id: newId,
            codice_articolo: 'N.D.',
            descrizione: 'Nuova voce',
            um: 'cad',
            quantita: 1,
            prezzo_unitario: 0,
            importo: 0,
        };
        setItems([...items, newItem]);
        setEditingId(newId);
    };

    const handleSave = () => {
        onSave(items, report);
    };

    const totalAmount = items.reduce((sum, item) => sum + item.importo, 0);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 overflow-y-auto">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-6xl max-h-[95vh] overflow-y-auto">
                <div className="sticky top-0 bg-white border-b p-4 sm:p-6 z-10">
                    <h2 className="text-2xl font-bold text-zinc-800">Modifica Computo Prima dell'Esportazione</h2>
                    <p className="text-zinc-600 mt-1">Rivedi e modifica i dati prima di generare il PDF certificato.</p>
                </div>

                <div className="p-4 sm:p-6 space-y-6">
                    {/* Relazione Tecnica */}
                    <div className="bg-zinc-50 p-4 rounded-lg border">
                        <h3 className="font-bold text-zinc-800 mb-2">Relazione Tecnica</h3>
                        <textarea
                            value={report}
                            onChange={(e) => setReport(e.target.value)}
                            className="w-full p-3 border rounded-lg font-mono text-sm min-h-[150px]"
                            placeholder="Relazione tecnica..."
                        />
                    </div>

                    {/* Tabella Computo con Header Fisso */}
                    <div className="bg-zinc-50 p-4 rounded-lg border">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-bold text-zinc-800">Voci di Computo</h3>
                            <button
                                onClick={handleAddItem}
                                className="bg-green-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-green-700 text-sm"
                            >
                                + Aggiungi Voce
                            </button>
                        </div>

                        {/* Tabella con scroll e header fisso */}
                        <div className="border rounded-lg overflow-hidden">
                            <div className="overflow-x-auto">
                                <div className="max-h-[500px] overflow-y-auto">
                                    <table className="w-full text-sm">
                                        <thead className="bg-brand-dark text-white sticky top-0 z-10 shadow-md">
                                            <tr>
                                                <th className="p-3 text-left font-semibold">N.</th>
                                                <th className="p-3 text-left font-semibold">Codice</th>
                                                <th className="p-3 text-left font-semibold">Descrizione</th>
                                                <th className="p-3 text-left font-semibold">U.M.</th>
                                                <th className="p-3 text-right font-semibold">Qtà</th>
                                                <th className="p-3 text-right font-semibold">P.U. (€)</th>
                                                <th className="p-3 text-right font-semibold">Importo (€)</th>
                                                <th className="p-3 text-center font-semibold">Azioni</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white">
                                            {items.map(item => (
                                                <tr key={item.id} className="border-b hover:bg-blue-50 transition-colors">
                                                    <td className="p-3 font-medium text-zinc-600">{item.id}</td>
                                                    <td className="p-3">
                                                        {editingId === item.id ? (
                                                            <input
                                                                type="text"
                                                                value={item.codice_articolo}
                                                                onChange={(e) => handleItemChange(item.id, 'codice_articolo', e.target.value)}
                                                                className="w-full p-2 border-2 border-blue-400 rounded text-sm focus:outline-none focus:border-blue-600"
                                                            />
                                                        ) : (
                                                            <span
                                                                onClick={() => setEditingId(item.id)}
                                                                className="cursor-pointer hover:text-blue-600 hover:underline block"
                                                                title="Clicca per modificare"
                                                            >
                                                                {item.codice_articolo}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="p-3">
                                                        {editingId === item.id ? (
                                                            <textarea
                                                                value={item.descrizione}
                                                                onChange={(e) => handleItemChange(item.id, 'descrizione', e.target.value)}
                                                                className="w-full p-2 border-2 border-blue-400 rounded text-sm focus:outline-none focus:border-blue-600 min-h-[60px]"
                                                                rows={2}
                                                            />
                                                        ) : (
                                                            <span
                                                                onClick={() => setEditingId(item.id)}
                                                                className="cursor-pointer hover:text-blue-600 hover:underline block"
                                                                title="Clicca per modificare"
                                                            >
                                                                {item.descrizione}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="p-3">
                                                        {editingId === item.id ? (
                                                            <input
                                                                type="text"
                                                                value={item.um}
                                                                onChange={(e) => handleItemChange(item.id, 'um', e.target.value)}
                                                                className="w-20 p-2 border-2 border-blue-400 rounded text-sm focus:outline-none focus:border-blue-600"
                                                            />
                                                        ) : (
                                                            <span
                                                                onClick={() => setEditingId(item.id)}
                                                                className="cursor-pointer hover:text-blue-600 hover:underline"
                                                                title="Clicca per modificare"
                                                            >
                                                                {item.um}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="p-3 text-right">
                                                        {editingId === item.id ? (
                                                            <input
                                                                type="number"
                                                                step="0.01"
                                                                value={item.quantita}
                                                                onChange={(e) => handleItemChange(item.id, 'quantita', parseFloat(e.target.value) || 0)}
                                                                className="w-24 p-2 border-2 border-blue-400 rounded text-sm text-right focus:outline-none focus:border-blue-600"
                                                            />
                                                        ) : (
                                                            <span
                                                                onClick={() => setEditingId(item.id)}
                                                                className="cursor-pointer hover:text-blue-600 hover:underline"
                                                                title="Clicca per modificare"
                                                            >
                                                                {item.quantita.toLocaleString('it-IT')}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="p-3 text-right">
                                                        {editingId === item.id ? (
                                                            <input
                                                                type="number"
                                                                step="0.01"
                                                                value={item.prezzo_unitario}
                                                                onChange={(e) => handleItemChange(item.id, 'prezzo_unitario', parseFloat(e.target.value) || 0)}
                                                                className="w-28 p-2 border-2 border-blue-400 rounded text-sm text-right focus:outline-none focus:border-blue-600"
                                                            />
                                                        ) : (
                                                            <span
                                                                onClick={() => setEditingId(item.id)}
                                                                className="cursor-pointer hover:text-blue-600 hover:underline"
                                                                title="Clicca per modificare"
                                                            >
                                                                €{item.prezzo_unitario.toLocaleString('it-IT', { minimumFractionDigits: 2 })}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="p-3 text-right font-bold text-green-700">
                                                        €{item.importo.toLocaleString('it-IT', { minimumFractionDigits: 2 })}
                                                    </td>
                                                    <td className="p-3 text-center">
                                                        <div className="flex gap-2 justify-center">
                                                            {editingId === item.id ? (
                                                                <button
                                                                    onClick={() => setEditingId(null)}
                                                                    className="bg-green-600 text-white px-3 py-1 rounded-md text-sm hover:bg-green-700 font-semibold shadow"
                                                                    title="Salva modifiche"
                                                                >
                                                                    ✓ Salva
                                                                </button>
                                                            ) : (
                                                                <button
                                                                    onClick={() => setEditingId(item.id)}
                                                                    className="bg-blue-600 text-white px-3 py-1 rounded-md text-sm hover:bg-blue-700 font-semibold shadow"
                                                                    title="Modifica voce"
                                                                >
                                                                    ✎ Modifica
                                                                </button>
                                                            )}
                                                            <button
                                                                onClick={() => handleDeleteItem(item.id)}
                                                                className="bg-red-600 text-white px-3 py-1 rounded-md text-sm hover:bg-red-700 font-semibold shadow"
                                                                title="Elimina voce"
                                                            >
                                                                🗑 Elimina
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                        <tfoot className="bg-gradient-to-r from-green-50 to-green-100 font-bold sticky bottom-0 shadow-md">
                                            <tr>
                                                <td colSpan={6} className="p-4 text-right text-zinc-800 text-lg">TOTALE (IVA esclusa)</td>
                                                <td className="p-4 text-right text-xl text-green-700">
                                                    {totalAmount.toLocaleString('it-IT', { style: 'currency', currency: 'EUR' })}
                                                </td>
                                                <td></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="sticky bottom-0 bg-white border-t p-4 sm:p-6 flex gap-3">
                    <button
                        onClick={handleSave}
                        className="flex-1 bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 transition-colors"
                    >
                        Conferma e Genera PDF Certificato
                    </button>
                    <button
                        onClick={onCancel}
                        className="bg-zinc-300 text-zinc-800 font-bold py-3 px-6 rounded-lg hover:bg-zinc-400 transition-colors"
                    >
                        Annulla
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ComputoEditor;
