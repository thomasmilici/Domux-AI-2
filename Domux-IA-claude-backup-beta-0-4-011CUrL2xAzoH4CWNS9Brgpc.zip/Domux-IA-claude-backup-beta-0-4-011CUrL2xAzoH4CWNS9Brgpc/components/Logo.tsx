import React from 'react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className }) => {
  return (
    <svg 
      viewBox="0 0 100 85" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className} 
      aria-label="Domux AI Logo"
    >
      <g>
        {/* Circle background */}
        <circle cx="50" cy="42.5" r="38" stroke="#2EC4B6" strokeWidth="4" fill="none" />
        
        {/* House structure */}
        <path d="M15 47.5 L15 82.5 L85 82.5 L85 47.5" stroke="#0D2C54" strokeWidth="4" fill="none" strokeLinejoin="round" strokeLinecap="round"/>
        {/* Roof */}
        <path d="M10 47.5 L50 12.5 L90 47.5" stroke="#0D2C54" strokeWidth="4" fill="none" strokeLinejoin="round" strokeLinecap="round"/>
        {/* Chimney */}
        <path d="M75 25 L75 37.5 L85 37.5 L85 17.5 Z" stroke="#0D2C54" strokeWidth="4" fill="white" strokeLinejoin="round" strokeLinecap="round"/>

        {/* Brain - simplified */}
        <g transform="translate(36, 40) scale(0.28)">
          <path d="M 50,5 A 24,24 0 0 1 50,53 A 12,12 0 0 1 50,29 M 50,5 A 24,24 0 0 0 50,53 A 12,12 0 0 0 50,29 M 50,17 A 12,12 0 0 1 50,41 M 50,17 A 12,12 0 0 0 50,41" fill="none" stroke="#2EC4B6" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round"/>
          <line x1="50" y1="5" x2="50" y2="53" stroke="#2EC4B6" strokeWidth="10" strokeLinecap="round" />
        </g>
      </g>
    </svg>
  );
};

export default Logo;
