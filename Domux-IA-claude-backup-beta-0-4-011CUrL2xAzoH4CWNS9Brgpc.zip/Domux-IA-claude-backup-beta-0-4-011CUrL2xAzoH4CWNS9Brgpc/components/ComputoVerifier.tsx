import React, { useState } from 'react';
import { db, collection, query, where, getDocs, limit } from '../services/firebase';
import Logger from '../services/logger';

interface VerificationResult {
    status: 'success' | 'fail' | 'error';
    message: string;
    projectData?: {
        readableId: string;
        createdAt: string;
        userInput: string;
        pdfDownloadUrl: string;
    };
}

const ComputoVerifier: React.FC = () => {
    const [readableId, setReadableId] = useState('');
    const [fileHash, setFileHash] = useState('');
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState<VerificationResult | null>(null);

    const handleVerification = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setResult(null);

        if (!readableId.trim() || !fileHash.trim()) {
            setResult({ status: 'error', message: "Per favore, inserisci sia il Codice Computo che l'Hash SHA-256." });
            setLoading(false);
            return;
        }

        try {
            const projectsRef = collection(db, 'projects');
            const q = query(
                projectsRef,
                where('metadata.readableId', '==', readableId.trim()),
                where('metadata.hash', '==', fileHash.trim().toLowerCase()),
                limit(1)
            );

            const querySnapshot = await getDocs(q);

            if (querySnapshot.empty) {
                setResult({ status: 'fail', message: "Nessun documento trovato con i dati forniti. La certificazione non è valida o i dati sono errati." });
            } else {
                const projectDoc = querySnapshot.docs[0].data();
                setResult({
                    status: 'success',
                    message: "Documento verificato con successo! I dati corrispondono a un progetto archiviato nel nostro sistema.",
                    projectData: {
                        readableId: projectDoc.metadata.readableId,
                        createdAt: new Date(projectDoc.metadata.timestamp).toLocaleString('it-IT'),
                        userInput: projectDoc.userInput,
                        pdfDownloadUrl: projectDoc.pdfDownloadUrl,
                    }
                });
            }
        } catch (err) {
            Logger.error("Error during computo verification:", err);
            setResult({ status: 'error', message: "Si è verificato un errore durante la verifica. Riprova più tardi." });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="w-full max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-lg">
            <h2 className="text-2xl font-bold text-zinc-800 mb-2">Verifica Certificazione Computo</h2>
            <p className="text-zinc-600 mb-6">Inserisci i dati presenti sul documento PDF per verificarne l'autenticità.</p>
            
            <form onSubmit={handleVerification} className="space-y-4">
                <div>
                    <label htmlFor="readableId" className="block text-zinc-700 text-sm font-bold mb-2">
                        Codice Computo
                    </label>
                    <input
                        type="text"
                        id="readableId"
                        value={readableId}
                        onChange={(e) => setReadableId(e.target.value)}
                        className="w-full p-3 border border-zinc-300 rounded-lg focus:ring-2 focus:ring-brand-cyan"
                        placeholder="Es. CM-2024-01-01-0001"
                        required
                    />
                </div>
                <div>
                    <label htmlFor="fileHash" className="block text-zinc-700 text-sm font-bold mb-2">
                        Hash SHA-256 del contenuto
                    </label>
                    <textarea
                        id="fileHash"
                        value={fileHash}
                        onChange={(e) => setFileHash(e.target.value)}
                        className="w-full p-3 border border-zinc-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-brand-cyan"
                        rows={3}
                        placeholder="Incolla l'hash SHA-256 qui..."
                        required
                    />
                </div>
                <button type="submit" disabled={loading} className="w-full bg-brand-dark text-white font-bold py-3 px-4 rounded-lg hover:opacity-90 disabled:bg-zinc-400 transition-colors">
                    {loading ? 'Verifica in corso...' : 'Verifica Documento'}
                </button>
            </form>

            {result && (
                <div className="mt-6 p-4 rounded-lg"
                    style={{
                        backgroundColor: result.status === 'success' ? '#f0fdf4' : result.status === 'fail' ? '#fff1f2' : '#fffbeb',
                        borderLeft: `4px solid ${result.status === 'success' ? '#22c55e' : result.status === 'fail' ? '#ef4444' : '#f59e0b'}`
                    }}
                >
                    <p className="font-bold" style={{ color: result.status === 'success' ? '#166534' : result.status === 'fail' ? '#991b1b' : '#92400e' }}>
                        {result.status === 'success' ? 'Verifica Riuscita' : result.status === 'fail' ? 'Verifica Fallita' : 'Errore'}
                    </p>
                    <p className="text-sm" style={{ color: result.status === 'success' ? '#15803d' : result.status === 'fail' ? '#b91c1c' : '#b45309' }}>
                        {result.message}
                    </p>
                    {result.status === 'success' && result.projectData && (
                        <div className="mt-4 pt-4 border-t border-green-200 text-sm text-green-900 space-y-1">
                             <p><strong>Codice:</strong> {result.projectData.readableId}</p>
                             <p><strong>Data:</strong> {result.projectData.createdAt}</p>
                             <p><strong>Descrizione:</strong> {result.projectData.userInput}</p>
                             <a href={result.projectData.pdfDownloadUrl} target="_blank" rel="noopener noreferrer" className="text-green-700 font-bold hover:underline">
                                Scarica una copia del documento originale
                             </a>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default ComputoVerifier;
