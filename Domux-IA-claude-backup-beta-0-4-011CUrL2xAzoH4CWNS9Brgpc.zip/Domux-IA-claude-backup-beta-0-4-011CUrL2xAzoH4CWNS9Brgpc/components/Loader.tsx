
import React from 'react';

interface LoaderProps {
  message: string;
}

const Loader: React.FC<LoaderProps> = ({ message }) => {
  return (
    <div className="fixed inset-0 bg-white bg-opacity-95 flex flex-col items-center justify-center p-8 text-center z-50">
      <div className="bg-white p-8 rounded-xl shadow-2xl max-w-md w-full">
        <div className="animate-spin rounded-full h-20 w-20 border-b-4 border-t-4 border-teal-600 mb-6 mx-auto"></div>
        <p className="text-zinc-800 font-bold text-xl mb-3">Elaborazione in corso...</p>
        <p className="text-zinc-600 text-base min-h-[3rem] leading-relaxed">{message}</p>
        <p className="text-zinc-400 text-sm mt-4 italic">Questa operazione può richiedere fino a 60 secondi. Attendere prego...</p>
      </div>
    </div>
  );
};

export default Loader;
