import React from 'react';
import { ComputoItem } from '../types';

interface ResultsTableProps {
  items: ComputoItem[];
}

const ResultsTable: React.FC<ResultsTableProps> = ({ items }) => {
  const total = items.reduce((sum, item) => sum + item.importo, 0);

  const formatCurrency = (value: number) => {
    return value.toLocaleString('it-IT', { style: 'currency', currency: 'EUR' });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg w-full animate-fade-in mt-6">
       <h3 className="text-2xl font-bold text-brand-dark mb-4">Computo Metrico Dettagliato</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-zinc-500">
          <thead className="text-xs text-white uppercase bg-brand-cyan">
            <tr>
              <th scope="col" className="px-6 py-3 w-12">N.</th>
              <th scope="col" className="px-6 py-3">Codice Art.</th>
              <th scope="col" className="px-6 py-3">Descrizione Lavori</th>
              <th scope="col" className="px-6 py-3">U.M.</th>
              <th scope="col" className="px-6 py-3 text-right">Quantità</th>
              <th scope="col" className="px-6 py-3 text-right">Prezzo Unit.</th>
              <th scope="col" className="px-6 py-3 text-right">Importo</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={index} className="bg-white border-b hover:bg-zinc-50">
                <td className="px-6 py-4 font-medium text-zinc-900">{item.id}</td>
                <td className="px-6 py-4 font-mono text-xs text-zinc-600">{item.codice_articolo}</td>
                <td className="px-6 py-4 text-zinc-800">{item.descrizione}</td>
                <td className="px-6 py-4">{item.um}</td>
                <td className="px-6 py-4 text-right">{item.quantita.toLocaleString('it-IT')}</td>
                <td className="px-6 py-4 text-right">{formatCurrency(item.prezzo_unitario)}</td>
                <td className="px-6 py-4 font-semibold text-zinc-900 text-right">{formatCurrency(item.importo)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="font-semibold text-zinc-900 bg-zinc-100">
              <td colSpan={6} className="px-6 py-4 text-right text-lg">IMPORTO TOTALE (IVA esclusa)</td>
              <td className="px-6 py-4 text-right text-lg">{formatCurrency(total)}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};

export default ResultsTable;