import React, { useState, useEffect } from 'react';

interface BeforeInstallPromptEvent extends Event {
    prompt: () => Promise<void>;
    userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

const InstallPrompt: React.FC = () => {
    const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
    const [showPrompt, setShowPrompt] = useState(false);
    const [isIOS, setIsIOS] = useState(false);
    const [isInstalled, setIsInstalled] = useState(false);

    useEffect(() => {
        // Check if already installed
        if (window.matchMedia('(display-mode: standalone)').matches) {
            setIsInstalled(true);
            return;
        }

        // Check if iOS
        const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
        setIsIOS(iOS);

        // Android/Chrome/Edge install prompt
        const handleBeforeInstallPrompt = (e: Event) => {
            e.preventDefault();
            const promptEvent = e as BeforeInstallPromptEvent;
            setDeferredPrompt(promptEvent);

            // Show prompt after 3 seconds
            setTimeout(() => {
                setShowPrompt(true);
            }, 3000);
        };

        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

        // If iOS, show manual instructions after 3 seconds
        if (iOS && !isInstalled) {
            setTimeout(() => {
                setShowPrompt(true);
            }, 3000);
        }

        return () => {
            window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        };
    }, []);

    const handleInstallClick = async () => {
        if (!deferredPrompt) {
            return;
        }

        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;

        if (outcome === 'accepted') {
            console.log('✅ Utente ha accettato l\'installazione');
        } else {
            console.log('❌ Utente ha rifiutato l\'installazione');
        }

        setDeferredPrompt(null);
        setShowPrompt(false);
    };

    const handleDismiss = () => {
        setShowPrompt(false);
        // Remember dismissal for 7 days
        localStorage.setItem('install-prompt-dismissed', Date.now().toString());
    };

    // Don't show if dismissed recently (within 7 days)
    useEffect(() => {
        const dismissedTime = localStorage.getItem('install-prompt-dismissed');
        if (dismissedTime) {
            const daysSinceDismissal = (Date.now() - parseInt(dismissedTime)) / (1000 * 60 * 60 * 24);
            if (daysSinceDismissal < 7) {
                setShowPrompt(false);
            }
        }
    }, []);

    if (!showPrompt || isInstalled) {
        return null;
    }

    return (
        <div className="fixed bottom-0 left-0 right-0 z-50 p-4 animate-fade-in">
            <div className="max-w-2xl mx-auto bg-gradient-to-r from-brand-dark to-brand-cyan text-white rounded-xl shadow-2xl p-4 sm:p-6">
                <div className="flex items-start gap-4">
                    <div className="text-4xl sm:text-5xl flex-shrink-0">📱</div>
                    <div className="flex-grow min-w-0">
                        <h3 className="text-lg sm:text-xl font-bold mb-2">
                            {isIOS ? 'Aggiungi Domux AI alla Home' : 'Installa Domux AI'}
                        </h3>

                        {isIOS ? (
                            <p className="text-sm sm:text-base text-white/90 mb-3">
                                Per un'esperienza migliore, aggiungi questa app alla schermata Home:
                                <br />
                                <span className="font-semibold mt-2 block">
                                    1. Tocca il pulsante "Condividi"
                                    <span className="inline-block mx-1">⬆️</span>
                                    <br />
                                    2. Scorri e tocca "Aggiungi alla schermata Home"
                                    <span className="inline-block mx-1">➕</span>
                                </span>
                            </p>
                        ) : (
                            <p className="text-sm sm:text-base text-white/90 mb-3">
                                Installa Domux AI sul tuo dispositivo per un accesso rapido e lavoro offline.
                            </p>
                        )}

                        <div className="flex gap-2 sm:gap-3">
                            {!isIOS && deferredPrompt && (
                                <button
                                    onClick={handleInstallClick}
                                    className="bg-white text-brand-dark font-bold py-2 px-4 sm:px-6 rounded-lg hover:bg-zinc-100 transition-colors text-sm sm:text-base"
                                >
                                    ⬇️ Installa Ora
                                </button>
                            )}
                            <button
                                onClick={handleDismiss}
                                className="bg-white/20 backdrop-blur text-white font-bold py-2 px-4 rounded-lg hover:bg-white/30 transition-colors text-sm sm:text-base"
                            >
                                {isIOS ? 'Ho Capito' : 'Non Ora'}
                            </button>
                        </div>
                    </div>
                    <button
                        onClick={handleDismiss}
                        className="text-white/80 hover:text-white text-2xl flex-shrink-0 leading-none"
                        aria-label="Chiudi"
                    >
                        ×
                    </button>
                </div>
            </div>
        </div>
    );
};

export default InstallPrompt;
