import React, { useState, useEffect } from 'react';
import { db, User, doc, getDoc, addDoc, collection, serverTimestamp, storage, ref, uploadBytes, getDownloadURL } from '../services/firebase';
import { GenerationResult, ComputoItem } from '../types';
import RenovationReport from './RenovationReport';
import Loader from './Loader';
import ErrorMessage from './ErrorMessage';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { generateProfessionalPDF } from '../utils/pdfGeneration';

interface ProjectViewerProps {
    projectId: string;
    user: User;
    onGoBack: () => void;
}

// Helper to calculate SHA-256 hash
const calculateSHA256 = async (blob: Blob): Promise<string> => {
    const arrayBuffer = await blob.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex;
};

const ProjectViewer: React.FC<ProjectViewerProps> = ({ projectId, user, onGoBack }) => {
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [projectData, setProjectData] = useState<any>(null);
    const [result, setResult] = useState<GenerationResult | null>(null);
    const [isSaving, setIsSaving] = useState(false);

    // Handler for editing archived projects - Now saves to Firestore with rename
    const handleEditArchivedProject = async (editedItems: ComputoItem[], editedReport: string) => {
        if (!result || !projectData) return;

        // Ask user for new project name
        const now = new Date();
        const dateTimeString = now.toLocaleString('it-IT', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        }).replace(/[/:]/g, '-').replace(/,/g, '');

        const defaultName = `Progetto Modificato ${dateTimeString}`;
        const newName = prompt('Inserisci il nome per il progetto modificato:', defaultName);

        if (!newName) {
            alert('Operazione annullata.');
            return;
        }

        setIsSaving(true);
        setError(null);

        try {
            // Generate metadata
            const datePart = now.toISOString().split('T')[0];
            const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
            const readableId = `CM-${datePart}-${randomPart}`;

            const metadata = {
                uuid: crypto.randomUUID(),
                readableId,
                hash: '', // Will be calculated after PDF generation
                timestamp: now.toISOString(),
                generatorVersion: 'Domux AI v1.5 (Modified)',
                parentId: projectId, // Reference to original project
            };

            // Create a session object for PDF generation (using project data)
            const committente = projectData.committente || {};
            const sessionData = {
                id: projectId,
                context: {
                    location: projectData.location || 'Non specificato',
                    committente: committente,
                    descriptionItems: []
                }
            };

            // Use professional PDF generation function (with images if available)
            const tempDoc = generateProfessionalPDF(
                editedItems,
                editedReport,
                user,
                sessionData as any,
                metadata,
                projectData.originalImageUrl,
                projectData.generatedImageUrl
            );

            // Calculate hash of generated PDF
            const contentBlob = tempDoc.output('blob');
            const hash = await calculateSHA256(contentBlob);
            metadata.hash = hash;

            // Upload PDF to Firebase Storage
            const pdfStorageRef = ref(storage, `pdfs/${user.uid}/${metadata.readableId}.pdf`);
            await uploadBytes(pdfStorageRef, contentBlob);
            const pdfDownloadUrl = await getDownloadURL(pdfStorageRef);

            // Save to Firestore
            const projectDataToSave = {
                userId: user.uid,
                userInput: newName,
                projectName: newName, // Use the same name for title and description
                location: projectData.location || '',
                committente: committente,
                createdAt: serverTimestamp(),
                pdfDownloadUrl,
                metadata,
                result: {
                    computoItems: editedItems,
                    reportText: editedReport,
                }
            };

            await addDoc(collection(db, 'projects'), projectDataToSave);

            setIsSaving(false);
            alert(`✅ Progetto "${newName}" salvato con successo in archivio!\n\nPuoi trovarlo nella sezione Archivio Progetti Certificati.`);
            onGoBack(); // Return to dashboard to see the new project

        } catch (err: any) {
            console.error('Error saving modified project:', err);
            setError(`Errore durante il salvataggio: ${err.message}`);
            setIsSaving(false);
            alert(`Errore durante il salvataggio: ${err.message}`);
        }
    };

    useEffect(() => {
        const loadProject = async () => {
            try {
                setLoading(true);
                setError(null);

                const projectDocRef = doc(db, 'projects', projectId);
                const projectDoc = await getDoc(projectDocRef);

                if (!projectDoc.exists()) {
                    setError('Progetto non trovato.');
                    return;
                }

                const data = projectDoc.data();
                setProjectData(data);

                // Build GenerationResult from project data
                const generatedResult: GenerationResult = {
                    computoItems: data.result?.computoItems || [],
                    reportText: data.result?.reportText || '',
                    generatedImage: data.result?.generatedImage,
                    generatedImageUrl: data.generatedImageUrl || data.result?.generatedImageUrl,
                    originalImageUrl: data.originalImageUrl || data.result?.originalImageUrl,
                    pdfDownloadUrl: data.pdfDownloadUrl || '',
                    metadata: data.metadata || {
                        uuid: 'N/A',
                        readableId: data.id || 'N/A',
                        hash: 'N/A',
                        timestamp: data.createdAt?.toDate?.()?.toISOString() || new Date().toISOString(),
                        generatorVersion: 'Domux AI v1.0',
                    },
                    sources: data.result?.sources || [],
                };

                setResult(generatedResult);
            } catch (err: any) {
                console.error('Error loading project:', err);
                setError('Errore durante il caricamento del progetto.');
            } finally {
                setLoading(false);
            }
        };

        loadProject();
    }, [projectId]);

    if (loading || isSaving) {
        return <Loader message={isSaving ? "Salvataggio modifiche in archivio..." : "Caricamento progetto..."} />;
    }

    if (error || !projectData || !result) {
        return (
            <div className="w-full max-w-4xl mx-auto p-8">
                <ErrorMessage message={error || 'Progetto non disponibile'} />
                <div className="mt-6 text-center">
                    <button
                        onClick={onGoBack}
                        className="bg-brand-cyan text-white font-bold py-3 px-6 rounded-lg hover:opacity-90 transition-colors"
                    >
                        ← Torna alla Dashboard
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="w-full">
            <RenovationReport
                user={user}
                result={result}
                userInput={projectData.userInput || ''}
                projectName={projectData.projectName}
                location={projectData.location || ''}
                committente={projectData.committente}
                onEdit={handleEditArchivedProject}
                showBackButton={true}
                onGoBack={onGoBack}
            />
            <div className="text-center mt-8 mb-8">
                <button
                    onClick={onGoBack}
                    className="bg-brand-cyan text-white font-bold py-3 px-6 rounded-lg hover:opacity-90 transition-colors duration-300 text-lg"
                >
                    ← Torna alla Dashboard
                </button>
            </div>
        </div>
    );
};

export default ProjectViewer;
