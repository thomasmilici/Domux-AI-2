import { initializeApp } from '@firebase/app';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  GoogleAuthProvider,
  signInWithPopup
} from '@firebase/auth';
import { 
  getFirestore, 
  setDoc, 
  doc, 
  serverTimestamp, 
  addDoc, 
  collection, 
  onSnapshot,
  updateDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  deleteDoc,
  arrayUnion
} from '@firebase/firestore';
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
  uploadString
} from '@firebase/storage';
import type { UserSubscription } from '../types/subscription';


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC4lP5_1RCijQniqug5kmcWZFxG7Ub0Bug",
  authDomain: "progettista-ai.firebaseapp.com",
  projectId: "progettista-ai",
  storageBucket: "progettista-ai.firebasestorage.app",
  messagingSenderId: "935797437515",
  appId: "1:935797437515:web:24cce40d50f79c594c49ce",
  measurementId: "G-PLYQKRD80C"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);

export interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  role?: 'user' | 'collaborator' | 'admin' | 'superadmin';
  disabled?: boolean;
  // Professional Data
  ragioneSociale?: string;
  partitaIva?: string;
  indirizzo?: string;
  emailContatto?: string;
  telefono?: string;
  // Subscription Data (v0.5)
  subscription?: UserSubscription;
}

// Re-exporting everything for convenience
export { 
  db, 
  auth, 
  storage,
  // Auth functions
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  GoogleAuthProvider,
  signInWithPopup,
  // Firestore functions
  setDoc, 
  doc, 
  serverTimestamp, 
  addDoc, 
  collection, 
  onSnapshot,
  updateDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  deleteDoc,
  arrayUnion,
  // Storage functions
  ref,
  uploadBytes,
  getDownloadURL,
  uploadString
};