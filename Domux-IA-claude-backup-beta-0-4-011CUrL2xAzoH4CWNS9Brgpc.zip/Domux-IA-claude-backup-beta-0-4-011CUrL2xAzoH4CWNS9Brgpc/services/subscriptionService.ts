/**
 * Servizio per la gestione dei tier e delle sottoscrizioni
 * Versione 0.5
 */

import {
  doc,
  updateDoc,
  getDoc,
  serverTimestamp,
  getDocs,
  query,
  where,
  collection
} from '@firebase/firestore';
import { db } from './firebase';
import type { User } from './firebase';
import type {
  SubscriptionTier,
  PaymentStatus,
  UserSubscription,
  TierFeatures
} from '../types/subscription';
import {
  TIER_CONFIG,
  TRIAL_DURATION_DAYS,
  canAccessFeature,
  isTierHigherOrEqual
} from '../types/subscription';

/**
 * Inizializza il trial gratuito per un nuovo utente
 */
export async function initializeFreeTrial(userId: string): Promise<void> {
  const now = new Date();
  const trialEnd = new Date(now);
  trialEnd.setDate(trialEnd.getDate() + TRIAL_DURATION_DAYS);

  const subscription: UserSubscription = {
    tier: 'free_trial',
    paymentStatus: 'trial',
    trialStartDate: now,
    trialEndDate: trialEnd,
  };

  const userRef = doc(db, 'users', userId);
  await updateDoc(userRef, {
    subscription,
    'subscription.trialStartDate': serverTimestamp(),
  });
}

/**
 * Verifica se il trial di un utente è scaduto
 */
export function isTrialExpired(subscription: UserSubscription | undefined): boolean {
  if (!subscription || subscription.tier !== 'free_trial') {
    return false;
  }

  if (!subscription.trialEndDate) {
    return false;
  }

  const now = new Date();
  const endDate = subscription.trialEndDate.toDate ? subscription.trialEndDate.toDate() : new Date(subscription.trialEndDate);

  return now > endDate;
}

/**
 * Verifica se la subscription di un utente è valida e attiva
 */
export function isSubscriptionActive(subscription: UserSubscription | undefined): boolean {
  if (!subscription) {
    return false;
  }

  // Se è in trial, controlla se non è scaduto
  if (subscription.tier === 'free_trial') {
    return !isTrialExpired(subscription);
  }

  // Per i tier a pagamento, controlla lo stato del pagamento
  if (subscription.paymentStatus === 'active') {
    // Se c'è una data di scadenza, verifica che non sia passata
    if (subscription.subscriptionEndDate) {
      const now = new Date();
      const endDate = subscription.subscriptionEndDate.toDate
        ? subscription.subscriptionEndDate.toDate()
        : new Date(subscription.subscriptionEndDate);
      return now <= endDate;
    }
    // Se non c'è data di scadenza, è un abbonamento attivo senza limite
    return true;
  }

  return false;
}

/**
 * Ottiene il tier effettivo dell'utente (gestisce trial scaduti)
 */
export function getEffectiveTier(user: User): SubscriptionTier {
  if (!user.subscription) {
    return 'free_trial'; // Default per utenti senza subscription
  }

  // Se è in trial e il trial è scaduto, downgrade automatico
  if (user.subscription.tier === 'free_trial' && isTrialExpired(user.subscription)) {
    return 'free_trial'; // Rimane in trial ma con accesso limitato
  }

  // Se ha un tier a pagamento ma non è attivo
  if (user.subscription.tier !== 'free_trial' && !isSubscriptionActive(user.subscription)) {
    return 'free_trial'; // Downgrade a trial scaduto
  }

  return user.subscription.tier;
}

/**
 * Ottiene la configurazione features per il tier dell'utente
 */
export function getUserTierFeatures(user: User): TierFeatures {
  const tier = getEffectiveTier(user);
  return TIER_CONFIG[tier];
}

/**
 * Verifica se l'utente può accedere a una feature specifica
 */
export function canUserAccessFeature(user: User, feature: keyof TierFeatures): boolean {
  const tier = getEffectiveTier(user);
  return canAccessFeature(tier, feature);
}

/**
 * Verifica se l'utente ha un tier sufficiente per accedere a una risorsa
 */
export function hasRequiredTier(user: User, requiredTier: SubscriptionTier): boolean {
  const userTier = getEffectiveTier(user);
  return isTierHigherOrEqual(userTier, requiredTier);
}

/**
 * Conta i progetti creati dall'utente nel mese corrente
 */
export async function getMonthlyProjectCount(userId: string): Promise<number> {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const projectsQuery = query(
    collection(db, 'projects'),
    where('userId', '==', userId),
    where('createdAt', '>=', startOfMonth)
  );

  const snapshot = await getDocs(projectsQuery);
  return snapshot.size;
}

/**
 * Conta le sessioni attive dell'utente
 */
export async function getActiveSessionCount(userId: string): Promise<number> {
  const sessionsQuery = query(
    collection(db, 'projectSessions'),
    where('userId', '==', userId),
    where('status', 'in', ['open', 'paused'])
  );

  const snapshot = await getDocs(sessionsQuery);
  return snapshot.size;
}

/**
 * Verifica se l'utente può creare un nuovo progetto
 */
export async function canCreateProject(user: User): Promise<{ allowed: boolean; reason?: string }> {
  const features = getUserTierFeatures(user);

  // Verifica se la subscription è attiva
  if (!isSubscriptionActive(user.subscription)) {
    return {
      allowed: false,
      reason: 'La tua prova gratuita è scaduta. Effettua l\'upgrade per continuare.'
    };
  }

  // Se il tier permette progetti illimitati
  if (features.maxProjectsPerMonth === -1) {
    return { allowed: true };
  }

  // Conta i progetti del mese
  const monthlyCount = await getMonthlyProjectCount(user.uid);

  if (monthlyCount >= features.maxProjectsPerMonth) {
    return {
      allowed: false,
      reason: `Hai raggiunto il limite di ${features.maxProjectsPerMonth} progetti mensili per il tuo piano ${features.displayName}.`
    };
  }

  return { allowed: true };
}

/**
 * Verifica se l'utente può creare una nuova sessione
 */
export async function canCreateSession(user: User): Promise<{ allowed: boolean; reason?: string }> {
  const features = getUserTierFeatures(user);

  // Verifica se la subscription è attiva
  if (!isSubscriptionActive(user.subscription)) {
    return {
      allowed: false,
      reason: 'La tua prova gratuita è scaduta. Effettua l\'upgrade per continuare.'
    };
  }

  // Se il tier permette sessioni illimitate
  if (features.maxSessionsActive === -1) {
    return { allowed: true };
  }

  // Conta le sessioni attive
  const activeCount = await getActiveSessionCount(user.uid);

  if (activeCount >= features.maxSessionsActive) {
    return {
      allowed: false,
      reason: `Hai raggiunto il limite di ${features.maxSessionsActive} sessioni attive per il tuo piano ${features.displayName}.`
    };
  }

  return { allowed: true };
}

/**
 * Aggiorna il tier di un utente (per admin o dopo pagamento)
 */
export async function updateUserTier(
  userId: string,
  tier: SubscriptionTier,
  paymentStatus: PaymentStatus = 'active',
  subscriptionData?: Partial<UserSubscription>
): Promise<void> {
  const now = new Date();

  const subscription: UserSubscription = {
    tier,
    paymentStatus,
    subscriptionStartDate: now,
    ...subscriptionData,
  };

  // Se non è trial, rimuovi i campi trial
  if (tier !== 'free_trial') {
    delete subscription.trialStartDate;
    delete subscription.trialEndDate;
  }

  const userRef = doc(db, 'users', userId);
  await updateDoc(userRef, {
    subscription,
    'subscription.subscriptionStartDate': serverTimestamp(),
  });
}

/**
 * Calcola i giorni rimanenti del trial
 */
export function getTrialDaysRemaining(subscription: UserSubscription | undefined): number {
  if (!subscription || subscription.tier !== 'free_trial' || !subscription.trialEndDate) {
    return 0;
  }

  const now = new Date();
  const endDate = subscription.trialEndDate.toDate ? subscription.trialEndDate.toDate() : new Date(subscription.trialEndDate);

  const diffTime = endDate.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  return Math.max(0, diffDays);
}

/**
 * Ottiene un messaggio user-friendly sullo stato della subscription
 */
export function getSubscriptionStatusMessage(user: User): string {
  if (!user.subscription) {
    return 'Nessuna sottoscrizione attiva';
  }

  const tier = getEffectiveTier(user);
  const features = TIER_CONFIG[tier];

  if (tier === 'free_trial') {
    const daysRemaining = getTrialDaysRemaining(user.subscription);
    if (daysRemaining > 0) {
      return `Prova gratuita - ${daysRemaining} giorni rimanenti`;
    } else {
      return 'Prova gratuita scaduta - Effettua l\'upgrade';
    }
  }

  if (isSubscriptionActive(user.subscription)) {
    return `Piano ${features.displayName} - Attivo`;
  }

  return 'Sottoscrizione scaduta';
}
