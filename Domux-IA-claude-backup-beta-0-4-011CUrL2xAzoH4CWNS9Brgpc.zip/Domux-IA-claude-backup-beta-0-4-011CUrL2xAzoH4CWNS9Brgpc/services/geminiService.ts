import { GoogleGenAI, Type, Modality } from "@google/genai";
import { ComputoItem } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Extracts a JSON block from a string, ignoring markdown fences and other surrounding text.
 * @param text The text containing the JSON block.
 * @returns The parsed JSON object.
 */
function extractJson(text: string): any {
    // This regex looks for a string that starts with { or [ and ends with } or ],
    // covering the entire JSON block. It handles markdown fences as well.
    const jsonRegex = /```json\s*([\s\S]*?)\s*```|({[\s\S]*}|\[[\s\S]*\])/;
    const match = text.match(jsonRegex);

    if (!match) {
        throw new Error("Nessun blocco JSON valido trovato nella risposta del modello AI.");
    }
    // The actual JSON string is in the first or second capturing group
    const jsonString = match[1] || match[2];
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        console.error("Failed to parse JSON:", jsonString);
        throw new Error("La risposta del modello AI non è in un formato JSON valido.");
    }
}


const generateSystemInstruction = (
    location: string,
    projectType?: 'public_works' | 'private_estimate',
    region?: string,
    preferredStores?: string[]
) => {
    const baseInstruction = `Sei un assistente tecnico specializzato nella redazione di computi metrici estimativi e relazioni tecniche per il settore edilizio.

Il tuo ruolo è quello di un professionista tecnico qualificato con esperienza nella stima e valutazione di interventi edilizi. La tua comunicazione deve essere:
- Formale e tecnica, con linguaggio proprio delle perizie tecniche
- Precisa e documentata nelle quantificazioni
- Conforme alle normative vigenti
- Strutturata secondo gli standard professionali del settore

STRUTTURA OBBLIGATORIA DELLA RELAZIONE TECNICA:

⚠️ IMPORTANTE: NON aggiungere intestazioni, header o campi come "RELATORE TECNICO", "DATA", "OGGETTO" nel testo della relazione. Questi campi sono già presenti nel layout del documento PDF.

La relazione tecnica DEVE contenere SOLO il corpo del testo seguendo questa struttura numerata:

1. DESCRIZIONE GENERALE
   - Inquadramento dell'intervento
   - Ubicazione e contesto
   - Finalità dell'opera

2. FASI OPERATIVE
   - Sequenza delle lavorazioni previste
   - Metodologie di esecuzione
   - Tempistiche indicative

3. MATERIALI PREVISTI
   - Elenco dei materiali principali
   - Caratteristiche tecniche rilevanti
   - Conformità normativa

4. COMPUTO METRICO
   - Introduzione alla quantificazione
   - Criterio di misurazione adottato
   - Note tecniche eventuali

INIZIA DIRETTAMENTE CON: "1. DESCRIZIONE GENERALE" seguito dal testo.
NON includere titoli o intestazioni aggiuntive sopra questa struttura.

LINGUAGGIO DA UTILIZZARE:
✅ Usare formule tecniche:
   - "L'intervento prevede..."
   - "Si provvede alla rimozione e smaltimento..."
   - "Il materiale previsto è conforme alle normative vigenti..."
   - "La lavorazione comprende..."
   - "Le operazioni includono..."

❌ Evitare espressioni colloquiali:
   - NO: "come se parlassi con un amico"
   - NO: "una soluzione incredibile"
   - NO: "fantastico", "perfetto", "ottimo"
   - NO: tono enfatico o emotivo

Il testo deve avere il carattere di una relazione tecnica professionale, adatta ad essere allegata a documentazione amministrativa o contrattuale.`;

    let pricingGuidance = '';

    if (projectType === 'public_works') {
        const regionToUse = region || location;
        pricingGuidance = `

🏛️ TIPO PROGETTO: OPERE PUBBLICHE
Devi cercare i prezzi NEI PREZZARI REGIONALI UFFICIALI della regione: ${regionToUse}.
Usa lo strumento di ricerca Google per trovare:
- "Prezzario regionale ${regionToUse} lavori pubblici 2024"
- "Prezzario opere pubbliche ${regionToUse}"
- "Elenco prezzi regionali ${regionToUse}"

IMPORTANTE per CODICI ARTICOLO:
- Ogni voce DEVE avere un codice dal prezzario regionale (es. "A.01.001", "B.02.015")
- Se trovi il codice, usalo esattamente come appare nel prezzario
- Se non trovi un codice specifico, usa "N.D." (Non Disponibile)
- I prezzi devono essere quelli ufficiali del prezzario, IVA ESCLUSA`;
    } else if (projectType === 'private_estimate') {
        const stores = preferredStores && preferredStores.length > 0
            ? preferredStores.join(', ')
            : 'principali store di edilizia (Leroy Merlin, Bricoman, OBI, etc.)';

        pricingGuidance = `

🏠 TIPO PROGETTO: PREVENTIVO PRIVATO
Devi cercare i prezzi e i CODICI PRODOTTO REALI negli store: ${stores}.

⚠️ ATTENZIONE: È FONDAMENTALE USARE GOOGLE SEARCH PER OGNI PRODOTTO! ⚠️

Per OGNI articolo del computo, DEVI:
1. Usare lo strumento di ricerca Google con queste query:
   - "codice [nome prodotto esatto] ${stores} 2024"
   - "ref [nome prodotto] catalogo ${stores}"
   - "[nome prodotto] scheda tecnica ${stores}"
   - Esempio: "codice pittura murale bianca Leroy Merlin 2024"

2. Cercare il CODICE REF./SKU dal sito ufficiale dello store
3. Verificare che il codice esista davvero (es. 12345678 per Leroy Merlin, cod. articolo per Bricoman)

🚫 NON INVENTARE MAI I CODICI PRODOTTO 🚫
- NON usare formati come "LM-12345678" se non li hai trovati con la ricerca
- NON creare codici fittizi o ipotetici
- Se dopo la ricerca Google NON trovi il codice reale, usa "N.D." nel campo codice_articolo

✅ CODICE REALE TROVATO:
Nel campo "codice_articolo" scrivi: "[Nome Store] Ref. [CODICE_REALE]"
Esempio: "Leroy Merlin Ref. 67890123" oppure "Bricoman Cod. ART789"

❌ CODICE NON TROVATO:
Se dopo la ricerca non trovi il codice, usa: "N.D."
E nella descrizione specifica: "Prodotto generico - verificare disponibilità in negozio"

PREZZI:
- I prezzi devono essere quelli attuali trovati nei siti degli store (IVA ESCLUSA)
- Cita sempre la fonte con URL del prodotto specifico

LISTA DELLA SPESA:
L'utente deve poter andare in negozio e chiedere il prodotto usando il codice che fornisci.
Quindi è ESSENZIALE che i codici siano REALI e VERIFICABILI.`;
    } else {
        // Fallback to original behavior
        pricingGuidance = `
Devi usare lo strumento di ricerca Google per trovare i prezzari ufficiali della regione o provincia specificata: ${location}.
Ogni oggetto nell'array "computoItems" DEVE includere un "codice_articolo" recuperato dai prezzari ufficiali.
Se un codice specifico non è reperibile, usa il valore "N.D." (Non Disponibile).`;
    }

    return `${baseInstruction}${pricingGuidance}

La relazione tecnica deve essere concisa e professionale.
I prezzi devono essere sempre IVA ESCLUSA.
Cita sempre le tue fonti con URL completi.

FORMATO OUTPUT:
Formatta la tua risposta finale come un singolo blocco di codice JSON, senza includere mai i delimitatori di markdown (come \`\`\`json).
Il JSON deve contenere:
- "computoItems": array di oggetti con campi {id, codice_articolo, descrizione, um, quantita, prezzo_unitario, importo}
- "reportText": stringa con la relazione tecnica

⚠️ REGOLA FONDAMENTALE SUI CODICI ⚠️
NON INVENTARE MAI i codici articolo/prodotto.
DEVI fare ricerche Google per ogni articolo e usare SOLO codici reali che hai trovato.
Se non trovi un codice reale dopo la ricerca, scrivi "N.D." nel campo codice_articolo.
È MEGLIO avere "N.D." che un codice inventato che non esiste.`;
};


export async function generateComputoMetric(
    description: string,
    location: string,
    projectType?: 'public_works' | 'private_estimate',
    region?: string,
    preferredStores?: string[]
): Promise<{ computoItems: ComputoItem[], reportText: string, generatedImage: undefined, sources: any[] }> {
    try {
        // Increased timeout for complex computo generation
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Timeout: la generazione del computo sta richiedendo troppo tempo. Riprova con una descrizione più semplice.')), 180000) // 3 minutes
        );

        const generationPromise = ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: `Genera un computo metrico e una relazione tecnica per i seguenti lavori a ${location}: ${description}`,
            config: {
                tools: [{googleSearch: {}}],
                systemInstruction: generateSystemInstruction(location, projectType, region, preferredStores),
            },
        });

        const response = await Promise.race([generationPromise, timeoutPromise]) as any;
        
        const text = response.text.trim();
        const result = extractJson(text);

        if (!result.computoItems || !result.reportText) {
            throw new Error("Risposta del modello AI non valida o incompleta.");
        }
        
        const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

        return {
            computoItems: result.computoItems,
            reportText: result.reportText,
            generatedImage: undefined,
            sources: sources,
        };
    } catch (error) {
        console.error("Errore durante la generazione del computo metrico:", error);
        throw new Error("Impossibile generare il computo metrico. Riprova più tardi.");
    }
}


export async function generateRenovationPlan(
    description: string,
    location: string,
    imageBase64: string,
    imageMimeType: string,
    projectType?: 'public_works' | 'private_estimate',
    region?: string,
    preferredStores?: string[]
): Promise<{ computoItems: ComputoItem[], reportText: string, generatedImage: string, sources: any[] }> {
     try {
        console.log("Starting renovation plan generation with image");

        // Step 1: Generate the cost estimate and technical report with Google Search
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Timeout: la generazione del piano di ristrutturazione sta richiedendo troppo tempo. Riprova.')), 180000) // 3 minutes
        );

        console.log("Calling AI for text generation with image...");
        const textGenerationPromise = ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: imageBase64,
                            mimeType: imageMimeType,
                        },
                    },
                    {
                        text: `Partendo dalla situazione esistente mostrata nell'immagine, genera un computo metrico e una relazione tecnica per il seguente progetto di ristrutturazione a ${location}: ${description}`,
                    },
                ],
            },
            config: {
                tools: [{googleSearch: {}}],
                systemInstruction: generateSystemInstruction(location, projectType, region, preferredStores),
            },
        });

        const textResponse = await Promise.race([textGenerationPromise, timeoutPromise]) as any;
        console.log("Text generation completed successfully");

        const textResult = extractJson(textResponse.text.trim());
        if (!textResult.computoItems || !textResult.reportText) {
            throw new Error("Risposta del modello AI per il testo non valida o incompleta.");
        }
        console.log("Text result parsed successfully");

        const sources = textResponse.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

        // Step 2: Generate the renovated image with improved error handling
        let generatedImage = '';
        try {
            console.log("Starting image generation...");

            // Add timeout specifically for image generation
            const imageTimeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Timeout generazione immagine')), 120000) // 2 minutes
            );

            const imageGenerationPromise = ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: {
                    parts: [
                        {
                            inlineData: {
                                data: imageBase64,
                                mimeType: imageMimeType,
                            },
                        },
                        {
                            text: `Questa è l'immagine dello stato attuale. Basandoti sulla seguente descrizione di progetto: "${description}", genera una immagine fotorealistica del risultato finale della ristrutturazione. Migliora l'illuminazione e l'arredamento per rendere l'ambiente moderno e accogliente.`,
                        },
                    ],
                },
                config: {
                    responseModalities: [Modality.IMAGE],
                },
            });

            const imageResponse = await Promise.race([imageGenerationPromise, imageTimeoutPromise]) as any;
            console.log("Image generation API call completed");

            // Extract generated image from response
            if (imageResponse?.candidates?.[0]?.content?.parts) {
                for (const part of imageResponse.candidates[0].content.parts) {
                    if (part.inlineData) {
                        generatedImage = part.inlineData.data;
                        console.log("Generated image extracted successfully");
                        break;
                    }
                }
            }

            if (!generatedImage) {
                console.warn("No image data found in response - continuing without generated image");
            }

        } catch (imageError: any) {
            // Log the error but don't fail the entire operation
            console.error("Errore durante la generazione dell'immagine (operazione continua senza immagine):", imageError);
            console.error("Image generation error details:", {
                message: imageError.message,
                stack: imageError.stack,
                name: imageError.name
            });
            // generatedImage remains empty string
        }

        return {
            computoItems: textResult.computoItems,
            reportText: textResult.reportText,
            generatedImage: generatedImage,
            sources: sources
        };
    } catch (error: any) {
        console.error("Errore durante la generazione del piano di ristrutturazione:", error);
        console.error("Error details:", {
            message: error.message,
            stack: error.stack,
            name: error.name
        });
        // Passa il messaggio d'errore effettivo per debugging
        const errorMessage = error.message || "Errore sconosciuto";
        throw new Error(`Impossibile generare il piano di ristrutturazione: ${errorMessage}`);
    }
}

/**
 * Sends a chat message to Gemini and returns the AI response
 * @param userMessage The user's message
 * @param conversationHistory Optional array of previous messages for context
 * @returns The AI's response text
 */
export async function sendChatMessage(
    userMessage: string,
    conversationHistory?: { role: 'user' | 'model', parts: { text: string }[] }[]
): Promise<string> {
    try {
        const chatSystemInstruction = `Sei un assistente AI specializzato in edilizia e architettura con lo stile comunicativo di un professionista esperto e amichevole.

Hai la competenza di un geometra senior che lavora da decenni nel settore, ma parli in modo naturale e accessibile. Puoi essere creativo nelle tue spiegazioni, usare esempi pratici, e adattare il tuo tono in base al contesto.

Il tuo obiettivo è assistere l'utente con:
- Domande su edilizia, architettura, ristrutturazioni
- Spiegazioni tecniche su materiali, lavorazioni, normative
- Consigli pratici su progetti di costruzione o ristrutturazione
- Analisi di documenti e foto
- Generazione di computi metrici estimativi

Rispondi in modo chiaro, professionale ma accessibile. Se l'utente chiede di analizzare un documento o una foto, spiega che dovrebbe usare i pulsanti degli strumenti dedicati.`;

        const contents = [
            ...(conversationHistory || []),
            { role: 'user' as const, parts: [{ text: userMessage }] }
        ];

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: contents,
            config: {
                tools: [{ googleSearch: {} }],
                systemInstruction: chatSystemInstruction,
                temperature: 0.9, // More creative and conversational
            },
        });

        return response.text.trim();
    } catch (error) {
        console.error("Errore durante l'invio del messaggio chat:", error);
        throw new Error("Impossibile ottenere una risposta dall'AI. Riprova più tardi.");
    }
}

/**
 * Analyzes a document (PDF or image) with Gemini Vision/Document Understanding
 * @param fileBase64 The base64-encoded file content
 * @param mimeType The MIME type of the file (e.g., 'application/pdf', 'image/jpeg')
 * @param prompt The analysis prompt
 * @returns The AI's analysis response
 */
export async function analyzeDocument(
    fileBase64: string,
    mimeType: string,
    prompt: string
): Promise<string> {
    try {
        const analysisSystemInstruction = `Sei un assistente AI specializzato nell'analisi di documenti tecnici per edilizia e architettura.

Quando analizzi un documento (PDF o immagine), devi:
- Estrarre tutte le informazioni rilevanti (voci di computo, quantità, prezzi, descrizioni)
- Identificare la struttura del documento (è un computo? una planimetria? un capitolato?)
- Fornire un riassunto chiaro e organizzato dei dati estratti
- Se è un computo metrico, elencare le voci principali con codici, descrizioni, unità di misura, quantità e prezzi
- Se è una foto/planimetria, descrivere gli elementi visibili e suggerire eventuali interventi

Sii preciso nell'estrazione dei dati numerici (quantità, prezzi, misure).`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro', // Pro for better document understanding
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: fileBase64,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                tools: [{ googleSearch: {} }],
                systemInstruction: analysisSystemInstruction,
                temperature: 0.3, // Lower temperature for more accurate extraction
            },
        });

        return response.text.trim();
    } catch (error) {
        console.error("Errore durante l'analisi del documento:", error);
        throw new Error("Impossibile analizzare il documento. Riprova più tardi.");
    }
}

/**
 * Analyzes multiple documents/photos intelligently and guides the user through the process
 * @param files Array of files with base64 data and metadata
 * @param conversationHistory Previous conversation for context
 * @returns Object with AI response and optional computo data
 */
export async function analyzeMultipleDocumentsAndGuide(
    files: { base64: string; mimeType: string; name: string }[],
    conversationHistory?: { role: 'user' | 'model', parts: { text: string }[] }[]
): Promise<{ message: string; shouldGenerateComputo: boolean; extractedInfo?: { projectType?: string; region?: string; location?: string; description?: string } }> {
    try {
        const guidingSystemInstruction = `Sei un assistente AI specializzato in edilizia che aiuta gli utenti a creare computi e preventivi dai loro appunti.

L'utente ti ha caricato uno o più documenti/foto (appunti scritti a mano, foto di cantieri, documenti PDF, ecc.).

Il tuo compito è:

1. **ANALIZZARE** tutti i documenti/foto caricati
2. **CAPIRE** cosa contengono (es. descrizione lavori, lista materiali, misure, foto di ambienti, ecc.)
3. **DETERMINARE** quali informazioni ti mancano per generare un computo completo
4. **RISPONDERE** in formato JSON con la tua analisi e le domande (se necessarie)

Informazioni necessarie per un computo completo:
- Tipo di progetto: PRIVATO o PUBBLICO (opere pubbliche)
- Se PUBBLICO: quale regione per i prezzari regionali
- Ubicazione del cantiere (città/regione)
- Descrizione dei lavori (se non già chiara dagli appunti)

FORMATO RISPOSTA:
Devi rispondere SEMPRE in formato JSON con questa struttura:

{
  "canGenerate": true/false,
  "message": "messaggio conversazionale per l'utente",
  "extractedInfo": {
    "description": "descrizione completa dei lavori estratta dagli appunti",
    "projectType": "private_estimate" o "public_works" (se identificato),
    "region": "nome regione" (se identificato),
    "location": "città/regione" (se identificato)
  },
  "missingInfo": ["lista di informazioni mancanti"]
}

REGOLE:
- Se 'canGenerate' è true: hai TUTTE le info necessarie e puoi generare il computo
- Se 'canGenerate' è false: mancano info essenziali, elenca in 'missingInfo' cosa manca
- Il 'message' deve essere sempre conversazionale e amichevole
- Estrai SEMPRE la 'description' degli appunti, anche se incompleta
- Non chiedere info già presenti negli appunti

Esempi:

Esempio 1 (Info complete):
{
  "canGenerate": true,
  "message": "Perfetto! Ho analizzato i tuoi appunti e ho trovato tutto quello che serve. Vedo che devi ristrutturare un bagno con nuove piastrelle, sanitari e impianto idrico. Sto per generare il preventivo completo!",
  "extractedInfo": {
    "description": "Ristrutturazione bagno: rimozione vecchi sanitari, nuove piastrelle 20mq, installazione sanitari moderni, rifacimento impianto idrico",
    "projectType": "private_estimate",
    "location": "Milano"
  },
  "missingInfo": []
}

Esempio 2 (Info mancanti):
{
  "canGenerate": false,
  "message": "Ho analizzato i tuoi appunti! Vedo che hai annotato una ristrutturazione del bagno con piastrelle e nuovi sanitari. Per generare un preventivo accurato, mi serve sapere:\\n\\n- È un lavoro privato o un'opera pubblica?\\n- In che città si trova il cantiere?",
  "extractedInfo": {
    "description": "Ristrutturazione bagno: piastrelle, sanitari nuovi"
  },
  "missingInfo": ["projectType", "location"]
}`;

        // Build parts array with all documents
        const parts: any[] = [];

        // Add all files
        for (const file of files) {
            parts.push({
                inlineData: {
                    data: file.base64,
                    mimeType: file.mimeType,
                }
            });
        }

        // Add text prompt
        parts.push({
            text: `Ho caricato ${files.length} file per generare un preventivo. I file sono: ${files.map(f => f.name).join(', ')}.

Analizza tutti questi documenti/foto, estrai le informazioni e rispondi in formato JSON seguendo lo schema definito nelle istruzioni.`
        });

        const contents = [
            ...(conversationHistory || []),
            { role: 'user' as const, parts }
        ];

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro', // Pro model for better document understanding
            contents: contents,
            config: {
                tools: [{ googleSearch: {} }],
                systemInstruction: guidingSystemInstruction,
                temperature: 0.3, // Lower for more structured output
            },
        });

        const responseText = response.text.trim();
        const jsonData = extractJson(responseText);

        return {
            message: jsonData.message || responseText,
            shouldGenerateComputo: jsonData.canGenerate === true,
            extractedInfo: jsonData.extractedInfo || {}
        };
    } catch (error) {
        console.error("Errore durante l'analisi dei documenti multipli:", error);
        throw new Error("Impossibile analizzare i documenti. Riprova più tardi.");
    }
}

/**
 * Generates an intelligent project title based on computo items
 * @param computoItems The computo items array
 * @param description Optional user description
 * @returns A concise, descriptive project title (e.g., "Rifacimento cucina", "Ristrutturazione bagno")
 */
export async function generateProjectTitle(
    computoItems: ComputoItem[],
    description?: string
): Promise<string> {
    try {
        const systemInstruction = `Sei un esperto edilizio che deve creare titoli concisi e professionali per progetti di costruzione/ristrutturazione.

Il tuo compito è analizzare le voci di un computo metrico e creare un titolo breve che descriva il tipo di lavoro.

REGOLE:
- Il titolo deve essere BREVE (massimo 4-5 parole)
- Deve descrivere IL TIPO DI INTERVENTO principale
- Usa termini tecnici ma comprensibili
- NON includere "Sig.", cognomi, date, o località
- NON usare parole come "Progetto", "Lavori di", "Intervento di" all'inizio

ESEMPI CORRETTI:
- "Rifacimento cucina"
- "Ristrutturazione bagno"
- "Sostituzione infissi"
- "Tinteggiatura appartamento"
- "Rifacimento impianto elettrico"
- "Pavimentazione terrazzo"
- "Isolamento termico facciata"

ESEMPI ERRATI:
- "Progetto di ristrutturazione cucina" (troppo lungo)
- "Lavori di tinteggiatura" (evita "Lavori di")
- "Intervento edilizio vario" (troppo generico)
- "Ristrutturazione completa appartamento Sig. Rossi" (non includere committente)

Rispondi SOLO con il titolo, senza spiegazioni o punteggiatura finale.`;

        const itemsDescription = computoItems
            .slice(0, 10) // Take first 10 items for context
            .map(item => `- ${item.descrizione}`)
            .join('\n');

        const prompt = description
            ? `Descrizione progetto: ${description}\n\nPrime voci del computo:\n${itemsDescription}`
            : `Voci del computo:\n${itemsDescription}`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                temperature: 0.3, // Lower temperature for consistent, professional titles
            },
        });

        let title = response.text.trim();

        // Remove common prefixes if present
        title = title.replace(/^(Progetto di |Lavori di |Intervento di |Intervento per |Progetto |Lavori )/i, '');

        // Remove quotes if present
        title = title.replace(/^["']|["']$/g, '');

        // Capitalize first letter
        title = title.charAt(0).toUpperCase() + title.slice(1);

        return title;
    } catch (error) {
        console.error("Errore durante la generazione del titolo progetto:", error);
        // Fallback to a generic title based on first item
        if (computoItems.length > 0) {
            const firstDesc = computoItems[0].descrizione.toLowerCase();
            if (firstDesc.includes('cucina')) return 'Rifacimento cucina';
            if (firstDesc.includes('bagno')) return 'Ristrutturazione bagno';
            if (firstDesc.includes('tinteggiatura') || firstDesc.includes('pittura')) return 'Tinteggiatura';
            if (firstDesc.includes('pavimento')) return 'Pavimentazione';
            if (firstDesc.includes('infissi') || firstDesc.includes('finestre')) return 'Sostituzione infissi';
        }
        return 'Ristrutturazione';
    }
}

/**
 * Generates a structured computo metrico from a document or photo analysis
 * @param fileBase64 The base64-encoded file content
 * @param mimeType The MIME type of the file
 * @param userPrompt The user's description/request
 * @param location The location for the project
 * @returns Structured computo with items and report text
 */
export async function generateComputoFromDocument(
    fileBase64: string,
    mimeType: string,
    userPrompt: string,
    location: string
): Promise<{ computoItems: ComputoItem[], reportText: string, sources: any[] }> {
    try {
        const systemInstruction = `Sei un assistente AI specializzato in computi metrici estimativi per edilizia.

Analizza il documento/foto fornito ed estrai o genera un computo metrico completo in formato JSON.

Il formato di output DEVE essere:
{
  "computoItems": [
    {
      "codice_articolo": "codice o N.D.",
      "descrizione": "descrizione completa della lavorazione",
      "unita_misura": "m, m2, m3, cad, kg, etc.",
      "quantita": numero,
      "prezzo_unitario": numero,
      "importo": numero (quantita * prezzo_unitario)
    }
  ],
  "reportText": "Relazione tecnica dettagliata che descrive il progetto, le lavorazioni, i materiali..."
}

IMPORTANTE:
- Se il documento è un computo esistente, estrai i dati esatti
- Se è una foto/planimetria, genera un computo estimativo basato sull'analisi visiva
- Usa prezzi di mercato realistici
- Calcola correttamente gli importi (quantita * prezzo_unitario)
- La relazione tecnica deve essere professionale e dettagliata`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: fileBase64,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: `${userPrompt}\n\nLocalità: ${location}\n\nGenera un computo metrico completo in formato JSON.`,
                    },
                ],
            },
            config: {
                tools: [{ googleSearch: {} }],
                systemInstruction: systemInstruction,
                temperature: 0.3,
            },
        });

        const textResult = extractJson(response.text.trim());
        if (!textResult.computoItems || !textResult.reportText) {
            throw new Error("Risposta del modello AI non valida o incompleta.");
        }

        const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

        return {
            computoItems: textResult.computoItems,
            reportText: textResult.reportText,
            sources: sources
        };
    } catch (error) {
        console.error("Errore durante la generazione del computo da documento:", error);
        throw new Error("Impossibile generare il computo dal documento. Riprova più tardi.");
    }
}