/**
 * Servizio per la gestione dei dati di Project Management in Firestore
 * Gestisce salvataggio, aggiornamento e sincronizzazione automatica
 * Versione 0.5 - Sistema IA-Driven
 */

import {
  doc,
  setDoc,
  getDoc,
  updateDoc,
  collection,
  addDoc,
  getDocs,
  query,
  where,
  serverTimestamp,
  onSnapshot,
  deleteDoc,
  writeBatch,
} from '@firebase/firestore';
import { db } from './firebase';
import { generateProjectManagementData } from './projectAIService';
import type {
  ProjectManagementData,
  ProjectTimeline,
  Activity,
  Expense,
  BrogliaccioDiCantiere,
  SALPrediction,
  ProjectAIAnalysis,
  GenerationStatus,
} from '../types/projectManagement';

// ============================================================================
// GENERAZIONE AUTOMATICA DATI PROGETTO
// ============================================================================

/**
 * Genera automaticamente tutti i dati di project management per un nuovo progetto
 * Questa funzione viene chiamata quando un utente crea/salva un preventivo
 */
export async function generateAndSaveProjectData(
  projectId: string,
  userId: string,
  userTier: 1 | 2 | 3,
  preventivo: any,
  projectInfo: {
    title: string;
    location: string;
    totalValue: number;
  }
): Promise<void> {
  try {
    // 1. Imposta stato generazione
    await setGenerationStatus(projectId, {
      projectId,
      status: 'generating',
      progress: 0,
      currentStep: 'Inizializzazione...',
      startedAt: serverTimestamp() as any,
    });

    // 2. Chiama IA per generare tutti i dati
    await updateGenerationStatus(projectId, { progress: 20, currentStep: 'Generazione timeline con IA...' });

    const aiData = await generateProjectManagementData(preventivo, projectInfo);

    // 3. Salva timeline
    await updateGenerationStatus(projectId, { progress: 40, currentStep: 'Salvataggio timeline...' });
    await saveTimeline(projectId, {
      ...aiData.timeline,
      projectId,
    });

    // 4. Salva SAL predictions
    await updateGenerationStatus(projectId, { progress: 60, currentStep: 'Salvataggio SAL previsti...' });
    await saveSALPredictions(projectId, aiData.salPredictions);

    // 5. Salva spese previste
    await updateGenerationStatus(projectId, { progress: 70, currentStep: 'Salvataggio spese previste...' });
    await savePredictedExpenses(projectId, aiData.predictedExpenses);

    // 6. Salva analisi IA
    await updateGenerationStatus(projectId, { progress: 85, currentStep: 'Salvataggio analisi IA...' });
    await saveAIAnalysis(projectId, {
      ...aiData.aiAnalysis,
      projectId,
    });

    // 7. Aggiorna metadata progetto
    await updateGenerationStatus(projectId, { progress: 95, currentStep: 'Finalizzazione...' });
    await updateDoc(doc(db, 'projects', projectId), {
      'generationMetadata.aiGeneratedAt': serverTimestamp(),
      'generationMetadata.aiVersion': 'gemini-2.0-flash-exp',
      'generationMetadata.fullDataGenerated': true,
      'generationMetadata.lastSync': serverTimestamp(),
    });

    // 8. Completa generazione
    await setGenerationStatus(projectId, {
      projectId,
      status: 'completed',
      progress: 100,
      completedAt: serverTimestamp() as any,
      startedAt: serverTimestamp() as any,
    });

    console.log(`✅ Project data generated successfully for ${projectId}`);
  } catch (error: any) {
    console.error('Error generating project data:', error);

    await setGenerationStatus(projectId, {
      projectId,
      status: 'error',
      progress: 0,
      error: error.message,
      startedAt: serverTimestamp() as any,
    });

    throw error;
  }
}

// ============================================================================
// OPERAZIONI TIMELINE
// ============================================================================

/**
 * Salva/aggiorna timeline completa
 */
export async function saveTimeline(
  projectId: string,
  timeline: ProjectTimeline
): Promise<void> {
  const timelineRef = doc(db, 'projects', projectId, 'timeline', 'current');
  await setDoc(timelineRef, timeline, { merge: true });
}

/**
 * Ottiene la timeline corrente
 */
export async function getTimeline(projectId: string): Promise<ProjectTimeline | null> {
  const timelineRef = doc(db, 'projects', projectId, 'timeline', 'current');
  const snap = await getDoc(timelineRef);
  return snap.exists() ? (snap.data() as ProjectTimeline) : null;
}

/**
 * Aggiorna singola attività
 */
export async function updateActivity(
  projectId: string,
  activityId: string,
  updates: Partial<Activity>
): Promise<void> {
  const timeline = await getTimeline(projectId);
  if (!timeline) throw new Error('Timeline not found');

  const activityIndex = timeline.activities.findIndex(a => a.id === activityId);
  if (activityIndex === -1) throw new Error('Activity not found');

  timeline.activities[activityIndex] = {
    ...timeline.activities[activityIndex],
    ...updates,
    lastUpdate: serverTimestamp() as any,
    manuallyModified: true,
  };

  await saveTimeline(projectId, timeline);

  // Trigger sincronizzazione a cascata
  await syncProjectData(projectId, 'activity_updated');
}

/**
 * Aggiorna progress di un'attività
 */
export async function updateActivityProgress(
  projectId: string,
  activityId: string,
  progress: number
): Promise<void> {
  if (progress < 0 || progress > 100) {
    throw new Error('Progress must be between 0 and 100');
  }

  const timeline = await getTimeline(projectId);
  if (!timeline) throw new Error('Timeline not found');

  const activity = timeline.activities.find(a => a.id === activityId);
  if (!activity) throw new Error('Activity not found');

  // Aggiorna status automaticamente
  let status: Activity['status'] = 'not_started';
  if (progress > 0 && progress < 100) status = 'in_progress';
  if (progress === 100) status = 'completed';

  await updateActivity(projectId, activityId, { progress, status });

  // Controlla e sblocca attività dipendenti
  if (progress === 100) {
    await unlockDependentActivities(projectId, activityId);
  }

  // Aggiorna SAL corrente
  await recalculateCurrentSAL(projectId);
}

/**
 * Sblocca attività che dipendono da quella completata
 */
async function unlockDependentActivities(
  projectId: string,
  completedActivityId: string
): Promise<void> {
  const timeline = await getTimeline(projectId);
  if (!timeline) return;

  const dependentActivities = timeline.activities.filter(a =>
    a.dependencies.includes(completedActivityId) && a.status === 'blocked'
  );

  for (const activity of dependentActivities) {
    // Verifica se tutte le dipendenze sono completate
    const allDepsCompleted = activity.dependencies.every(depId => {
      const dep = timeline.activities.find(a => a.id === depId);
      return dep?.status === 'completed';
    });

    if (allDepsCompleted) {
      await updateActivity(projectId, activity.id, { status: 'not_started' });
    }
  }
}

// ============================================================================
// OPERAZIONI SPESE
// ============================================================================

/**
 * Salva spese previste
 */
export async function savePredictedExpenses(
  projectId: string,
  expenses: Expense[]
): Promise<void> {
  const batch = writeBatch(db);

  expenses.forEach(expense => {
    const expRef = doc(collection(db, 'projects', projectId, 'expenses'));
    batch.set(expRef, { ...expense, projectId });
  });

  await batch.commit();
}

/**
 * Aggiunge una nuova spesa
 */
export async function addExpense(
  projectId: string,
  expense: Omit<Expense, 'id' | 'projectId' | 'createdAt' | 'lastUpdate'>
): Promise<string> {
  const expRef = await addDoc(collection(db, 'projects', projectId, 'expenses'), {
    ...expense,
    projectId,
    aiSuggested: false,
    createdAt: serverTimestamp(),
    lastUpdate: serverTimestamp(),
  });

  // Se la spesa è collegata a un'attività, aggiorna actualCost
  if (expense.linkedActivityId) {
    await updateActivityActualCost(projectId, expense.linkedActivityId, expense.amount);
  }

  // Trigger sincronizzazione
  await syncProjectData(projectId, 'expense_added');

  return expRef.id;
}

/**
 * Aggiorna costo reale di un'attività
 */
async function updateActivityActualCost(
  projectId: string,
  activityId: string,
  additionalCost: number
): Promise<void> {
  const timeline = await getTimeline(projectId);
  if (!timeline) return;

  const activity = timeline.activities.find(a => a.id === activityId);
  if (!activity) return;

  const newActualCost = activity.actualCost + additionalCost;
  const variance = newActualCost - activity.estimatedCost;

  await updateActivity(projectId, activityId, {
    actualCost: newActualCost,
    variance,
  });
}

/**
 * Ottiene tutte le spese di un progetto
 */
export async function getExpenses(projectId: string): Promise<Expense[]> {
  const expensesSnap = await getDocs(collection(db, 'projects', projectId, 'expenses'));
  return expensesSnap.docs.map(doc => ({ ...doc.data(), id: doc.id } as Expense));
}

// ============================================================================
// OPERAZIONI SAL
// ============================================================================

/**
 * Salva SAL predictions
 */
export async function saveSALPredictions(
  projectId: string,
  predictions: SALPrediction[]
): Promise<void> {
  const batch = writeBatch(db);

  predictions.forEach(pred => {
    const predRef = doc(db, 'projects', projectId, 'salPredictions', `sal-${pred.salNumber}`);
    batch.set(predRef, pred);
  });

  await batch.commit();
}

/**
 * Crea nuovo brogliaccio SAL
 */
export async function createBrogliaccioDiCantiere(
  projectId: string,
  salData: Omit<BrogliaccioDiCantiere, 'id' | 'createdAt' | 'lastUpdate'>
): Promise<string> {
  const brogliacioRef = await addDoc(
    collection(db, 'projects', projectId, 'brogliacci'),
    {
      ...salData,
      projectId,
      createdAt: serverTimestamp(),
      lastUpdate: serverTimestamp(),
    }
  );

  // Trigger sincronizzazione
  await syncProjectData(projectId, 'sal_completed');

  return brogliacioRef.id;
}

/**
 * Ricalcola SAL corrente basandosi su progress attività
 */
export async function recalculateCurrentSAL(projectId: string): Promise<void> {
  const timeline = await getTimeline(projectId);
  if (!timeline) return;

  // Calcola progress complessivo pesato sui costi
  const totalEstimatedCost = timeline.activities.reduce((sum, act) => sum + act.estimatedCost, 0);
  const weightedProgress = timeline.activities.reduce(
    (sum, act) => sum + (act.progress / 100) * act.estimatedCost,
    0
  );

  const overallProgress = (weightedProgress / totalEstimatedCost) * 100;

  // Aggiorna documento progetto
  await updateDoc(doc(db, 'projects', projectId), {
    'basicInfo.currentProgress': overallProgress,
    'basicInfo.lastUpdate': serverTimestamp(),
  });
}

// ============================================================================
// AI ANALYSIS
// ============================================================================

/**
 * Salva analisi IA
 */
export async function saveAIAnalysis(
  projectId: string,
  analysis: ProjectAIAnalysis
): Promise<void> {
  const analysisRef = doc(db, 'projects', projectId, 'aiAnalysis', 'current');
  await setDoc(analysisRef, analysis);
}

/**
 * Ottiene analisi IA corrente
 */
export async function getAIAnalysis(projectId: string): Promise<ProjectAIAnalysis | null> {
  const analysisRef = doc(db, 'projects', projectId, 'aiAnalysis', 'current');
  const snap = await getDoc(analysisRef);
  return snap.exists() ? (snap.data() as ProjectAIAnalysis) : null;
}

// ============================================================================
// SINCRONIZZAZIONE AUTOMATICA
// ============================================================================

/**
 * Sistema di sincronizzazione che propaga cambiamenti
 */
export async function syncProjectData(
  projectId: string,
  eventType: 'expense_added' | 'activity_updated' | 'sal_completed' | 'manual_edit'
): Promise<void> {
  console.log(`🔄 Syncing project ${projectId} after ${eventType}`);

  try {
    // 1. Ricalcola SAL corrente
    await recalculateCurrentSAL(projectId);

    // 2. Se scostamento significativo (>10%), rigenera previsioni IA
    const variance = await calculateProjectVariance(projectId);
    if (variance > 0.1) {
      console.log(`⚠️ High variance detected (${(variance * 100).toFixed(1)}%), triggering AI update`);
      // TODO: Implementare rigenerazione parziale previsioni
    }

    // 3. Aggiorna metadata sync
    await updateDoc(doc(db, 'projects', projectId), {
      'generationMetadata.lastSync': serverTimestamp(),
    });

    console.log(`✅ Sync completed for project ${projectId}`);
  } catch (error) {
    console.error('Error syncing project data:', error);
  }
}

/**
 * Calcola varianza complessiva del progetto (costi reali vs previsti)
 */
async function calculateProjectVariance(projectId: string): Promise<number> {
  const timeline = await getTimeline(projectId);
  if (!timeline) return 0;

  const totalEstimated = timeline.activities.reduce((sum, act) => sum + act.estimatedCost, 0);
  const totalActual = timeline.activities.reduce((sum, act) => sum + act.actualCost, 0);

  if (totalEstimated === 0) return 0;

  return Math.abs(totalActual - totalEstimated) / totalEstimated;
}

// ============================================================================
// GENERATION STATUS
// ============================================================================

/**
 * Imposta stato generazione
 */
async function setGenerationStatus(projectId: string, status: GenerationStatus): Promise<void> {
  const statusRef = doc(db, 'generationStatus', projectId);
  await setDoc(statusRef, status);
}

/**
 * Aggiorna stato generazione
 */
async function updateGenerationStatus(
  projectId: string,
  updates: Partial<GenerationStatus>
): Promise<void> {
  const statusRef = doc(db, 'generationStatus', projectId);
  await updateDoc(statusRef, updates);
}

/**
 * Ottiene stato generazione
 */
export async function getGenerationStatus(projectId: string): Promise<GenerationStatus | null> {
  const statusRef = doc(db, 'generationStatus', projectId);
  const snap = await getDoc(statusRef);
  return snap.exists() ? (snap.data() as GenerationStatus) : null;
}

/**
 * Listener real-time per stato generazione
 */
export function subscribeToGenerationStatus(
  projectId: string,
  callback: (status: GenerationStatus | null) => void
): () => void {
  const statusRef = doc(db, 'generationStatus', projectId);
  return onSnapshot(statusRef, (snap) => {
    callback(snap.exists() ? (snap.data() as GenerationStatus) : null);
  });
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Verifica se i dati completi sono stati generati
 */
export async function hasFullDataGenerated(projectId: string): Promise<boolean> {
  const projectRef = doc(db, 'projects', projectId);
  const snap = await getDoc(projectRef);

  if (!snap.exists()) return false;

  const data = snap.data();
  return data?.generationMetadata?.fullDataGenerated === true;
}

/**
 * Forza rigenerazione completa dati progetto
 */
export async function forceRegenerateProjectData(projectId: string): Promise<void> {
  const projectRef = doc(db, 'projects', projectId);
  const projectSnap = await getDoc(projectRef);

  if (!projectSnap.exists()) throw new Error('Project not found');

  const projectData = projectSnap.data();

  await generateAndSaveProjectData(
    projectId,
    projectData.userId,
    projectData.userTier || 1,
    projectData.preventivo,
    {
      title: projectData.basicInfo?.title || projectData.projectName,
      location: projectData.location || '',
      totalValue: projectData.preventivo?.totale || 0,
    }
  );
}
