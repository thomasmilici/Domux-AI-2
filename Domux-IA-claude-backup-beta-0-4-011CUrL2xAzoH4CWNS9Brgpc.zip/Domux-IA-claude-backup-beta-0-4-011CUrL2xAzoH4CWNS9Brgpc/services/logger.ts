// services/logger.ts

import { db, addDoc, collection, serverTimestamp } from './firebase';

/**
 * Logger centralizzato che scrive sia su console che su Firestore
 * per permettere debugging autonomo e analisi degli errori
 */
class AppLogger {
  private prefix = "[Domux AI]";
  private userId: string | null = null;
  private sessionId: string | null = null;
  private logsEnabled = true;

  private getCurrentTimestamp(): string {
    return new Date().toISOString();
  }

  /**
   * Imposta l'ID dell'utente corrente per i log
   */
  public setUserId(userId: string | null): void {
    this.userId = userId;
  }

  /**
   * Imposta l'ID della sessione corrente per i log
   */
  public setSessionId(sessionId: string | null): void {
    this.sessionId = sessionId;
  }

  /**
   * Abilita o disabilita il logging su Firestore
   */
  public setLogsEnabled(enabled: boolean): void {
    this.logsEnabled = enabled;
  }

  /**
   * Salva il log su Firestore in modo non bloccante
   */
  private async saveToFirestore(level: 'log' | 'warn' | 'error', message: string, context?: any): Promise<void> {
    if (!this.logsEnabled) return;

    try {
      const logEntry: any = {
        level,
        message,
        timestamp: serverTimestamp(),
        timestampISO: this.getCurrentTimestamp(),
        userAgent: navigator.userAgent,
      };

      // Aggiungi contesto utente e sessione se disponibili
      if (this.userId) {
        logEntry.userId = this.userId;
      }
      if (this.sessionId) {
        logEntry.sessionId = this.sessionId;
      }

      // Serializza il contesto in modo sicuro
      if (context !== undefined) {
        try {
          if (context instanceof Error) {
            logEntry.context = {
              name: context.name,
              message: context.message,
              stack: context.stack,
            };
          } else if (typeof context === 'object') {
            logEntry.context = JSON.parse(JSON.stringify(context, (key, value) => {
              // Gestisci valori non serializzabili
              if (value instanceof Error) {
                return {
                  name: value.name,
                  message: value.message,
                  stack: value.stack,
                };
              }
              if (typeof value === 'function') {
                return '[Function]';
              }
              if (typeof value === 'undefined') {
                return '[Undefined]';
              }
              return value;
            }));
          } else {
            logEntry.context = String(context);
          }
        } catch (e) {
          logEntry.context = '[Unable to serialize context]';
        }
      }

      // Salva in background senza attendere
      addDoc(collection(db, 'logs'), logEntry).catch(err => {
        // Se fallisce il salvataggio su Firestore, non blocchiamo l'app
        console.error('[Logger] Failed to save log to Firestore:', err);
      });
    } catch (err) {
      // Ignora errori di logging per non bloccare l'app
      console.error('[Logger] Error in saveToFirestore:', err);
    }
  }

  /**
   * Registra un messaggio informativo standard.
   * @param message Il messaggio principale da registrare.
   * @param context Dati aggiuntivi o oggetti da ispezionare.
   */
  public log(message: string, ...context: any[]): void {
    const timestamp = this.getCurrentTimestamp();
    console.log(`${this.prefix} [LOG] ${timestamp}: ${message}`, ...context);

    // Salva su Firestore solo per messaggi importanti (opzionale per ridurre i log)
    const contextObj = context.length > 0 ? context : undefined;
    this.saveToFirestore('log', message, contextObj);
  }

  /**
   * Registra un messaggio di avvertimento.
   * @param message Il messaggio di avvertimento.
   * @param context Dati aggiuntivi o oggetti.
   */
  public warn(message: string, ...context: any[]): void {
    const timestamp = this.getCurrentTimestamp();
    console.warn(`${this.prefix} [WARN] ${timestamp}: ${message}`, ...context);

    const contextObj = context.length > 0 ? context : undefined;
    this.saveToFirestore('warn', message, contextObj);
  }

  /**
   * Registra un errore.
   * @param message Il messaggio di errore.
   * @param error L'oggetto errore o dati contestuali.
   */
  public error(message: string, ...error: any[]): void {
    const timestamp = this.getCurrentTimestamp();
    console.error(`${this.prefix} [ERROR] ${timestamp}: ${message}`, ...error);

    const errorObj = error.length > 0 ? error[0] : undefined;
    this.saveToFirestore('error', message, errorObj);
  }

  /**
   * Recupera gli ultimi N log da Firestore
   */
  public async getRecentLogs(limitCount: number = 50): Promise<any[]> {
    try {
      const { getDocs, query, orderBy, limit } = await import('./firebase');
      const logsQuery = query(
        collection(db, 'logs'),
        orderBy('timestamp', 'desc'),
        limit(limitCount)
      );
      const snapshot = await getDocs(logsQuery);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (err) {
      console.error('[Logger] Failed to retrieve logs:', err);
      return [];
    }
  }
}

// Esporta un'istanza singleton del logger
const Logger = new AppLogger();
export default Logger;
