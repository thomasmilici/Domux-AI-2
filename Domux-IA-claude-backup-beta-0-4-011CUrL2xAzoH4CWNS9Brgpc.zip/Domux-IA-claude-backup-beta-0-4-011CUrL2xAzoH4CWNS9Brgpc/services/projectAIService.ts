/**
 * Servizio per la generazione automatica dei dati di Project Management con IA
 * Utilizza Gemini API per creare timeline, SAL, spese previste, analisi rischi
 * Versione 0.5 - Sistema IA-Driven
 */

import { GoogleGenAI } from "@google/genai";
import type {
  ProjectTimeline,
  Activity,
  Milestone,
  BrogliaccioDiCantiere,
  SALPrediction,
  Expense,
  ProjectAIAnalysis,
  RiskFactor,
  CostPrediction,
  TimelinePrediction,
  ActivityCategory,
} from '../types/projectManagement';
import { serverTimestamp } from '../services/firebase';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Estrae JSON da risposta Gemini (gestisce markdown e testo extra)
 */
function extractJson(text: string): any {
  const jsonRegex = /```json\s*([\s\S]*?)\s*```|({[\s\S]*}|\[[\s\S]*\])/;
  const match = text.match(jsonRegex);

  if (!match) {
    throw new Error("Nessun blocco JSON valido trovato nella risposta AI.");
  }

  const jsonString = match[1] || match[2];
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    console.error("Failed to parse JSON:", jsonString);
    throw new Error("La risposta AI non è in un formato JSON valido.");
  }
}

/**
 * Genera l'intera struttura di project management per un preventivo
 */
export async function generateProjectManagementData(
  preventivo: any,
  projectInfo: {
    title: string;
    location: string;
    totalValue: number;
  }
): Promise<{
  timeline: Omit<ProjectTimeline, 'projectId'>;
  salPredictions: SALPrediction[];
  predictedExpenses: Expense[];
  aiAnalysis: Omit<ProjectAIAnalysis, 'projectId'>;
}> {
  const prompt = buildProjectManagementPrompt(preventivo, projectInfo);

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-exp",
      contents: prompt,
      config: {
        temperature: 0.4, // Più deterministico per dati strutturati
        topP: 0.8,
        topK: 40,
        maxOutputTokens: 8192,
      }
    });

    const text = response.text;
    const data = extractJson(text);

    // Valida e trasforma i dati
    return parseAndValidateProjectData(data, projectInfo.totalValue);
  } catch (error: any) {
    console.error('Error generating project management data:', error);
    throw new Error(`Errore generazione dati progetto: ${error.message}`);
  }
}

/**
 * Costruisce il prompt per Gemini
 */
function buildProjectManagementPrompt(
  preventivo: any,
  projectInfo: { title: string; location: string; totalValue: number }
): string {
  return `Sei un esperto project manager e direttore lavori nel settore delle costruzioni italiano.

Analizza questo preventivo e genera un piano di progetto COMPLETO e REALISTICO per un cantiere italiano.

INFORMAZIONI PROGETTO:
Titolo: ${projectInfo.title}
Ubicazione: ${projectInfo.location}
Valore Totale: ${formatCurrency(projectInfo.totalValue)}

PREVENTIVO DETTAGLIATO:
${JSON.stringify(preventivo, null, 2)}

---

GENERA un piano di progetto completo in formato JSON con questa struttura:

{
  "timeline": {
    "totalDurationWeeks": number,
    "activities": [
      {
        "id": "act-001",
        "name": string,
        "category": "demolizioni" | "impianti_idraulici" | "impianti_elettrici" | "murature" | "intonaci" | "pavimenti" | "rivestimenti" | "serramenti" | "finiture" | "imbiancatura" | "altro",
        "startWeek": number,
        "duration": number,
        "dependencies": [string],
        "estimatedCost": number,
        "resources": [
          {
            "type": "manodopera" | "materiali" | "mezzi" | "subappalto",
            "description": string,
            "quantity": number,
            "unit": string,
            "unitCost": number,
            "totalCost": number
          }
        ],
        "notes": string
      }
    ],
    "milestones": [
      {
        "id": "mile-001",
        "name": string,
        "week": number,
        "salNumber": number,
        "expectedProgress": number,
        "expectedValue": number
      }
    ],
    "criticalPath": [string]
  },

  "salPredictions": [
    {
      "salNumber": number,
      "expectedWeek": number,
      "expectedProgress": number,
      "expectedValue": number,
      "criticalActivities": [string],
      "risks": [
        {
          "description": string,
          "probability": "low" | "medium" | "high",
          "impact": "low" | "medium" | "high",
          "mitigation": string
        }
      ]
    }
  ],

  "predictedExpenses": [
    {
      "id": "exp-001",
      "weekNumber": number,
      "description": string,
      "category": "personale" | "materiali" | "noleggi" | "subappalti" | "spese_generali",
      "linkedActivityId": string,
      "amount": number,
      "notes": string
    }
  ],

  "aiAnalysis": {
    "riskFactors": [
      {
        "id": "risk-001",
        "category": "tempo" | "costi" | "qualita" | "sicurezza" | "normativa",
        "level": "basso" | "medio" | "alto" | "critico",
        "description": string,
        "probability": number,
        "impact": number,
        "mitigation": string
      }
    ],
    "overallRiskLevel": "basso" | "medio" | "alto" | "critico",
    "costPrediction": {
      "baseCase": number,
      "optimistic": number,
      "pessimistic": number,
      "confidence": number,
      "factors": [
        {
          "name": string,
          "impact": number,
          "probability": number
        }
      ]
    },
    "timelinePrediction": {
      "expectedDuration": number,
      "optimisticDuration": number,
      "pessimisticDuration": number,
      "criticalPath": [string],
      "bufferDays": number,
      "delayProbability": number,
      "delayFactors": [
        {
          "activity": string,
          "reason": string,
          "impact": number
        }
      ]
    },
    "recommendations": [
      {
        "priority": "alta" | "media" | "bassa",
        "category": string,
        "description": string,
        "actionItems": [string]
      }
    ],
    "analysisConfidence": number,
    "dataCompleteness": number
  }
}

---

REGOLE IMPORTANTI:

1. SEQUENZIAMENTO ATTIVITÀ:
   - Rispetta la sequenza logica edilizia italiana: demolizioni → impianti → murature → finiture
   - Considera sovrapposizioni possibili (es: impianti elettrici possono iniziare prima che idraulici finiscano)
   - Identifica dipendenze critiche (es: intonaco dipende da murature completate)

2. DURATE REALISTICHE:
   - Usa durate standard per cantieri italiani
   - Considera dimensioni intervento e complessità
   - Aggiungi buffer per imprevisti (10-15%)

3. SAL (Stati Avanzamento Lavori):
   - Minimo 3, massimo 5 SAL
   - Primo SAL non prima del 30% avanzamento (normativa italiana)
   - Distribuisci SAL su milestone significative
   - SAL finale sempre a 100%

4. ALLOCAZIONE COSTI:
   - Somma di tutti i costi attività = valore totale preventivo
   - Distribuisci costi realisticamente tra manodopera (40-50%), materiali (40-50%), mezzi/altro (10%)
   - Prevedi spese generali 5-10% del totale

5. SPESE PREVISTE:
   - Distribuisci temporalmente secondo timeline
   - Picco di spesa nelle fasi centrali
   - Considera pagamenti rateizzati fornitori
   - Aggiungi costi fissi ricorrenti (noleggi, utenze cantiere)

6. ANALISI RISCHI:
   - Identifica rischi reali per il tipo di intervento
   - Valuta probabilità e impatto in modo conservativo
   - Suggerisci mitigazioni concrete
   - Considera rischi meteo, fornitori, normativa

7. PREVISIONI:
   - Base case = scenario più probabile
   - Optimistic = -10% costi, -15% tempo
   - Pessimistic = +20% costi, +25% tempo
   - Confidence basato su completezza dati

IMPORTANTE:
- Tutti i valori economici in EUR
- Durate in settimane (numeri decimali ok)
- Progress in percentuale 0-100
- IDs univoci e descrittivi
- Note tecniche in italiano

Rispondi SOLO con JSON valido, nessun testo aggiuntivo.
`;
}

/**
 * Valida e trasforma i dati ricevuti da Gemini
 */
function parseAndValidateProjectData(
  data: any,
  expectedTotal: number
): {
  timeline: Omit<ProjectTimeline, 'projectId'>;
  salPredictions: SALPrediction[];
  predictedExpenses: Expense[];
  aiAnalysis: Omit<ProjectAIAnalysis, 'projectId'>;
} {
  // Valida che i costi delle attività sommino al totale (con margine 5%)
  const totalActivitiesCost = data.timeline.activities.reduce(
    (sum: number, act: any) => sum + act.estimatedCost,
    0
  );

  const variance = Math.abs(totalActivitiesCost - expectedTotal) / expectedTotal;
  if (variance > 0.05) {
    console.warn(
      `Attenzione: somma costi attività (${totalActivitiesCost}) differisce dal totale preventivo (${expectedTotal}) del ${(variance * 100).toFixed(1)}%`
    );
  }

  // Trasforma activities aggiungendo campi mancanti
  const now = new Date();
  const projectStartDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000); // +1 settimana

  const activities: Activity[] = data.timeline.activities.map((act: any) => ({
    ...act,
    endWeek: act.startWeek + act.duration,
    progress: 0,
    status: 'not_started' as const,
    actualCost: 0,
    variance: 0,
    aiGenerated: true,
    manuallyModified: false,
    createdAt: serverTimestamp(),
    lastUpdate: serverTimestamp(),
  }));

  // Trasforma milestones
  const milestones: Milestone[] = data.timeline.milestones.map((m: any) => ({
    ...m,
    actualProgress: 0,
    actualValue: 0,
    completed: false,
    aiGenerated: true,
  }));

  // Calcola date timeline
  const estimatedEndDate = new Date(
    projectStartDate.getTime() + data.timeline.totalDurationWeeks * 7 * 24 * 60 * 60 * 1000
  );

  const timeline: Omit<ProjectTimeline, 'projectId'> = {
    generatedAt: serverTimestamp(),
    generatedBy: 'ai',
    lastAIUpdate: serverTimestamp(),
    projectStartDate: projectStartDate as any,
    estimatedEndDate: estimatedEndDate as any,
    totalDurationWeeks: data.timeline.totalDurationWeeks,
    activities,
    milestones,
    criticalPath: data.timeline.criticalPath || [],
    aiAnalysis: {
      confidenceLevel: data.aiAnalysis?.analysisConfidence || 75,
      riskFactors: data.aiAnalysis?.riskFactors?.map((r: any) => r.description) || [],
      recommendations: data.aiAnalysis?.recommendations?.map((r: any) => r.description) || [],
    },
  };

  // Trasforma SAL predictions
  const salPredictions: SALPrediction[] = data.salPredictions.map((sal: any) => ({
    salNumber: sal.salNumber,
    expectedDate: new Date(
      projectStartDate.getTime() + sal.expectedWeek * 7 * 24 * 60 * 60 * 1000
    ) as any,
    expectedProgress: sal.expectedProgress,
    expectedValue: sal.expectedValue,
    criticalActivities: sal.criticalActivities || [],
    risks: sal.risks || [],
  }));

  // Trasforma predicted expenses (convertendo weekNumber in date)
  const predictedExpenses: Expense[] = data.predictedExpenses.map((exp: any, index: number) => ({
    id: exp.id || `pred-exp-${index + 1}`,
    projectId: '', // Sarà impostato dal chiamante
    date: new Date(
      projectStartDate.getTime() + (exp.weekNumber || 1) * 7 * 24 * 60 * 60 * 1000
    ) as any,
    description: exp.description,
    category: exp.category,
    linkedActivityId: exp.linkedActivityId,
    amount: exp.amount,
    paid: false,
    aiSuggested: true,
    notes: exp.notes,
    createdAt: serverTimestamp(),
    lastUpdate: serverTimestamp(),
  }));

  // Trasforma AI analysis
  const riskFactors: RiskFactor[] = (data.aiAnalysis?.riskFactors || []).map((r: any, index: number) => ({
    id: r.id || `risk-${index + 1}`,
    category: r.category,
    level: r.level,
    description: r.description,
    probability: r.probability,
    impact: r.impact,
    riskScore: r.probability * r.impact / 100,
    mitigation: r.mitigation,
    status: 'aperto' as const,
    identifiedAt: serverTimestamp(),
  }));

  const costPrediction: CostPrediction = {
    baseCase: data.aiAnalysis?.costPrediction?.baseCase || expectedTotal,
    optimistic: data.aiAnalysis?.costPrediction?.optimistic || expectedTotal * 0.9,
    pessimistic: data.aiAnalysis?.costPrediction?.pessimistic || expectedTotal * 1.2,
    confidence: data.aiAnalysis?.costPrediction?.confidence || 70,
    factors: data.aiAnalysis?.costPrediction?.factors || [],
    lastUpdate: serverTimestamp(),
  };

  const timelinePrediction: TimelinePrediction = {
    expectedDuration: data.aiAnalysis?.timelinePrediction?.expectedDuration || data.timeline.totalDurationWeeks,
    optimisticDuration: data.aiAnalysis?.timelinePrediction?.optimisticDuration || data.timeline.totalDurationWeeks * 0.85,
    pessimisticDuration: data.aiAnalysis?.timelinePrediction?.pessimisticDuration || data.timeline.totalDurationWeeks * 1.25,
    criticalPath: data.aiAnalysis?.timelinePrediction?.criticalPath || data.timeline.criticalPath,
    bufferDays: data.aiAnalysis?.timelinePrediction?.bufferDays || Math.ceil(data.timeline.totalDurationWeeks * 0.15 * 7),
    delayProbability: data.aiAnalysis?.timelinePrediction?.delayProbability || 30,
    delayFactors: data.aiAnalysis?.timelinePrediction?.delayFactors || [],
    lastUpdate: serverTimestamp(),
  };

  const aiAnalysis: Omit<ProjectAIAnalysis, 'projectId'> = {
    generatedAt: serverTimestamp(),
    lastUpdate: serverTimestamp(),
    riskFactors,
    overallRiskLevel: data.aiAnalysis?.overallRiskLevel || 'medio',
    costPrediction,
    timelinePrediction,
    recommendations: data.aiAnalysis?.recommendations || [],
    analysisConfidence: data.aiAnalysis?.analysisConfidence || 75,
    dataCompleteness: data.aiAnalysis?.dataCompleteness || 80,
  };

  return {
    timeline,
    salPredictions,
    predictedExpenses,
    aiAnalysis,
  };
}

/**
 * Utility per formattare valuta
 */
function formatCurrency(value: number): string {
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
  }).format(value);
}

/**
 * Rigenera solo la timeline mantenendo i dati esistenti
 */
export async function regenerateTimeline(
  preventivo: any,
  projectInfo: any,
  existingActivities?: Activity[]
): Promise<Omit<ProjectTimeline, 'projectId'>> {
  // TODO: Implementare logica di rigenerazione parziale
  // Mantiene progress e actualCost delle attività esistenti
  // Ricalcola solo durate e dipendenze

  const fullData = await generateProjectManagementData(preventivo, projectInfo);
  return fullData.timeline;
}

/**
 * Aggiorna previsioni SAL basandosi su avanzamento reale
 */
export async function updateSALPredictions(
  currentProgress: number,
  timeline: ProjectTimeline,
  expenses: Expense[]
): Promise<SALPrediction[]> {
  // TODO: Implementare logica di aggiornamento previsioni
  // Usa dati reali per migliorare previsioni future

  return [];
}
