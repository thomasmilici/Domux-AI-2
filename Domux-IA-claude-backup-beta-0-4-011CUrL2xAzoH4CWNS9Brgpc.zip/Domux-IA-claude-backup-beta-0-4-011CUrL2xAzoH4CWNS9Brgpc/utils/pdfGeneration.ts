import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ComputoItem, CertificationMetadata, ProjectSession } from '../types';
import { User } from '../services/firebase';

/**
 * Funzione helper per disegnare testo giustificato con paginazione automatica
 * @param doc - Documento jsPDF
 * @param text - Testo da giustificare
 * @param x - Coordinata X iniziale (margine sinistro)
 * @param y - Coordinata Y iniziale
 * @param maxWidth - Larghezza massima del testo
 * @param lineHeight - Altezza della riga
 * @param pageHeight - Altezza della pagina
 * @param bottomMargin - Margine inferiore della pagina
 * @param topMargin - Margine superiore per nuove pagine
 * @returns La coordinata Y finale dopo il rendering
 */
function drawJustifiedText(
    doc: jsPDF,
    text: string,
    x: number,
    y: number,
    maxWidth: number,
    lineHeight: number,
    pageHeight: number,
    bottomMargin: number,
    topMargin: number
): number {
    const lines = doc.splitTextToSize(text, maxWidth);
    let currentY = y;

    for (let i = 0; i < lines.length; i++) {
        // Check se serve nuova pagina
        if (currentY + lineHeight > pageHeight - bottomMargin) {
            doc.addPage();
            currentY = topMargin;
        }

        const line = lines[i];
        const isLastLine = i === lines.length - 1;

        // Non giustificare l'ultima riga o righe troppo corte
        if (isLastLine || doc.getTextWidth(line) < maxWidth * 0.75) {
            doc.text(line, x, currentY);
        } else {
            // Giustifica la riga distribuendo gli spazi
            const words = line.split(' ');
            if (words.length === 1) {
                doc.text(line, x, currentY);
            } else {
                const lineWidthWithoutSpaces = words.reduce((sum, word) => sum + doc.getTextWidth(word), 0);
                const totalSpaceWidth = maxWidth - lineWidthWithoutSpaces;
                const spaceWidth = totalSpaceWidth / (words.length - 1);

                let currentX = x;
                words.forEach((word, index) => {
                    doc.text(word, currentX, currentY);
                    currentX += doc.getTextWidth(word);
                    if (index < words.length - 1) {
                        currentX += spaceWidth;
                    }
                });
            }
        }
        currentY += lineHeight;
    }

    return currentY;
}

/**
 * Genera un PDF professionale con layout tecnico formale
 *
 * Caratteristiche principali:
 * - Margini simmetrici di 20mm (2cm) su entrambi i lati
 * - Campo "Committente" nell'intestazione in alto a destra
 * - Testo giustificato nella relazione tecnica
 * - Tabella computo metrico allineata con i margini del documento
 * - Immagini prima/dopo (opzionali)
 *
 * @param computoItems - Voci di computo
 * @param reportText - Relazione tecnica
 * @param user - Dati utente/professionista
 * @param session - Sessione progetto (committente, oggetto)
 * @param metadata - Metadati certificazione
 * @param originalImageUrl - URL immagine stato attuale (opzionale)
 * @param generatedImageUrl - URL immagine stato finale (opzionale)
 * @returns jsPDF document
 */
export function generateProfessionalPDF(
    computoItems: ComputoItem[],
    reportText: string,
    user: User,
    session: ProjectSession | null,
    metadata: CertificationMetadata,
    originalImageUrl?: string,
    generatedImageUrl?: string
): jsPDF {
    const doc = new jsPDF();
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 20; // Margini simmetrici di 2cm (20mm)
    const bottomMargin = 25; // Margine inferiore aumentato per numerazione pagine
    let currentY = 20;

    // Titolo progetto con formato su 2 righe:
    // Riga 1: "[Descrizione lavori]"
    // Riga 2: "Sig. [Cognome] - [Data]"
    const projectTitle = session?.projectName || 'COMPUTO METRICO ESTIMATIVO';

    // Separa il titolo in 2 righe (split su " Sig. ")
    let titleLine1 = projectTitle;
    let titleLine2 = '';

    const sigIndex = projectTitle.indexOf(' Sig. ');
    if (sigIndex !== -1) {
        titleLine1 = projectTitle.substring(0, sigIndex);
        titleLine2 = projectTitle.substring(sigIndex + 1); // +1 per rimuovere lo spazio iniziale
    }

    // ===== 1. INTESTAZIONE PROFESSIONALE =====
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(13, 44, 84); // brand-dark

    // Riga 1 del titolo
    doc.text(titleLine1.toUpperCase(), margin, currentY);
    currentY += 7; // Spazio tra le righe del titolo

    // Riga 2 del titolo (se presente)
    if (titleLine2) {
        doc.text(titleLine2.toUpperCase(), margin, currentY);
        currentY += 5; // Spazio dopo il titolo completo
    }

    // Numero documento e codice in alto a destra
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(80);

    // Componiamo il nome committente
    const committenteNome = session?.context.committente?.nome || '';
    const committenteCognome = session?.context.committente?.cognome || '';
    const committenteCompleto = [committenteNome, committenteCognome].filter(x => x).join(' ') || 'Non specificato';

    const docInfo = [
        `Committente: ${committenteCompleto}`,
        `Doc. N. ${metadata.readableId}`,
        `Data: ${new Date(metadata.timestamp).toLocaleDateString('it-IT')}`,
        `Località: ${session?.context.location || 'Non specificato'}`
    ];

    // Salva la posizione Y iniziale per i dati committente
    const docInfoStartY = currentY;
    doc.text(docInfo, pageW - margin, docInfoStartY, { align: 'right' });

    // Calcola lo spazio occupato dai dati committente (4 righe * altezza riga)
    const lineSpacing = 4; // Spaziatura tra righe per fontSize 9
    const docInfoHeight = docInfo.length * lineSpacing;

    // Aggiorna currentY per essere sotto i dati committente
    currentY = Math.max(currentY, docInfoStartY + docInfoHeight + 5); // +5 per margine extra

    // Linea di separazione (ora posizionata correttamente sotto i dati committente)
    doc.setDrawColor(13, 44, 84);
    doc.setLineWidth(0.5);
    doc.line(margin, currentY, pageW - margin, currentY);

    // ===== 2. RELAZIONE TECNICA =====
    currentY += 10;
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(13, 44, 84);
    doc.text('RELAZIONE TECNICA', margin, currentY);

    currentY += 8;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(40);

    // Usa la funzione drawJustifiedText per testo giustificato con paginazione
    const lineHeight = 5; // Altezza di una riga
    currentY = drawJustifiedText(
        doc,
        reportText,
        margin,
        currentY,
        pageW - margin * 2,
        lineHeight,
        pageH,
        bottomMargin,
        margin
    );

    currentY += 10; // Spazio dopo la relazione

    // ===== INSERIMENTO IMMAGINI PRIMA/DOPO (se presenti) =====
    if (originalImageUrl || generatedImageUrl) {
        // Check se serve nuova pagina per le immagini
        if (currentY > pageH - 120) {
            doc.addPage();
            currentY = margin;
        }

        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(13, 44, 84);
        doc.text('IMMAGINI PROGETTO', margin, currentY);
        currentY += 10;

        const imageWidth = (pageW - margin * 3) / 2; // Due immagini affiancate
        const imageHeight = imageWidth * 0.75; // Proporzione 4:3

        // Check se c'è spazio per le immagini, altrimenti nuova pagina
        if (currentY + imageHeight > pageH - bottomMargin) {
            doc.addPage();
            currentY = margin;
        }

        // Immagine PRIMA (stato attuale)
        if (originalImageUrl) {
            doc.setFontSize(10);
            doc.setFont('helvetica', 'bold');
            doc.setTextColor(80);
            doc.text('STATO ATTUALE', margin, currentY);
            currentY += 5;

            try {
                doc.addImage(originalImageUrl, 'JPEG', margin, currentY, imageWidth, imageHeight);
            } catch (error) {
                console.error('Error adding original image to PDF:', error);
            }
        }

        // Immagine DOPO (stato finale generato)
        if (generatedImageUrl) {
            const secondImageX = margin + imageWidth + margin;
            const labelY = originalImageUrl ? currentY - 5 : currentY;

            doc.setFontSize(10);
            doc.setFont('helvetica', 'bold');
            doc.setTextColor(80);
            doc.text('STATO FINALE', secondImageX, labelY);

            const imageY = originalImageUrl ? currentY : currentY + 5;

            try {
                doc.addImage(generatedImageUrl, 'JPEG', secondImageX, imageY, imageWidth, imageHeight);
            } catch (error) {
                console.error('Error adding generated image to PDF:', error);
            }
        }

        // Aggiorna currentY dopo le immagini
        currentY += imageHeight + 15;
    }

    // Check se serve nuova pagina prima della tabella
    if (currentY > pageH - 80) {
        doc.addPage();
        currentY = margin;
    }

    // ===== 3. TABELLA COMPUTO METRICO =====
    const tableData = computoItems.map((item, index) => [
        String(index + 1), // N.
        item.codice_articolo,
        item.descrizione,
        item.um,
        item.quantita.toLocaleString('it-IT', { minimumFractionDigits: 2 }),
        item.prezzo_unitario.toLocaleString('it-IT', { minimumFractionDigits: 2 }), // Senza €
        item.importo.toLocaleString('it-IT', { minimumFractionDigits: 2 }) // Senza €
    ]);

    const total = computoItems.reduce((sum, item) => sum + item.importo, 0);

    // Calcola larghezza disponibile per la tabella rispettando i margini
    const availableWidth = pageW - (margin * 2);

    autoTable(doc, {
        startY: currentY,
        head: [['N.', 'Codice', 'Descrizione', 'U.M.', 'Quantità', 'P.U.\n€', 'Importo €']],
        body: tableData,
        foot: [], // Totale NON in footer tabella
        theme: 'grid',
        tableWidth: availableWidth, // Larghezza tabella = larghezza disponibile tra i margini
        headStyles: {
            fillColor: [13, 44, 84], // brand-dark
            textColor: 255,
            fontSize: 9,
            fontStyle: 'bold',
            halign: 'center'
        },
        bodyStyles: {
            fontSize: 8,
            textColor: [40, 40, 40],
            cellPadding: 3
        },
        columnStyles: {
            0: { cellWidth: availableWidth * 0.06, halign: 'right' }, // N. - 6%
            1: { cellWidth: availableWidth * 0.18, halign: 'right' },   // Codice - 18%
            2: { cellWidth: availableWidth * 0.38, halign: 'justify' },   // Descrizione - 38% giustificata
            3: { cellWidth: availableWidth * 0.08, halign: 'right' }, // U.M. - 8%
            4: { cellWidth: availableWidth * 0.10, halign: 'right' },  // Quantità - 10%
            5: { cellWidth: availableWidth * 0.10, halign: 'right' },  // P.U. - 10%
            6: { cellWidth: availableWidth * 0.10, halign: 'right' }   // Importo - 10%
        },
        styles: {
            lineColor: [200, 200, 200],
            lineWidth: 0.1
        },
        margin: { left: margin, right: margin, bottom: bottomMargin },
        didDrawPage: (data: any) => {
            // Assicurati che siamo sull'ultima pagina della tabella
            currentY = data.cursor.y;
        }
    });

    // Get last table position using the correct jspdf-autotable API
    // Aggiungi un buffer di sicurezza
    currentY = currentY + 10;

    // ===== 4. TOTALE COMPLESSIVO (subito dopo la tabella) =====
    // Check se serve nuova pagina per il totale
    if (currentY > pageH - 40) {
        doc.addPage();
        currentY = margin;
    }

    // Linea sopra il totale
    doc.setDrawColor(13, 44, 84);
    doc.setLineWidth(0.5);
    doc.line(margin, currentY, pageW - margin, currentY);

    currentY += 2;

    // Rettangolo leggero per evidenziare
    doc.setFillColor(245, 245, 245); // grigio molto chiaro
    doc.rect(margin, currentY, pageW - margin * 2, 12, 'F');

    currentY += 8;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(13, 44, 84);
    doc.text('IMPORTO TOTALE (IVA esclusa):', margin + 5, currentY);

    doc.setFontSize(14);
    doc.setTextColor(22, 101, 52); // green-700
    doc.text(total.toLocaleString('it-IT', { style: 'currency', currency: 'EUR' }), pageW - margin - 5, currentY, { align: 'right' });

    // ===== 5. FOOTER =====
    // Salva il numero di pagine corrente
    const totalPages = (doc as any).internal.getNumberOfPages();

    // Aggiungi footer su ogni pagina
    for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);

        // DOMUX AI in basso a sinistra (su tutte le pagine)
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(13, 44, 84);
        doc.text('DOMUX AI', margin, pageH - 18);

        // Certificazione sotto DOMUX AI (in basso a sinistra)
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(6);
        doc.setTextColor(150);
        doc.text(`Certificato SHA-256: ${metadata.hash.substring(0, 32)}...`, margin, pageH - 10);
        doc.text(`UUID: ${metadata.uuid}`, margin, pageH - 6);

        // Numerazione pagine in basso centro
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(80);
        doc.text(`${i} di ${totalPages}`, pageW / 2, pageH - 10, { align: 'center' });

        // Dati professionista solo nell'ultima pagina (in basso a destra)
        if (i === totalPages) {
            let footerY = pageH - 35;

            doc.setFont('helvetica', 'italic');
            doc.setFontSize(8);
            doc.setTextColor(100);
            doc.text('Elaborato da:', pageW - margin, footerY, { align: 'right' });

            footerY += 4;
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(9);
            doc.setTextColor(13, 44, 84);
            const professionalInfo = [
                user.ragioneSociale || user.displayName || 'Domux AI',
                user.partitaIva ? `P.IVA ${user.partitaIva}` : '',
                user.indirizzo || '',
                `Email: ${user.emailContatto || user.email || ''}`
            ].filter(line => line);

            professionalInfo.forEach(line => {
                doc.text(line, pageW - margin, footerY, { align: 'right' });
                footerY += 4;
            });
        }
    }

    return doc;
}
