// This file is obsolete and has been replaced by assets/logo-jpeg.ts
// It is intentionally left empty to prevent its use.
