# Sistema di Logging Automatico

## Panoramica

Il sistema di logging è stato migliorato per salvare automaticamente tutti i log (info, warning, errori) su **Firestore**, permettendo il monitoraggio e il debugging autonomo.

## Caratteristiche

✅ **Logging Automatico**: Tutti i log vengono salvati su Firestore in background
✅ **Tracciamento Utente**: Ogni log include userId e sessionId
✅ **Stack Trace**: Gli errori includono stack trace completo
✅ **Non Bloccante**: Il salvataggio avviene in background senza rallentare l'app
✅ **Serializzazione Sicura**: Gestisce oggetti complessi, errori, funzioni

## Struttura Log su Firestore

Ogni log salvato in Firestore (collection `logs`) contiene:

```typescript
{
  level: 'log' | 'warn' | 'error',
  message: string,
  timestamp: Timestamp,
  timestampISO: string,
  userId?: string,
  sessionId?: string,
  userAgent: string,
  context?: any // Dati aggiuntivi, stack trace per errori
}
```

## Come Usare

### Nel Codice

Il logger funziona come prima, ma ora salva anche su Firestore:

```typescript
import Logger from './services/logger';

// Log informativo
Logger.log("Operazione completata", { data: someData });

// Warning
Logger.warn("Attenzione: valore non valido", { value });

// Errore
Logger.error("Errore durante la generazione", error);
```

### Leggere i Log

#### Opzione 1: Dalla Console Firebase

1. Vai su [Firebase Console](https://console.firebase.google.com/)
2. Seleziona il progetto `progettista-ai`
3. Firestore Database → Collection `logs`
4. Filtra per:
   - `level == "error"` per vedere solo gli errori
   - `userId == "xxx"` per vedere i log di un utente specifico
   - `sessionId == "xxx"` per vedere i log di una sessione specifica

#### Opzione 2: Script Node (TODO - richiede setup)

```bash
# Installare ts-node se non presente
npm install -g ts-node

# Eseguire lo script
ts-node scripts/read-logs.ts
```

#### Opzione 3: Programmaticamente

```typescript
import Logger from './services/logger';

// Recupera ultimi 50 log
const logs = await Logger.getRecentLogs(50);
console.log(logs);

// Filtra per errori
const errors = logs.filter(l => l.level === 'error');
```

## Gestione Performance

Per evitare troppi log e costi Firebase:

```typescript
// Disabilita logging su Firestore (mantiene console.log)
Logger.setLogsEnabled(false);

// Riabilita
Logger.setLogsEnabled(true);
```

## Risoluzione Problemi Comuni

### "Non vedo i log su Firestore"

1. Verifica che l'utente sia autenticato
2. Controlla le regole Firestore per la collection `logs`
3. Verifica la console browser per errori del logger

### Regole Firestore Consigliate

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Logs collection - write only per utenti autenticati
    match /logs/{logId} {
      allow write: if request.auth != null;
      allow read: if request.auth != null &&
                     (request.auth.token.role == 'admin' ||
                      request.auth.token.role == 'superadmin');
    }
  }
}
```

## Debug

Per vedere i log del logger stesso (meta-logging):

```javascript
// Apri console browser e digita:
localStorage.setItem('debug_logger', 'true');
// Ricarica la pagina
```

## Esempi di Query Utili

### Firebase Console

Trova errori recenti:
```
level == "error"
timestamp > [timestamp_di_ieri]
```

Trova log di una sessione specifica:
```
sessionId == "abc123"
```

Trova tutti gli errori di un utente:
```
userId == "xxx" AND level == "error"
```
