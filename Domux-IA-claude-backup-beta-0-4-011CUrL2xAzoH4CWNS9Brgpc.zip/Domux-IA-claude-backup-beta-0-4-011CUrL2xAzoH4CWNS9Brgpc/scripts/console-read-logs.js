// Script da eseguire nella console del browser per leggere i log
// Copia e incolla questo codice nella console del browser (F12)

(async function readLogs() {
  console.log('📋 Caricamento log da Firestore...\n');

  try {
    // Importa le funzioni Firebase dal modulo esistente
    const { db, getDocs, collection, query, orderBy, limit } = await import('./services/firebase');

    // Crea query per ultimi 50 log
    const logsQuery = query(
      collection(db, 'logs'),
      orderBy('timestamp', 'desc'),
      limit(50)
    );

    const snapshot = await getDocs(logsQuery);
    const logs = [];

    snapshot.forEach(doc => {
      logs.push({ id: doc.id, ...doc.data() });
    });

    console.log(`✅ Trovati ${logs.length} log\n`);

    // Statistiche
    const errors = logs.filter(l => l.level === 'error');
    const warns = logs.filter(l => l.level === 'warn');
    const infos = logs.filter(l => l.level === 'log');

    console.log('📊 STATISTICHE:');
    console.log(`   🔴 Errori: ${errors.length}`);
    console.log(`   ⚠️  Warning: ${warns.length}`);
    console.log(`   ℹ️  Info: ${infos.length}`);
    console.log(`   📝 Totale: ${logs.length}\n`);

    // Mostra ultimi 5 errori
    if (errors.length > 0) {
      console.log('🔴 ULTIMI ERRORI:\n');
      errors.slice(0, 5).forEach((log, index) => {
        console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        console.log(`#${index + 1} - ${log.timestampISO || 'N/A'}`);
        console.log(`Message: ${log.message}`);
        if (log.userId) console.log(`User: ${log.userId}`);
        if (log.sessionId) console.log(`Session: ${log.sessionId}`);
        if (log.context) {
          console.log('Context:');
          console.log(log.context);
        }
        console.log('');
      });
    }

    // Restituisci tutti i log per analisi
    console.log('💾 Tutti i log sono salvati nella variabile: window.__logs');
    window.__logs = logs;

    return logs;
  } catch (error) {
    console.error('❌ Errore nel caricamento log:', error);
  }
})();
