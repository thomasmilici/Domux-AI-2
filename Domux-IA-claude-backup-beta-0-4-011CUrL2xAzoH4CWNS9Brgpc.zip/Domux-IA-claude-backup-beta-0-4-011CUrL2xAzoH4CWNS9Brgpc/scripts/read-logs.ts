// scripts/read-logs.ts
// Script per leggere i log da Firestore
// Uso: node --loader ts-node/esm scripts/read-logs.ts

import Logger from '../services/logger';

async function main() {
  console.log('📋 Recupero ultimi 100 log da Firestore...\n');

  try {
    const logs = await Logger.getRecentLogs(100);

    if (logs.length === 0) {
      console.log('Nessun log trovato.');
      return;
    }

    console.log(`Trovati ${logs.length} log:\n`);

    // Ordina per timestamp e mostra i log
    logs.forEach((log, index) => {
      const timestamp = log.timestampISO || 'N/A';
      const level = log.level?.toUpperCase() || 'LOG';
      const userId = log.userId || 'N/A';
      const sessionId = log.sessionId || 'N/A';
      const message = log.message || '';
      const context = log.context ? JSON.stringify(log.context, null, 2) : '';

      console.log(`[${index + 1}] ${timestamp} [${level}]`);
      console.log(`   User: ${userId}`);
      console.log(`   Session: ${sessionId}`);
      console.log(`   Message: ${message}`);
      if (context) {
        console.log(`   Context: ${context}`);
      }
      console.log('---\n');
    });

    // Mostra statistiche
    const errors = logs.filter(l => l.level === 'error').length;
    const warns = logs.filter(l => l.level === 'warn').length;
    const infos = logs.filter(l => l.level === 'log').length;

    console.log('\n📊 Statistiche:');
    console.log(`   Errori: ${errors}`);
    console.log(`   Warning: ${warns}`);
    console.log(`   Info: ${infos}`);
    console.log(`   Totale: ${logs.length}`);

    // Mostra gli ultimi 5 errori
    const recentErrors = logs.filter(l => l.level === 'error').slice(0, 5);
    if (recentErrors.length > 0) {
      console.log('\n🔴 Ultimi errori:');
      recentErrors.forEach((log, index) => {
        console.log(`\n${index + 1}. ${log.timestampISO}`);
        console.log(`   ${log.message}`);
        if (log.context) {
          console.log(`   ${JSON.stringify(log.context, null, 2)}`);
        }
      });
    }
  } catch (error) {
    console.error('Errore nel recupero dei log:', error);
  }
}

main().then(() => {
  console.log('\n✅ Script completato');
  process.exit(0);
}).catch(err => {
  console.error('❌ Errore fatale:', err);
  process.exit(1);
});
