/**
 * Tipi per il Sistema di Project Management Integrato con IA
 * Versione 0.5 - Sistema IA-Driven
 */

import type { Timestamp } from '@firebase/firestore';

// ============================================================================
// TIMELINE & ACTIVITIES
// ============================================================================

export type ActivityCategory =
  | 'demolizioni'
  | 'impianti_idraulici'
  | 'impianti_elettrici'
  | 'murature'
  | 'intonaci'
  | 'pavimenti'
  | 'rivestimenti'
  | 'serramenti'
  | 'finiture'
  | 'imbiancatura'
  | 'altro';

export interface Resource {
  type: 'manodopera' | 'materiali' | 'mezzi' | 'subappalto';
  description: string;
  quantity: number;
  unit: string;
  unitCost: number;
  totalCost: number;
}

export interface Activity {
  id: string;
  name: string;
  category: ActivityCategory;
  startWeek: number; // Settimana di inizio (relativa a data inizio progetto)
  duration: number; // Durata in settimane
  endWeek: number; // Calcolato: startWeek + duration
  progress: number; // 0-100
  status: 'not_started' | 'in_progress' | 'completed' | 'blocked';
  dependencies: string[]; // IDs di attività prerequisite
  estimatedCost: number;
  actualCost: number;
  variance: number; // Calcolato: actualCost - estimatedCost
  resources: Resource[];
  aiGenerated: boolean;
  manuallyModified: boolean;
  notes?: string;
  createdAt: Timestamp;
  lastUpdate: Timestamp;
}

export interface Milestone {
  id: string;
  name: string;
  week: number;
  salNumber?: number; // Collegamento a SAL se applicabile
  expectedProgress: number; // % avanzamento atteso
  actualProgress?: number; // % avanzamento reale
  expectedValue: number; // Valore economico atteso
  actualValue?: number; // Valore economico reale
  completed: boolean;
  completedDate?: Timestamp;
  aiGenerated: boolean;
}

export interface ProjectTimeline {
  projectId: string;
  generatedAt: Timestamp;
  generatedBy: 'ai' | 'manual';
  lastAIUpdate: Timestamp;
  projectStartDate: Timestamp;
  estimatedEndDate: Timestamp;
  actualEndDate?: Timestamp;
  totalDurationWeeks: number;
  activities: Activity[];
  milestones: Milestone[];
  criticalPath: string[]; // IDs attività nel percorso critico
  aiAnalysis?: {
    confidenceLevel: number; // 0-100
    riskFactors: string[];
    recommendations: string[];
  };
}

// ============================================================================
// EXPENSES (SPESE)
// ============================================================================

export type ExpenseCategory =
  | 'personale'
  | 'materiali'
  | 'noleggi'
  | 'subappalti'
  | 'spese_generali'
  | 'altro';

export interface Expense {
  id: string;
  projectId: string;
  date: Timestamp;
  description: string;
  category: ExpenseCategory;
  linkedActivityId?: string; // Collegamento a timeline activity
  amount: number;
  invoiceNumber?: string;
  supplier?: string;
  paid: boolean;
  paidDate?: Timestamp;
  paymentMethod?: 'contanti' | 'bonifico' | 'assegno' | 'carta';
  aiSuggested: boolean;
  notes?: string;
  attachments?: string[]; // URLs documenti
  createdAt: Timestamp;
  lastUpdate: Timestamp;
}

export interface ExpensesSummary {
  totalExpenses: number;
  totalPaid: number;
  totalUnpaid: number;
  byCategory: Record<ExpenseCategory, number>;
  byActivity: Record<string, number>; // activityId -> total
  variance: number; // Scostamento da budget
  cashFlowPrediction: {
    nextWeek: number;
    nextMonth: number;
    nextQuarter: number;
  };
}

// ============================================================================
// SAL & BROGLIACCIO
// ============================================================================

export interface SALActivity {
  activityId: string;
  activityName: string;
  plannedProgress: number; // % prevista per questo SAL
  actualProgress: number; // % effettiva
  variance: number; // Differenza
  plannedValue: number;
  actualValue: number;
}

export interface BrogliaccioDiCantiere {
  id: string;
  projectId: string;
  salNumber: number;
  date: Timestamp;
  status: 'previsto' | 'in_corso' | 'completato' | 'certificato';

  // Avanzamento
  activities: SALActivity[];
  totalPlannedProgress: number; // % complessiva prevista
  totalActualProgress: number; // % complessiva effettiva
  progressVariance: number;

  // Valori economici
  totalPlannedValue: number;
  totalActualValue: number;
  valueVariance: number;
  cumulativeValue: number; // Valore cumulativo fino a questo SAL

  // Dettagli tecnici
  workDescription: string; // Descrizione lavori eseguiti
  qualityChecks: {
    item: string;
    status: 'ok' | 'warning' | 'fail';
    notes?: string;
  }[];

  // Metadati
  aiGenerated: boolean;
  manuallyModified: boolean;
  certifiedBy?: string; // Nome direttore lavori
  certifiedDate?: Timestamp;
  notes?: string;
  photos?: string[]; // URLs foto cantiere

  createdAt: Timestamp;
  lastUpdate: Timestamp;
}

export interface SALPrediction {
  salNumber: number;
  expectedDate: Timestamp;
  expectedProgress: number;
  expectedValue: number;
  criticalActivities: string[]; // IDs attività critiche per questo SAL
  risks: {
    description: string;
    probability: 'low' | 'medium' | 'high';
    impact: 'low' | 'medium' | 'high';
    mitigation?: string;
  }[];
}

// ============================================================================
// COMPUTO METRICO DETTAGLIATO (Tier 3)
// ============================================================================

export interface ComputoArticle {
  articleCode: string; // Codice prezziario regionale
  description: string;
  quantity: number;
  unit: string; // m, m2, m3, kg, cad, etc.
  unitPrice: number;
  total: number; // quantity * unitPrice
  linkedActivityId?: string;
  supplier?: string;
  notes?: string;
}

export interface ComputoCategory {
  code: string; // Es: "A.01", "B.03"
  name: string;
  description?: string;
  items: ComputoArticle[];
  subtotal: number;
  percentage?: number; // % sul totale computo
}

export interface ComputoMetricoDettagliato {
  projectId: string;
  version: number;
  createdAt: Timestamp;
  lastUpdate: Timestamp;

  // Riferimenti
  prezziarioRegionale: string; // Es: "Emilia-Romagna 2024"
  currency: 'EUR';

  // Struttura
  categories: ComputoCategory[];

  // Totali
  subtotal: number; // Somma categorie
  speseGenerali: number; // %
  utileImpresa: number; // %
  subtotaleConUtile: number;
  iva: number; // %
  totaleLordo: number;

  // Analisi
  topExpensiveItems: ComputoArticle[]; // Top 10 voci più costose
  categoriesBreakdown: {
    category: string;
    value: number;
    percentage: number;
  }[];

  aiGenerated: boolean;
  certifiedBy?: string;
}

// ============================================================================
// LIBRETTO DELLE MISURE (Tier 3)
// ============================================================================

export interface Measurement {
  orderNumber: number; // Numero d'ordine progressivo
  equalParts: number; // N (numero parti uguali)
  length: number; // Lunghezza
  width: number; // Larghezza/Altezza
  height: number; // Profondità/Spessore
  product: number; // Calcolato: equalParts * length * width * height
  notes?: string;
}

export interface LibrettoMisureEntry {
  id: string;
  projectId: string;
  orderNumber: number; // Progressivo nel libretto
  date: Timestamp;

  // Riferimenti
  linkedArticleCode: string; // Dal computo metrico
  articleDescription: string;
  unit: string;

  // Descrizione lavoro
  workDescription: string; // Es: "Scavo di fondazione lato nord"
  location?: string; // Es: "Piano terra", "Vano A"

  // Misurazioni
  measurements: Measurement[];
  totalProduct: number; // Somma tutti i product

  // Validazione
  expectedQuantity?: number; // Da computo metrico
  variance?: number; // Differenza tra misurato e previsto

  // Approvazioni
  measuredBy?: string; // Nome operatore
  verifiedBy?: string; // Nome direttore lavori
  verifiedDate?: Timestamp;

  // Metadati
  aiGenerated: boolean;
  manuallyModified: boolean;
  photos?: string[]; // Foto misurazione
  notes?: string;

  createdAt: Timestamp;
  lastUpdate: Timestamp;
}

// ============================================================================
// ANALISI IA & PREVISIONI
// ============================================================================

export interface RiskFactor {
  id: string;
  category: 'tempo' | 'costi' | 'qualita' | 'sicurezza' | 'normativa';
  level: 'basso' | 'medio' | 'alto' | 'critico';
  description: string;
  probability: number; // 0-100
  impact: number; // 0-100
  riskScore: number; // probability * impact
  mitigation: string;
  status: 'aperto' | 'in_mitigazione' | 'risolto';
  identifiedAt: Timestamp;
  resolvedAt?: Timestamp;
}

export interface CostPrediction {
  baseCase: number; // Stima più probabile
  optimistic: number; // Scenario migliore
  pessimistic: number; // Scenario peggiore
  confidence: number; // 0-100
  factors: {
    name: string;
    impact: number; // +/- percentuale
    probability: number;
  }[];
  lastUpdate: Timestamp;
}

export interface TimelinePrediction {
  expectedDuration: number; // Settimane
  optimisticDuration: number;
  pessimisticDuration: number;
  criticalPath: string[]; // IDs attività
  bufferDays: number; // Giorni di margine
  delayProbability: number; // 0-100
  delayFactors: {
    activity: string;
    reason: string;
    impact: number; // giorni
  }[];
  lastUpdate: Timestamp;
}

export interface ProjectAIAnalysis {
  projectId: string;
  generatedAt: Timestamp;
  lastUpdate: Timestamp;

  // Analisi rischi
  riskFactors: RiskFactor[];
  overallRiskLevel: 'basso' | 'medio' | 'alto' | 'critico';

  // Previsioni costi
  costPrediction: CostPrediction;

  // Previsioni tempi
  timelinePrediction: TimelinePrediction;

  // Raccomandazioni
  recommendations: {
    priority: 'alta' | 'media' | 'bassa';
    category: string;
    description: string;
    actionItems: string[];
  }[];

  // Benchmark (se disponibili)
  similarProjects?: {
    id: string;
    similarity: number; // 0-100
    actualCost: number;
    actualDuration: number;
  }[];

  // Confidence
  analysisConfidence: number; // 0-100
  dataCompleteness: number; // 0-100
}

// ============================================================================
// PROJECT COMPLETO (Struttura Firestore)
// ============================================================================

export interface ProjectManagementData {
  // Riferimento base
  projectId: string;
  userId: string;
  userTier: 1 | 2 | 3;

  // Info base (Tier 1 - sempre visibile)
  basicInfo: {
    title: string;
    client: string;
    location: string;
    totalValue: number;
    createdAt: Timestamp;
    lastUpdate: Timestamp;
    status: 'planning' | 'in_progress' | 'completed' | 'on_hold' | 'cancelled';
  };

  // Preventivo base (Tier 1)
  preventivo: {
    items: any[]; // Dalla struttura esistente
    totale: number;
    pdfUrl?: string;
  };

  // Timeline (Tier 2 - generato automaticamente, visibile da Tier 2+)
  timeline?: ProjectTimeline;

  // Spese (Tier 2)
  expenses?: {
    items: Expense[];
    summary: ExpensesSummary;
  };

  // Brogliaccio e SAL (Tier 2)
  brogliaccio?: {
    entries: BrogliaccioDiCantiere[];
    predictions: SALPrediction[];
    currentSAL: number;
  };

  // Computo dettagliato (Tier 3)
  computoDettagliato?: ComputoMetricoDettagliato;

  // Libretto misure (Tier 3)
  librettoMisure?: {
    entries: LibrettoMisureEntry[];
    totalEntries: number;
  };

  // Analisi IA (generata automaticamente per tutti)
  aiAnalysis?: ProjectAIAnalysis;

  // Metadati generazione
  generationMetadata: {
    aiGeneratedAt?: Timestamp;
    aiVersion?: string;
    fullDataGenerated: boolean;
    lastSync?: Timestamp;
  };
}

// ============================================================================
// UTILITY TYPES
// ============================================================================

export interface GenerationStatus {
  projectId: string;
  status: 'pending' | 'generating' | 'completed' | 'error';
  progress: number; // 0-100
  currentStep?: string;
  error?: string;
  startedAt: Timestamp;
  completedAt?: Timestamp;
}

export interface SyncEvent {
  projectId: string;
  eventType: 'expense_added' | 'activity_updated' | 'sal_completed' | 'manual_edit';
  timestamp: Timestamp;
  triggeredBy: string; // userId
  changes: Record<string, any>;
  syncedFields: string[];
}
