/**
 * Sistema di Tier e Abbonamenti
 * Versione 0.5
 */

// Tipi di tier disponibili
export type SubscriptionTier = 'free_trial' | 'basic' | 'professional' | 'enterprise';

// Stato del pagamento
export type PaymentStatus = 'trial' | 'active' | 'expired' | 'cancelled' | 'pending';

// Interfaccia per i dati di sottoscrizione dell'utente
export interface UserSubscription {
  tier: SubscriptionTier;
  paymentStatus: PaymentStatus;
  trialStartDate?: Date | any; // Firebase Timestamp
  trialEndDate?: Date | any; // Firebase Timestamp
  subscriptionStartDate?: Date | any; // Firebase Timestamp
  subscriptionEndDate?: Date | any; // Firebase Timestamp (opzionale per rinnovi automatici)
  lastPaymentDate?: Date | any; // Firebase Timestamp
  nextBillingDate?: Date | any; // Firebase Timestamp
  paypalSubscriptionId?: string; // ID sottoscrizione PayPal (per future implementazioni)
  paypalOrderId?: string; // ID ordine PayPal
}

// Configurazione features per ogni tier
export interface TierFeatures {
  name: string;
  displayName: string;
  maxProjects: number; // -1 per illimitati
  maxProjectsPerMonth: number; // -1 per illimitati
  maxSessionsActive: number; // -1 per illimitati
  canAccessAdvancedServices: boolean;
  canAccessPremiumServices: boolean;
  canExportPDF: boolean;
  canUseAIAssistant: boolean;
  canUploadImages: boolean;
  maxImageUploadsPerProject: number;
  canAccessPriceDatabase: boolean;
  prioritySupport: boolean;
  customBranding: boolean; // Logo personalizzato nei PDF
  apiAccess: boolean;
  monthlyPrice?: number; // Prezzo mensile in euro
  yearlyPrice?: number; // Prezzo annuale in euro
}

// Configurazione tier
export const TIER_CONFIG: Record<SubscriptionTier, TierFeatures> = {
  free_trial: {
    name: 'free_trial',
    displayName: 'Prova Gratuita',
    maxProjects: 3,
    maxProjectsPerMonth: 3,
    maxSessionsActive: 2,
    canAccessAdvancedServices: false,
    canAccessPremiumServices: false,
    canExportPDF: true,
    canUseAIAssistant: true,
    canUploadImages: true,
    maxImageUploadsPerProject: 1,
    canAccessPriceDatabase: true,
    prioritySupport: false,
    customBranding: false,
    apiAccess: false,
  },
  basic: {
    name: 'basic',
    displayName: 'Basic',
    maxProjects: 20,
    maxProjectsPerMonth: 20,
    maxSessionsActive: 5,
    canAccessAdvancedServices: false,
    canAccessPremiumServices: false,
    canExportPDF: true,
    canUseAIAssistant: true,
    canUploadImages: true,
    maxImageUploadsPerProject: 3,
    canAccessPriceDatabase: true,
    prioritySupport: false,
    customBranding: false,
    apiAccess: false,
    monthlyPrice: 19.99,
    yearlyPrice: 199.99,
  },
  professional: {
    name: 'professional',
    displayName: 'Professional',
    maxProjects: 100,
    maxProjectsPerMonth: 100,
    maxSessionsActive: 15,
    canAccessAdvancedServices: true,
    canAccessPremiumServices: false,
    canExportPDF: true,
    canUseAIAssistant: true,
    canUploadImages: true,
    maxImageUploadsPerProject: 10,
    canAccessPriceDatabase: true,
    prioritySupport: true,
    customBranding: true,
    apiAccess: false,
    monthlyPrice: 49.99,
    yearlyPrice: 499.99,
  },
  enterprise: {
    name: 'enterprise',
    displayName: 'Enterprise',
    maxProjects: -1, // illimitati
    maxProjectsPerMonth: -1, // illimitati
    maxSessionsActive: -1, // illimitati
    canAccessAdvancedServices: true,
    canAccessPremiumServices: true,
    canExportPDF: true,
    canUseAIAssistant: true,
    canUploadImages: true,
    maxImageUploadsPerProject: -1, // illimitati
    canAccessPriceDatabase: true,
    prioritySupport: true,
    customBranding: true,
    apiAccess: true,
    monthlyPrice: 99.99,
    yearlyPrice: 999.99,
  },
};

// Durata trial in giorni
export const TRIAL_DURATION_DAYS = 7;

// Helper per verificare se un tier può accedere a una feature specifica
export function canAccessFeature(tier: SubscriptionTier, feature: keyof TierFeatures): boolean {
  const tierConfig = TIER_CONFIG[tier];
  const value = tierConfig[feature];

  // Se è un booleano, ritorna direttamente
  if (typeof value === 'boolean') {
    return value;
  }

  // Se è un numero, considera -1 come "illimitato" quindi true
  if (typeof value === 'number') {
    return value !== 0;
  }

  return false;
}

// Helper per confrontare tier (utile per upgrade/downgrade)
export function compareTiers(tierA: SubscriptionTier, tierB: SubscriptionTier): number {
  const tierOrder: SubscriptionTier[] = ['free_trial', 'basic', 'professional', 'enterprise'];
  return tierOrder.indexOf(tierA) - tierOrder.indexOf(tierB);
}

// Helper per verificare se un tier è superiore ad un altro
export function isTierHigherOrEqual(userTier: SubscriptionTier, requiredTier: SubscriptionTier): boolean {
  return compareTiers(userTier, requiredTier) >= 0;
}
