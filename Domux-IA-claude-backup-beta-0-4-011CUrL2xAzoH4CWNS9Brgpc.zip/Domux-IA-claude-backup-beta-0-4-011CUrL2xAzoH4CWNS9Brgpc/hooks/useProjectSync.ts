/**
 * Hook React per sincronizzazione automatica dati progetto
 * Mantiene aggiornati timeline, spese, SAL in tempo reale
 * Versione 0.5 - Sistema IA-Driven
 */

import { useState, useEffect, useCallback } from 'react';
import { onSnapshot, collection, doc } from '@firebase/firestore';
import { db } from '../services/firebase';
import {
  getTimeline,
  getExpenses,
  getAIAnalysis,
  getGenerationStatus,
  syncProjectData,
} from '../services/projectManagementService';
import type {
  ProjectTimeline,
  Expense,
  ProjectAIAnalysis,
  GenerationStatus,
} from '../types/projectManagement';

interface ProjectSyncState {
  timeline: ProjectTimeline | null;
  expenses: Expense[];
  aiAnalysis: ProjectAIAnalysis | null;
  generationStatus: GenerationStatus | null;
  loading: boolean;
  error: string | null;
  lastSync: Date | null;
}

/**
 * Hook principale per sincronizzare tutti i dati di un progetto
 */
export function useProjectSync(projectId: string | null) {
  const [state, setState] = useState<ProjectSyncState>({
    timeline: null,
    expenses: [],
    aiAnalysis: null,
    generationStatus: null,
    loading: true,
    error: null,
    lastSync: null,
  });

  // Caricamento iniziale dati
  useEffect(() => {
    if (!projectId) {
      setState(prev => ({ ...prev, loading: false }));
      return;
    }

    let isMounted = true;

    const loadInitialData = async () => {
      try {
        setState(prev => ({ ...prev, loading: true, error: null }));

        const [timeline, expenses, aiAnalysis, generationStatus] = await Promise.all([
          getTimeline(projectId),
          getExpenses(projectId),
          getAIAnalysis(projectId),
          getGenerationStatus(projectId),
        ]);

        if (isMounted) {
          setState({
            timeline,
            expenses,
            aiAnalysis,
            generationStatus,
            loading: false,
            error: null,
            lastSync: new Date(),
          });
        }
      } catch (error: any) {
        console.error('Error loading project data:', error);
        if (isMounted) {
          setState(prev => ({
            ...prev,
            loading: false,
            error: error.message,
          }));
        }
      }
    };

    loadInitialData();

    return () => {
      isMounted = false;
    };
  }, [projectId]);

  // Listener real-time per timeline
  useEffect(() => {
    if (!projectId) return;

    const timelineRef = doc(db, 'projects', projectId, 'timeline', 'current');
    const unsubscribe = onSnapshot(
      timelineRef,
      (snap) => {
        if (snap.exists()) {
          setState(prev => ({
            ...prev,
            timeline: snap.data() as ProjectTimeline,
            lastSync: new Date(),
          }));
        }
      },
      (error) => {
        console.error('Error listening to timeline:', error);
      }
    );

    return unsubscribe;
  }, [projectId]);

  // Listener real-time per spese
  useEffect(() => {
    if (!projectId) return;

    const expensesRef = collection(db, 'projects', projectId, 'expenses');
    const unsubscribe = onSnapshot(
      expensesRef,
      (snap) => {
        const expenses = snap.docs.map(doc => ({
          ...doc.data(),
          id: doc.id,
        })) as Expense[];

        setState(prev => ({
          ...prev,
          expenses,
          lastSync: new Date(),
        }));
      },
      (error) => {
        console.error('Error listening to expenses:', error);
      }
    );

    return unsubscribe;
  }, [projectId]);

  // Listener real-time per generation status
  useEffect(() => {
    if (!projectId) return;

    const statusRef = doc(db, 'generationStatus', projectId);
    const unsubscribe = onSnapshot(
      statusRef,
      (snap) => {
        if (snap.exists()) {
          setState(prev => ({
            ...prev,
            generationStatus: snap.data() as GenerationStatus,
          }));
        }
      },
      (error) => {
        console.error('Error listening to generation status:', error);
      }
    );

    return unsubscribe;
  }, [projectId]);

  // Force sync callback
  const forceSync = useCallback(async () => {
    if (!projectId) return;

    try {
      await syncProjectData(projectId, 'manual_edit');
    } catch (error: any) {
      console.error('Error forcing sync:', error);
      setState(prev => ({ ...prev, error: error.message }));
    }
  }, [projectId]);

  return {
    ...state,
    forceSync,
  };
}

/**
 * Hook per timeline con operazioni CRUD
 */
export function useTimeline(projectId: string | null) {
  const { timeline, loading, error } = useProjectSync(projectId);

  const getActivity = useCallback(
    (activityId: string) => {
      return timeline?.activities.find(a => a.id === activityId) || null;
    },
    [timeline]
  );

  const getActivitiesByCategory = useCallback(
    (category: string) => {
      return timeline?.activities.filter(a => a.category === category) || [];
    },
    [timeline]
  );

  const getCriticalPathActivities = useCallback(() => {
    if (!timeline) return [];
    return timeline.activities.filter(a => timeline.criticalPath.includes(a.id));
  }, [timeline]);

  const getOverallProgress = useCallback(() => {
    if (!timeline || timeline.activities.length === 0) return 0;

    const totalCost = timeline.activities.reduce((sum, act) => sum + act.estimatedCost, 0);
    const weightedProgress = timeline.activities.reduce(
      (sum, act) => sum + (act.progress / 100) * act.estimatedCost,
      0
    );

    return totalCost > 0 ? (weightedProgress / totalCost) * 100 : 0;
  }, [timeline]);

  return {
    timeline,
    loading,
    error,
    getActivity,
    getActivitiesByCategory,
    getCriticalPathActivities,
    overallProgress: getOverallProgress(),
  };
}

/**
 * Hook per gestione spese con analisi
 */
export function useExpenses(projectId: string | null) {
  const { expenses, loading, error } = useProjectSync(projectId);

  const getTotalExpenses = useCallback(() => {
    return expenses.reduce((sum, exp) => sum + exp.amount, 0);
  }, [expenses]);

  const getTotalPaid = useCallback(() => {
    return expenses.filter(exp => exp.paid).reduce((sum, exp) => sum + exp.amount, 0);
  }, [expenses]);

  const getTotalUnpaid = useCallback(() => {
    return expenses.filter(exp => !exp.paid).reduce((sum, exp) => sum + exp.amount, 0);
  }, [expenses]);

  const getExpensesByCategory = useCallback(() => {
    const byCategory: Record<string, number> = {};

    expenses.forEach(exp => {
      byCategory[exp.category] = (byCategory[exp.category] || 0) + exp.amount;
    });

    return byCategory;
  }, [expenses]);

  const getExpensesByActivity = useCallback(() => {
    const byActivity: Record<string, number> = {};

    expenses.forEach(exp => {
      if (exp.linkedActivityId) {
        byActivity[exp.linkedActivityId] =
          (byActivity[exp.linkedActivityId] || 0) + exp.amount;
      }
    });

    return byActivity;
  }, [expenses]);

  return {
    expenses,
    loading,
    error,
    totalExpenses: getTotalExpenses(),
    totalPaid: getTotalPaid(),
    totalUnpaid: getTotalUnpaid(),
    byCategory: getExpensesByCategory(),
    byActivity: getExpensesByActivity(),
  };
}

/**
 * Hook per monitorare generazione dati in background
 */
export function useGenerationMonitor(projectId: string | null) {
  const { generationStatus } = useProjectSync(projectId);

  const isGenerating = generationStatus?.status === 'generating';
  const hasError = generationStatus?.status === 'error';
  const isCompleted = generationStatus?.status === 'completed';

  return {
    status: generationStatus,
    isGenerating,
    hasError,
    isCompleted,
    progress: generationStatus?.progress || 0,
    currentStep: generationStatus?.currentStep,
    error: generationStatus?.error,
  };
}
