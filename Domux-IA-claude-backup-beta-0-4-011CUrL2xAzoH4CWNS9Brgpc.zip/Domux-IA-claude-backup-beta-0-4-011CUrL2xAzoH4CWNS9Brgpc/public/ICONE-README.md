# Generazione Icone PWA

Le icone attuali sono placeholder temporanei. Per generare icone professionali:

## Opzione 1: Tool Online (Più Veloce)
1. Visita: https://realfavicongenerator.net/
2. Carica il file `icon.svg`
3. Genera tutte le dimensioni
4. Scarica e sostituisci i file in questa cartella

## Opzione 2: NPM Tool (Automatico)
```bash
npx pwa-asset-generator public/icon.svg public --icon-only --background "#0D2C54"
```

## Dimensioni Richieste:
- icon-16x16.png
- icon-32x32.png
- icon-72x72.png
- icon-96x96.png
- icon-128x128.png
- icon-144x144.png
- icon-152x152.png
- icon-180x180.png (iOS)
- icon-192x192.png
- icon-384x384.png
- icon-512x512.png

## Per ora:
L'app usa l'SVG come fallback - funziona su browser moderni!
